package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ListeningEventEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.SavedMixEntity
import com.example.data.local.SeedCatalog
import com.example.data.local.SunozaDatabase
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import com.example.model.TransitionFilterType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: SunozaDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, SunozaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun appName_isSunoza() {
        assertEquals("Sunoza", context.getString(R.string.app_name))
    }

    @Test
    fun authorizedSourceValidator_enforcesAuthorizedSourcesOnly() {
        val allowed = AuthorizedSourceValidator.validateUrl(
            "https://archive.org/download/test_item/track.mp3",
            "https://creativecommons.org/licenses/by/4.0/",
        )
        assertTrue(allowed is SourceValidationResult.Authorized)

        val blockedHttp = AuthorizedSourceValidator.validateUrl(
            "http://archive.org/download/test_item/track.mp3",
        )
        assertTrue(blockedHttp is SourceValidationResult.Rejected)

        val blockedDomain = AuthorizedSourceValidator.validateUrl(
            "https://unauthorized-pirate-site.example.com/song.mp3",
        )
        assertTrue(blockedDomain is SourceValidationResult.Rejected)
    }

    @Test
    fun roomDao_seedsTracksAndManagesOrderedPlaylistsMixesAndHistory() = runTest {
        val dao = db.sunozaDao()
        val seedSongs = SeedCatalog.buildSeedSongs(context)
        val insertedIds = dao.insertSongs(seedSongs)
        assertEquals(4, insertedIds.size)

        val playlistId = dao.insertPlaylist(PlaylistEntity(name = "Night Drive"))
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = insertedIds[0], position = 0))
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = insertedIds[1], position = 1))

        // Verify reordering works
        dao.updatePlaylistOrder(playlistId, listOf(insertedIds[1], insertedIds[0]))
        val refs = dao.observePlaylistCrossRefs().first().filter { it.playlistId == playlistId }
        assertEquals(listOf(insertedIds[1], insertedIds[0]), refs.map { it.songId })

        // Verify saved mixes and listening history
        dao.insertSavedMix(
            SavedMixEntity(
                name = "Sunset Blend",
                deckASongId = insertedIds[0],
                deckBSongId = insertedIds[1],
                crossfader = 0.5f,
                transitionDurationSec = 8,
                filterType = TransitionFilterType.ECHO_FADE.name,
                echoAmount = 0.4f,
                autoMixEnabled = true,
            )
        )
        val mixes = dao.observeSavedMixes().first()
        assertEquals(1, mixes.size)
        assertEquals("Sunset Blend", mixes.first().name)

        dao.insertListeningEvent(ListeningEventEntity(songId = insertedIds[0], sourceType = "BUNDLED"))
        assertEquals(1, dao.observeRecentListeningEvents().first().size)

        dao.setFavorite(insertedIds.last(), true)
        val favorites = dao.observeFavoriteSongs().first()
        assertTrue(favorites.any { it.id == insertedIds.last() })
    }
}
