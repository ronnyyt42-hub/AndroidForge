package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ListeningEventEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.SavedMixEntity
import com.example.data.local.SeedCatalog
import com.example.data.local.SunozaDatabase
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import com.example.model.TransitionFilterType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.remote.ArchiveMetadataResponse
import com.example.data.remote.ArchiveOrgApi
import com.example.data.remote.ArchiveSearchResponse
import com.example.data.remote.AudiusApi
import com.example.data.remote.AudiusArtworkDto
import com.example.data.remote.AudiusTrackDto
import com.example.data.remote.AudiusTracksResponse
import com.example.data.remote.AudiusUserDto
import com.example.data.remote.ItunesSearchApi
import com.example.data.remote.ItunesSearchResponse
import com.example.data.remote.ItunesTrackDto
import com.example.data.repository.MusicRepository
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowNetworkCapabilities
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: SunozaDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, SunozaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun appName_isSunoza() {
        assertEquals("Sunoza", context.getString(R.string.app_name))
    }

    @Test
    fun authorizedSourceValidator_enforcesAuthorizedSourcesOnly() {
        val allowedArchive = AuthorizedSourceValidator.validateUrl(
            "https://archive.org/download/test_item/track.mp3",
            "https://creativecommons.org/licenses/by/4.0/",
        )
        assertTrue(allowedArchive is SourceValidationResult.Authorized)

        val allowedAudius = AuthorizedSourceValidator.validateUrl(
            "https://api.audius.co/v1/tracks/abc123/stream?app_name=SUNOZA",
            "Artist Authorized Stream",
        )
        assertTrue(allowedAudius is SourceValidationResult.Authorized)

        val allowedItunes = AuthorizedSourceValidator.validateUrl(
            "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview125/v4/11/22/33/sample.m4a",
            "Official 30s Preview",
        )
        assertTrue(allowedItunes is SourceValidationResult.Authorized)

        val blockedHttp = AuthorizedSourceValidator.validateUrl(
            "http://archive.org/download/test_item/track.mp3",
        )
        assertTrue(blockedHttp is SourceValidationResult.Rejected)

        val blockedDomain = AuthorizedSourceValidator.validateUrl(
            "https://unauthorized-pirate-site.example.com/song.mp3",
        )
        assertTrue(blockedDomain is SourceValidationResult.Rejected)
    }

    @Test
    fun roomDao_seedsTracksAndManagesOrderedPlaylistsMixesAndHistory() = runTest {
        val dao = db.sunozaDao()
        val seedSongs = SeedCatalog.buildSeedSongs(context)
        val insertedIds = dao.insertSongs(seedSongs)
        assertEquals(4, insertedIds.size)

        val playlistId = dao.insertPlaylist(PlaylistEntity(name = "Night Drive"))
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = insertedIds[0], position = 0))
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = insertedIds[1], position = 1))

        // Verify metadata update preserves playlist cross-refs
        dao.updateSongMetadata(
            songId = insertedIds[0],
            artworkUri = "https://archive.org/services/img/test",
            album = "Updated Album",
            genre = "Synthwave",
        )

        // Verify reordering works
        dao.updatePlaylistOrder(playlistId, listOf(insertedIds[1], insertedIds[0]))
        val refs = dao.observePlaylistCrossRefs().first().filter { it.playlistId == playlistId }
        assertEquals(listOf(insertedIds[1], insertedIds[0]), refs.map { it.songId })
        val updatedSong = dao.observeAllSongs().first().firstOrNull { it.id == insertedIds[0] }
        assertEquals("https://archive.org/services/img/test", updatedSong?.artworkUri)
        assertEquals("Updated Album", updatedSong?.album)

        // Verify saved mixes and listening history
        dao.insertSavedMix(
            SavedMixEntity(
                name = "Sunset Blend",
                deckASongId = insertedIds[0],
                deckBSongId = insertedIds[1],
                crossfader = 0.5f,
                transitionDurationSec = 8,
                filterType = TransitionFilterType.ECHO_FADE.name,
                echoAmount = 0.4f,
                autoMixEnabled = true,
            )
        )
        val mixes = dao.observeSavedMixes().first()
        assertEquals(1, mixes.size)
        assertEquals("Sunset Blend", mixes.first().name)

        dao.insertListeningEvent(ListeningEventEntity(songId = insertedIds[0], sourceType = "BUNDLED"))
        assertEquals(1, dao.observeRecentListeningEvents().first().size)

        dao.setFavorite(insertedIds.last(), true)
        val favorites = dao.observeFavoriteSongs().first()
        assertTrue(favorites.any { it.id == insertedIds.last() })
    }

    @Test
    fun musicRepository_handlesOnlineSearchSuccessServerFailureAndOfflineState() = runTest {
        val dao = db.sunozaDao()
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNet = cm.activeNetwork
        if (activeNet != null) {
            val caps = ShadowNetworkCapabilities.newInstance()
            Shadows.shadowOf(caps).addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            Shadows.shadowOf(cm).setNetworkCapabilities(activeNet, caps)
        }

        val fakeArchive = object : ArchiveOrgApi {
            override suspend fun searchAudio(
                query: String,
                fields: List<String>,
                rows: Int,
                page: Int,
                output: String,
            ) = ArchiveSearchResponse()

            override suspend fun getItemMetadata(identifier: String) = ArchiveMetadataResponse()
        }
        val fakeAudius = object : AudiusApi {
            override suspend fun getTrendingTracks(appName: String, limit: Int) = AudiusTracksResponse(
                data = listOf(
                    AudiusTrackDto(
                        id = "trk-1",
                        title = "Neon Drift",
                        genre = "Synthwave",
                        duration = 205,
                        isStreamable = true,
                        artwork = AudiusArtworkDto(medium = "https://cdn.audius.co/neon-480.jpg"),
                        user = AudiusUserDto(name = "Kairo"),
                    )
                )
            )

            override suspend fun searchTracks(query: String, appName: String, limit: Int) =
                getTrendingTracks(appName, limit)
        }
        val fakeItunes = object : ItunesSearchApi {
            override suspend fun searchSongs(term: String, media: String, entity: String, limit: Int) =
                ItunesSearchResponse(
                    resultCount = 1,
                    results = listOf(
                        ItunesTrackDto(
                            trackId = 99L,
                            trackName = "Solaris Preview",
                            artistName = "Lumen",
                            collectionName = "Orbit EP",
                            previewUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/sample.m4a",
                            artworkUrl100 = "https://is1-ssl.mzstatic.com/100x100bb.jpg",
                            primaryGenreName = "Electronic",
                        )
                    )
                )
        }

        val repo = MusicRepository(context, dao, fakeArchive, fakeAudius, fakeItunes)
        val successOutcome = repo.searchAuthorizedOnlineTracks("neon")
        assertFalse(successOutcome.isOffline)
        assertNull(successOutcome.errorMessage)
        assertTrue(successOutcome.tracks.any { it.id == "audius-trk-1" && it.artworkUrl == "https://cdn.audius.co/neon-480.jpg" })
        assertTrue(successOutcome.tracks.any { it.id == "itunes-99" && it.album == "Orbit EP" })

        val addedSong = repo.addAuthorizedOnlineCandidate(successOutcome.tracks.first()).getOrThrow()
        assertEquals("https://cdn.audius.co/neon-480.jpg", addedSong.artworkUri)

        // Failing API servers should surface clear error message rather than silently failing
        val failingAudius = object : AudiusApi {
            override suspend fun getTrendingTracks(appName: String, limit: Int) = throw IOException("503 Service Unavailable")
            override suspend fun searchTracks(query: String, appName: String, limit: Int) = throw IOException("503 Service Unavailable")
        }
        val failingItunes = object : ItunesSearchApi {
            override suspend fun searchSongs(term: String, media: String, entity: String, limit: Int) = throw IOException("Timeout")
        }
        val failingRepo = MusicRepository(context, dao, fakeArchive, failingAudius, failingItunes)
        val failureOutcome = failingRepo.searchAuthorizedOnlineTracks("synth")
        assertNotNull(failureOutcome.errorMessage)
        assertTrue(failureOutcome.errorMessage!!.contains("unavailable", ignoreCase = true))

        // Offline device state should report isOffline = true cleanly
        Shadows.shadowOf(cm).setDefaultNetworkActive(false)
        if (activeNet != null) {
            Shadows.shadowOf(cm).setNetworkCapabilities(activeNet, null)
        }
        val offlineOutcome = repo.searchAuthorizedOnlineTracks("synth")
        assertTrue(offlineOutcome.isOffline)
        assertNotNull(offlineOutcome.errorMessage)
    }
}
