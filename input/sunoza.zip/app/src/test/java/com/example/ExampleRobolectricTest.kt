package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ListeningEventEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.SavedMixEntity
import com.example.data.local.SeedCatalog
import com.example.data.local.SunozaDatabase
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import com.example.model.TransitionFilterType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.remote.ArchiveMetadataResponse
import com.example.data.remote.ArchiveOrgApi
import com.example.data.remote.ArchiveSearchResponse
import com.example.data.remote.AudiusApi
import com.example.data.remote.AudiusArtworkDto
import com.example.data.remote.AudiusTrackDto
import com.example.data.remote.AudiusTracksResponse
import com.example.data.remote.AudiusUserDto
import com.example.data.remote.ItunesSearchApi
import com.example.data.remote.ItunesSearchResponse
import com.example.data.remote.ItunesTrackDto
import com.example.data.repository.MusicRepository
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowNetworkCapabilities
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.unit.dp
import com.example.data.remote.ArchiveFileDto
import com.example.data.remote.ArchiveItemMetadataDto
import com.example.data.remote.OnlineTrackCandidate
import com.example.ui.SunozaUiState
import com.example.ui.components.OnlineScreen
import com.example.ui.theme.SunozaTheme
import org.junit.Rule
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var db: SunozaDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, SunozaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun appName_isSunoza() {
        assertEquals("Sunoza", context.getString(R.string.app_name))
    }

    @Test
    fun authorizedSourceValidator_enforcesCommercialSafeAndHonestVerificationStatus() {
        val allowedArchive = AuthorizedSourceValidator.validateUrl(
            "https://archive.org/download/test_item/track.mp3",
            "https://creativecommons.org/licenses/by/4.0/",
        )
        assertTrue(allowedArchive is SourceValidationResult.Authorized)
        assertTrue((allowedArchive as SourceValidationResult.Authorized).isLicenseVerified)

        val unverifiedManualUrl = AuthorizedSourceValidator.validateUrl(
            "https://archive.org/download/test_item/track.mp3",
        )
        assertTrue(unverifiedManualUrl is SourceValidationResult.Authorized)
        val unverified = unverifiedManualUrl as SourceValidationResult.Authorized
        assertFalse(unverified.isLicenseVerified)
        assertFalse(unverified.licenseName.contains("Creative Commons", ignoreCase = true))

        val blockedNc = AuthorizedSourceValidator.validateUrl(
            "https://archive.org/download/test_item/nc_track.mp3",
            "https://creativecommons.org/licenses/by-nc-sa/4.0/",
        )
        assertTrue(blockedNc is SourceValidationResult.Rejected)

        val blockedAllRights = AuthorizedSourceValidator.validateUrl(
            "https://api.audius.co/v1/tracks/abc123/stream?app_name=SUNOZA",
            "All Rights Reserved",
        )
        assertTrue(blockedAllRights is SourceValidationResult.Rejected)

        val allowedAudius = AuthorizedSourceValidator.validateUrl(
            "https://api.audius.co/v1/tracks/abc123/stream?app_name=SUNOZA",
            "Artist Authorized Stream",
        )
        assertTrue(allowedAudius is SourceValidationResult.Authorized)
        assertFalse((allowedAudius as SourceValidationResult.Authorized).isLicenseVerified)

        val allowedItunes = AuthorizedSourceValidator.validateUrl(
            "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview125/v4/11/22/33/sample.m4a",
            "Official 30s Preview",
        )
        assertTrue(allowedItunes is SourceValidationResult.Authorized)
        assertFalse((allowedItunes as SourceValidationResult.Authorized).isLicenseVerified)

        val blockedHttp = AuthorizedSourceValidator.validateUrl(
            "http://archive.org/download/test_item/track.mp3",
        )
        assertTrue(blockedHttp is SourceValidationResult.Rejected)

        val blockedDomain = AuthorizedSourceValidator.validateUrl(
            "https://unauthorized-pirate-site.example.com/song.mp3",
        )
        assertTrue(blockedDomain is SourceValidationResult.Rejected)
    }

    @Test
    fun roomDao_seedsTracksAndManagesOrderedPlaylistsMixesAndHistory() = runTest {
        val dao = db.sunozaDao()
        val seedSongs = SeedCatalog.buildSeedSongs(context)
        val insertedIds = dao.insertSongs(seedSongs)
        assertEquals(4, insertedIds.size)

        val playlistId = dao.insertPlaylist(PlaylistEntity(name = "Night Drive"))
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = insertedIds[0], position = 0))
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = insertedIds[1], position = 1))

        // Verify metadata update preserves playlist cross-refs
        dao.updateSongMetadata(
            songId = insertedIds[0],
            artworkUri = "https://archive.org/services/img/test",
            album = "Updated Album",
            genre = "Synthwave",
        )

        // Verify reordering works
        dao.updatePlaylistOrder(playlistId, listOf(insertedIds[1], insertedIds[0]))
        val refs = dao.observePlaylistCrossRefs().first().filter { it.playlistId == playlistId }
        assertEquals(listOf(insertedIds[1], insertedIds[0]), refs.map { it.songId })
        val updatedSong = dao.observeAllSongs().first().firstOrNull { it.id == insertedIds[0] }
        assertEquals("https://archive.org/services/img/test", updatedSong?.artworkUri)
        assertEquals("Updated Album", updatedSong?.album)

        // Verify saved mixes and listening history
        dao.insertSavedMix(
            SavedMixEntity(
                name = "Sunset Blend",
                deckASongId = insertedIds[0],
                deckBSongId = insertedIds[1],
                crossfader = 0.5f,
                transitionDurationSec = 8,
                filterType = TransitionFilterType.ECHO_FADE.name,
                echoAmount = 0.4f,
                autoMixEnabled = true,
            )
        )
        val mixes = dao.observeSavedMixes().first()
        assertEquals(1, mixes.size)
        assertEquals("Sunset Blend", mixes.first().name)

        dao.insertListeningEvent(ListeningEventEntity(songId = insertedIds[0], sourceType = "BUNDLED"))
        assertEquals(1, dao.observeRecentListeningEvents().first().size)

        dao.setFavorite(insertedIds.last(), true)
        val favorites = dao.observeFavoriteSongs().first()
        assertTrue(favorites.any { it.id == insertedIds.last() })
    }

    @Test
    fun musicRepository_testsMultipleSearchTermsPaginationFullTracksPreviewsAndErrors() = runTest {
        val dao = db.sunozaDao()
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNet = cm.activeNetwork
        if (activeNet != null) {
            val caps = ShadowNetworkCapabilities.newInstance()
            Shadows.shadowOf(caps).addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            Shadows.shadowOf(cm).setNetworkCapabilities(activeNet, caps)
        }

        val fakeArchive = object : ArchiveOrgApi {
            override suspend fun searchAudio(
                query: String,
                fields: List<String>,
                rows: Int,
                page: Int,
                output: String,
            ): ArchiveSearchResponse {
                val id = if (query.contains("acoustic", ignoreCase = true)) "ia-acoustic" else "ia-synth"
                return ArchiveSearchResponse(
                    response = com.example.data.remote.ArchiveSearchInner(
                        numFound = 12,
                        docs = listOf(
                            com.example.data.remote.ArchiveDocDto(
                                identifier = "$id-p$page",
                                title = if (id == "ia-acoustic") "Acoustic Horizon $page" else "Ambient Pulse $page",
                                creator = "CC Musician",
                                licenseUrl = "https://creativecommons.org/licenses/by/4.0/",
                            ),
                            com.example.data.remote.ArchiveDocDto(
                                identifier = "dark-item",
                                title = "Removed Item",
                                creator = "Hidden",
                                licenseUrl = "https://creativecommons.org/licenses/by/4.0/",
                            ),
                        ),
                    )
                )
            }

            override suspend fun getItemMetadata(identifier: String): ArchiveMetadataResponse {
                if (identifier == "dark-item") {
                    return ArchiveMetadataResponse(isDark = true)
                }
                return ArchiveMetadataResponse(
                    isDark = false,
                    metadata = ArchiveItemMetadataDto(album = "Open Netlabel Vol. 1"),
                    files = listOf(
                        ArchiveFileDto(name = "track_full.mp3", length = "04:05", private = false),
                    ),
                )
            }
        }

        val fakeAudius = object : AudiusApi {
            override suspend fun getTrendingTracks(appName: String, limit: Int, offset: Int) =
                searchTracks("trending", appName, limit, offset)

            override suspend fun searchTracks(query: String, appName: String, limit: Int, offset: Int): AudiusTracksResponse {
                val items = (0 until limit).map { idx ->
                    val globalIdx = offset + idx
                    AudiusTrackDto(
                        id = "aud-${query.lowercase().replace(' ', '_')}-$globalIdx",
                        title = "$query Track #$globalIdx",
                        genre = "Electronic",
                        duration = 228 + idx,
                        isStreamable = true,
                        artwork = AudiusArtworkDto(medium = "https://cdn.audius.co/$globalIdx.jpg"),
                        user = AudiusUserDto(name = "Audius Artist $globalIdx"),
                    )
                }
                return AudiusTracksResponse(data = items)
            }
        }

        val fakeItunes = object : ItunesSearchApi {
            override suspend fun searchSongs(term: String, media: String, entity: String, limit: Int, offset: Int) =
                ItunesSearchResponse(
                    resultCount = 1,
                    results = listOf(
                        ItunesTrackDto(
                            trackId = 900L + offset,
                            trackName = "$term Radio Sample",
                            artistName = "Label Artist",
                            collectionName = "Orbit Album",
                            previewUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/sample_$offset.m4a",
                            artworkUrl100 = "https://is1-ssl.mzstatic.com/100x100bb.jpg",
                            primaryGenreName = "Pop",
                            trackTimeMillis = 214_000L,
                        )
                    )
                )
        }

        val repo = MusicRepository(context, dao, fakeArchive, fakeAudius, fakeItunes)

        // Search term 1: "synthwave"
        val synthPage0 = repo.searchAuthorizedOnlineTracks("synthwave", page = 0)
        assertFalse(synthPage0.isOffline)
        assertNull(synthPage0.errorMessage)
        assertTrue(synthPage0.hasMore)
        val fullTracks = synthPage0.tracks.filterNot { it.isPreviewOnly }
        val previews = synthPage0.tracks.filter { it.isPreviewOnly }
        assertTrue(fullTracks.isNotEmpty())
        assertTrue(previews.isNotEmpty())
        // Full tracks play > 30s and come before preview-only tracks
        assertTrue(fullTracks.all { it.durationMs > 30_000L })
        assertTrue(previews.all { it.durationMs == 30_000L && it.isPreviewOnly })
        assertFalse(synthPage0.tracks.first().isPreviewOnly)
        assertTrue(synthPage0.tracks.none { it.id.contains("dark-item") })

        // Verify pagination page 1 appends fresh results without duplicates
        val synthPage1 = repo.searchAuthorizedOnlineTracks("synthwave", page = 1)
        val merged = MusicRepository.mergeAndDeduplicateCandidates(synthPage0.tracks, synthPage1.tracks)
        assertTrue(merged.size > synthPage0.tracks.size)
        assertEquals(merged.distinctBy { it.streamUrl }.size, merged.size)

        // Search term 2: "acoustic"
        val acousticRes = repo.searchAuthorizedOnlineTracks("acoustic", page = 0)
        assertTrue(acousticRes.tracks.any { it.title.contains("acoustic", ignoreCase = true) })
        assertTrue(acousticRes.tracks.any { it.providerName == "Internet Archive Audio" && it.durationMs == 245_000L })

        // Search term 3: verify persisted full track vs preview Song properties
        val fullSong = repo.addAuthorizedOnlineCandidate(fullTracks.first()).getOrThrow()
        assertFalse(fullSong.isPreviewOnly)
        assertTrue(fullSong.durationMs > 30_000L)

        val previewSong = repo.addAuthorizedOnlineCandidate(previews.first()).getOrThrow()
        assertTrue(previewSong.isPreviewOnly)
        assertEquals(30_000L, previewSong.durationMs)

        // Failing API servers should surface clear error message
        val failingAudius = object : AudiusApi {
            override suspend fun getTrendingTracks(appName: String, limit: Int, offset: Int) = throw IOException("503 Unavailable")
            override suspend fun searchTracks(query: String, appName: String, limit: Int, offset: Int) = throw IOException("503 Unavailable")
        }
        val failingArchive = object : ArchiveOrgApi {
            override suspend fun searchAudio(query: String, fields: List<String>, rows: Int, page: Int, output: String) = throw IOException("503")
            override suspend fun getItemMetadata(identifier: String) = throw IOException("503")
        }
        val failingItunes = object : ItunesSearchApi {
            override suspend fun searchSongs(term: String, media: String, entity: String, limit: Int, offset: Int) = throw IOException("Timeout")
        }
        val failingRepo = MusicRepository(context, dao, failingArchive, failingAudius, failingItunes)
        val failureOutcome = failingRepo.searchAuthorizedOnlineTracks("ambient", page = 0)
        assertNotNull(failureOutcome.errorMessage)
        assertTrue(failureOutcome.errorMessage!!.contains("unavailable", ignoreCase = true))

        // Offline state reports isOffline = true cleanly
        Shadows.shadowOf(cm).setDefaultNetworkActive(false)
        if (activeNet != null) {
            Shadows.shadowOf(cm).setNetworkCapabilities(activeNet, null)
        }
        val offlineOutcome = repo.searchAuthorizedOnlineTracks("synth", page = 0)
        assertTrue(offlineOutcome.isOffline)
        assertNotNull(offlineOutcome.errorMessage)
    }

    @Test
    fun onlineScreen_showsFullVsPreviewFiltersLoadMoreAndErrors() {
        val fullTrack = OnlineTrackCandidate(
            id = "audius-full-1",
            title = "Deep Orbit",
            artist = "Kairo",
            album = "Single · Synthwave",
            streamUrl = "https://api.audius.co/v1/tracks/full1/stream?app_name=SUNOZA",
            durationMs = 240_000L,
            providerName = "Audius Open Catalog",
            licenseName = "Artist Authorized Stream",
            isPreviewOnly = false,
        )
        val previewTrack = OnlineTrackCandidate(
            id = "itunes-prev-1",
            title = "Radio Snippet",
            artist = "Label Star",
            album = "Greatest Hits",
            streamUrl = "https://audio-ssl.itunes.apple.com/prev1.m4a",
            durationMs = 30_000L,
            fullTrackDurationMs = 205_000L,
            providerName = "Apple iTunes Preview",
            licenseName = "Apple iTunes 30s Preview (Promotional Only)",
            isPreviewOnly = true,
            externalStoreUrl = "https://music.apple.com/us/album/prev1",
            attributionText = "Provided courtesy of iTunes",
        )

        var loadMoreClicks = 0
        var playedId: String? = null
        var inspectedId: String? = null

        composeRule.setContent {
            SunozaTheme {
                OnlineScreen(
                    uiState = SunozaUiState(
                        isReady = true,
                        onlineCandidates = listOf(fullTrack, previewTrack),
                        canLoadMoreOnline = true,
                        onlineErrorMessage = "Partial server error",
                    ),
                    onSearchQueryChange = {},
                    onSearchSubmit = {},
                    onLoadMore = { loadMoreClicks++ },
                    onPlayCandidate = { playedId = it.id },
                    onAddCandidateToPlaylist = {},
                    onPlayPlaylistPack = {},
                    onPlaySong = {},
                    onToggleFavorite = {},
                    onOpenAuthorizedUrlDialog = {},
                    onInspectAttribution = { inspectedId = it.id },
                )
            }
        }
        composeRule.waitForIdle()

        // Error banner, full track, preview badge, iTunes courtesy attribution, and load more button are displayed
        composeRule.onNodeWithTag("online_error_banner").assertIsDisplayed()
        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_track_audius-full-1"))
        composeRule.onNodeWithTag("online_track_audius-full-1").assertIsDisplayed()

        // Tapping info button invokes attribution inspector callback
        composeRule.onNodeWithTag("online_info_button_audius-full-1", useUnmergedTree = true).performClick()
        composeRule.waitForIdle()
        assertEquals("audius-full-1", inspectedId)

        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_track_itunes-prev-1"))
        composeRule.onNodeWithTag("online_track_itunes-prev-1").assertIsDisplayed()
        composeRule.onNodeWithTag("preview_badge_itunes-prev-1", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithTag("itunes_store_badge_itunes-prev-1", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("Preview Only · 30s Samples").assertIsDisplayed()

        // Filter to Full Tracks only: preview row disappears
        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_filter_full_tracks"))
        composeRule.onNodeWithTag("online_filter_full_tracks").performClick()
        composeRule.waitForIdle()
        assertEquals(0, composeRule.onAllNodesWithTag("online_track_itunes-prev-1").fetchSemanticsNodes().size)
        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_track_audius-full-1"))
        composeRule.onNodeWithTag("online_track_audius-full-1").assertIsDisplayed()

        // Tapping the full track invokes playback with the exact candidate ID
        composeRule.onNodeWithTag("online_track_audius-full-1").performClick()
        composeRule.waitForIdle()
        assertEquals("audius-full-1", playedId)

        // Filter to Previews only: full track disappears and preview track returns
        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_filter_previews"))
        composeRule.onNodeWithTag("online_filter_previews").performClick()
        composeRule.waitForIdle()
        assertEquals(0, composeRule.onAllNodesWithTag("online_track_audius-full-1").fetchSemanticsNodes().size)
        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_track_itunes-prev-1"))
        composeRule.onNodeWithTag("online_track_itunes-prev-1").assertIsDisplayed()

        // Verify Load More callback fires
        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_load_more_button"))
        composeRule.onNodeWithTag("online_load_more_button").performClick()
        composeRule.waitForIdle()
        assertEquals(1, loadMoreClicks)
    }

    @Test
    fun musicRepository_surfacesWarningWhenFullCatalogsFailAndExcludesShortAndNonCommercialTracks() = runTest {
        val dao = db.sunozaDao()
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNet = cm.activeNetwork
        if (activeNet != null) {
            val caps = ShadowNetworkCapabilities.newInstance()
            Shadows.shadowOf(caps).addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            Shadows.shadowOf(cm).setNetworkCapabilities(activeNet, caps)
        }

        // Insert a legacy iTunes row with bogus durationMs=210_000 and verify ensureSeeded() normalizes it to 30s Preview Only
        val legacyId = dao.insertSong(
            com.example.data.local.SongEntity(
                title = "Legacy iTunes Sample",
                artist = "Label Star",
                audioUri = "https://audio-ssl.itunes.apple.com/legacy/sample.m4a",
                durationMs = 210_000L,
                backgroundColorArgb = 0xFF221F33L,
                sourceType = com.example.model.SourceType.AUTHORIZED_ONLINE.name,
                sourceLabel = "Apple iTunes Preview",
                licenseName = "Streaming",
                isFavorite = false,
                lyricsRaw = "",
                addedAtMs = 1_000L,
                mood = "Streaming",
            )
        )

        val failingAudius = object : AudiusApi {
            override suspend fun getTrendingTracks(appName: String, limit: Int, offset: Int) = throw IOException("Audius 503")
            override suspend fun searchTracks(query: String, appName: String, limit: Int, offset: Int) = throw IOException("Audius 503")
        }
        val emptyArchive = object : ArchiveOrgApi {
            override suspend fun searchAudio(query: String, fields: List<String>, rows: Int, page: Int, output: String) =
                ArchiveSearchResponse()
            override suspend fun getItemMetadata(identifier: String) = ArchiveMetadataResponse()
        }
        val workingItunes = object : ItunesSearchApi {
            override suspend fun searchSongs(term: String, media: String, entity: String, limit: Int, offset: Int) =
                ItunesSearchResponse(
                    resultCount = 1,
                    results = listOf(
                        ItunesTrackDto(
                            trackId = 111L,
                            trackName = "Mainstream Hit",
                            artistName = "Pop Artist",
                            previewUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/sample_hit.m4a",
                            trackViewUrl = "https://music.apple.com/us/album/mainstream-hit",
                            trackTimeMillis = 205_000L,
                        )
                    )
                )
        }

        val partialFailRepo = MusicRepository(context, dao, emptyArchive, failingAudius, workingItunes)
        partialFailRepo.ensureSeeded()
        val normalizedLegacy = dao.observeAllSongs().first().first { it.id == legacyId }.toDomain()
        assertEquals(30_000L, normalizedLegacy.durationMs)
        assertTrue(normalizedLegacy.isPreviewOnly)
        assertEquals("Provided courtesy of iTunes", normalizedLegacy.attributionText)

        val outcome = partialFailRepo.searchAuthorizedOnlineTracks("Mainstream Hit", page = 0)
        assertNotNull(outcome.errorMessage)
        assertTrue(outcome.errorMessage!!.contains("30-second iTunes previews", ignoreCase = true))
        assertTrue(outcome.tracks.all { it.isPreviewOnly })
        assertEquals("https://music.apple.com/us/album/mainstream-hit", outcome.tracks.first().externalStoreUrl)
        assertEquals("Provided courtesy of iTunes", outcome.tracks.first().attributionText)

        // Verify short <=30s and NC Audius tracks and NC / missing-license Archive tracks are excluded
        val filteredArchive = object : ArchiveOrgApi {
            override suspend fun searchAudio(query: String, fields: List<String>, rows: Int, page: Int, output: String) =
                ArchiveSearchResponse(
                    response = com.example.data.remote.ArchiveSearchInner(
                        numFound = 3,
                        docs = listOf(
                            com.example.data.remote.ArchiveDocDto(
                                identifier = "nc-item",
                                title = "NonCommercial Album",
                                creator = "NC Creator",
                                licenseUrl = "https://creativecommons.org/licenses/by-nc/4.0/",
                            ),
                            com.example.data.remote.ArchiveDocDto(
                                identifier = "nolicense-item",
                                title = "No License Album",
                                creator = "Unknown",
                                licenseUrl = null,
                            ),
                            com.example.data.remote.ArchiveDocDto(
                                identifier = "ccby-item",
                                title = "Commercial Safe Track",
                                creator = "Indie Artist",
                                licenseUrl = "https://creativecommons.org/licenses/by/4.0/",
                            ),
                        )
                    )
                )

            override suspend fun getItemMetadata(identifier: String) = ArchiveMetadataResponse(
                isDark = false,
                metadata = ArchiveItemMetadataDto(
                    licenseUrl = when (identifier) {
                        "nc-item" -> "https://creativecommons.org/licenses/by-nc/4.0/"
                        "ccby-item" -> "https://creativecommons.org/licenses/by/4.0/"
                        else -> null
                    }
                ),
                files = listOf(ArchiveFileDto(name = "song.mp3", length = "200.0", private = false)),
            )
        }
        val shortAndNcAudius = object : AudiusApi {
            override suspend fun getTrendingTracks(appName: String, limit: Int, offset: Int) = searchTracks("", appName, limit, offset)
            override suspend fun searchTracks(query: String, appName: String, limit: Int, offset: Int) = AudiusTracksResponse(
                data = listOf(
                    AudiusTrackDto(id = "short30", title = "Too Short 25s", duration = 25, isStreamable = true),
                    AudiusTrackDto(id = "ncaud", title = "NC Audius Track", duration = 180, ccLicense = "by-nc", isStreamable = true),
                    AudiusTrackDto(id = "long210", title = "Real Full Song", duration = 210, permalink = "/indie/real-full-song", isStreamable = true),
                )
            )
        }
        val repoWithFilters = MusicRepository(context, dao, filteredArchive, shortAndNcAudius, workingItunes)
        val filteredOutcome = repoWithFilters.searchAuthorizedOnlineTracks("Real Full Song", page = 0)
        assertTrue(filteredOutcome.tracks.none { it.id == "audius-short30" || it.id == "audius-ncaud" })
        assertTrue(filteredOutcome.tracks.none { it.id.contains("nc-item") || it.id.contains("nolicense-item") })
        val validAudius = filteredOutcome.tracks.firstOrNull { it.id == "audius-long210" }
        assertNotNull(validAudius)
        assertEquals(210_000L, validAudius!!.durationMs)
        assertEquals("https://audius.co/indie/real-full-song", validAudius.sourcePageUrl)
        val validArchive = filteredOutcome.tracks.firstOrNull { it.id.contains("ccby-item") }
        assertNotNull(validArchive)
        assertTrue(validArchive!!.isLicenseVerified)

        // Verify copyright/content report blocks reported stream locally
        repoWithFilters.reportTrack(
            streamUrl = validArchive.streamUrl,
            title = validArchive.title,
            artist = validArchive.artist,
            providerName = validArchive.providerName,
            reason = "Copyright / DMCA Takedown",
            reporterEmail = "rights@example.com",
            details = "Takedown request",
        )
        val postReportOutcome = repoWithFilters.searchAuthorizedOnlineTracks("Real Full Song", page = 0)
        assertTrue(postReportOutcome.tracks.none { it.streamUrl == validArchive.streamUrl })
        assertTrue(repoWithFilters.verifyPlayableCandidate(validArchive).isFailure)
    }

    @Test
    fun roomDatabase_migration2To3_preservesExistingSongsAndCreatesReportedTracksTable() = runTest {
        val dbName = "migration_test_sunoza.db"
        context.deleteDatabase(dbName)
        val openHelper = androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(
            androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbName)
                .callback(object : androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(2) {
                    override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        db.execSQL(
                            """
                            CREATE TABLE IF NOT EXISTS `songs` (
                                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                `title` TEXT NOT NULL,
                                `artist` TEXT NOT NULL,
                                `audioUri` TEXT NOT NULL,
                                `durationMs` INTEGER NOT NULL,
                                `backgroundColorArgb` INTEGER NOT NULL,
                                `sourceType` TEXT NOT NULL,
                                `sourceLabel` TEXT NOT NULL,
                                `licenseName` TEXT NOT NULL,
                                `isFavorite` INTEGER NOT NULL,
                                `lyricsRaw` TEXT NOT NULL,
                                `addedAtMs` INTEGER NOT NULL,
                                `album` TEXT NOT NULL,
                                `artworkUri` TEXT,
                                `folderName` TEXT NOT NULL,
                                `genre` TEXT NOT NULL,
                                `bpm` INTEGER NOT NULL,
                                `energyScore` REAL NOT NULL,
                                `mood` TEXT NOT NULL,
                                `playCount` INTEGER NOT NULL,
                                `lastPlayedAtMs` INTEGER NOT NULL,
                                `mediaStoreId` INTEGER
                            )
                            """.trimIndent()
                        )
                        db.execSQL(
                            """
                            CREATE TABLE IF NOT EXISTS `playlists` (
                                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                `name` TEXT NOT NULL,
                                `createdAtMs` INTEGER NOT NULL
                            )
                            """.trimIndent()
                        )
                        db.execSQL(
                            """
                            CREATE TABLE IF NOT EXISTS `playlist_song_cross_ref` (
                                `playlistId` INTEGER NOT NULL,
                                `songId` INTEGER NOT NULL,
                                `position` INTEGER NOT NULL,
                                `addedAtMs` INTEGER NOT NULL,
                                PRIMARY KEY(`playlistId`, `songId`),
                                FOREIGN KEY(`playlistId`) REFERENCES `playlists`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE,
                                FOREIGN KEY(`songId`) REFERENCES `songs`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                            )
                            """.trimIndent()
                        )
                        db.execSQL(
                            "CREATE INDEX IF NOT EXISTS `index_playlist_song_cross_ref_playlistId` ON `playlist_song_cross_ref` (`playlistId`)"
                        )
                        db.execSQL(
                            "CREATE INDEX IF NOT EXISTS `index_playlist_song_cross_ref_songId` ON `playlist_song_cross_ref` (`songId`)"
                        )
                        db.execSQL(
                            """
                            CREATE TABLE IF NOT EXISTS `listening_events` (
                                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                `songId` INTEGER NOT NULL,
                                `playedAtMs` INTEGER NOT NULL,
                                `sourceType` TEXT NOT NULL
                            )
                            """.trimIndent()
                        )
                        db.execSQL(
                            """
                            CREATE TABLE IF NOT EXISTS `saved_mixes` (
                                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                `name` TEXT NOT NULL,
                                `deckASongId` INTEGER NOT NULL,
                                `deckBSongId` INTEGER NOT NULL,
                                `crossfader` REAL NOT NULL,
                                `transitionDurationSec` INTEGER NOT NULL,
                                `filterType` TEXT NOT NULL,
                                `echoAmount` REAL NOT NULL,
                                `autoMixEnabled` INTEGER NOT NULL,
                                `createdAtMs` INTEGER NOT NULL
                            )
                            """.trimIndent()
                        )
                        db.execSQL(
                            """
                            INSERT INTO `songs` (
                                `id`, `title`, `artist`, `audioUri`, `durationMs`, `backgroundColorArgb`,
                                `sourceType`, `sourceLabel`, `licenseName`, `isFavorite`, `lyricsRaw`,
                                `addedAtMs`, `album`, `artworkUri`, `folderName`, `genre`, `bpm`,
                                `energyScore`, `mood`, `playCount`, `lastPlayedAtMs`, `mediaStoreId`
                            ) VALUES (
                                77, 'Preserved Track', 'Legacy Artist', 'https://archive.org/download/a/b.mp3',
                                195000, 4280427059, 'AUTHORIZED_ONLINE', 'Internet Archive Audio',
                                'CC BY', 1, '', 1000, 'Archive Album', NULL, 'Online', 'Ambient',
                                100, 0.6, 'Streaming', 3, 2000, NULL
                            )
                            """.trimIndent()
                        )
                    }

                    override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
                })
                .build()
        )
        openHelper.writableDatabase.close()

        val migratedDb = Room.databaseBuilder(context, SunozaDatabase::class.java, dbName)
            .addMigrations(SunozaDatabase.MIGRATION_1_2, SunozaDatabase.MIGRATION_2_3)
            .allowMainThreadQueries()
            .build()
        try {
            val songs = migratedDb.sunozaDao().observeAllSongs().first()
            assertEquals(1, songs.size)
            assertEquals("Preserved Track", songs.first().title)
            assertFalse(songs.first().isLicenseVerified)

            migratedDb.sunozaDao().insertReportedTrack(
                com.example.data.local.ReportedTrackEntity(
                    streamUrl = "https://archive.org/download/a/b.mp3",
                    title = "Preserved Track",
                    artist = "Legacy Artist",
                    providerName = "Internet Archive Audio",
                    reason = "Copyright / DMCA Takedown",
                )
            )
            assertEquals(1, migratedDb.sunozaDao().observeReportedTracks().first().size)
        } finally {
            migratedDb.close()
            context.deleteDatabase(dbName)
        }
    }

    @Test
    fun onlineScreen_displaysNoFullTracksWarningWhenOnlyPreviewsExist() {
        val previewOnly = OnlineTrackCandidate(
            id = "itunes-only-1",
            title = "Preview Song",
            artist = "Pop Star",
            album = "Hit Single",
            streamUrl = "https://audio-ssl.itunes.apple.com/only_prev.m4a",
            durationMs = 30_000L,
            fullTrackDurationMs = 200_000L,
            providerName = "Apple iTunes Preview",
            licenseName = "Apple iTunes 30s Preview (Promotional Only)",
            isPreviewOnly = true,
            externalStoreUrl = "https://music.apple.com/us/album/only-prev",
            attributionText = "Provided courtesy of iTunes",
        )

        composeRule.setContent {
            SunozaTheme {
                OnlineScreen(
                    uiState = SunozaUiState(
                        isReady = true,
                        onlineSearchQuery = "Pop Star",
                        onlineCandidates = listOf(previewOnly),
                    ),
                    onSearchQueryChange = {},
                    onSearchSubmit = {},
                    onLoadMore = {},
                    onPlayCandidate = {},
                    onAddCandidateToPlaylist = {},
                    onPlayPlaylistPack = {},
                    onPlaySong = {},
                    onToggleFavorite = {},
                    onOpenAuthorizedUrlDialog = {},
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_no_full_tracks_notice"))
        composeRule.onNodeWithTag("online_no_full_tracks_notice").assertIsDisplayed()

        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_filter_full_tracks"))
        composeRule.onNodeWithTag("online_filter_full_tracks").performClick()
        composeRule.waitForIdle()

        assertEquals(0, composeRule.onAllNodesWithTag("online_track_itunes-only-1").fetchSemanticsNodes().size)
        composeRule.onNodeWithTag("online_screen")
            .performScrollToNode(androidx.compose.ui.test.hasTestTag("online_empty_state"))
        composeRule.onNodeWithTag("online_empty_state").assertIsDisplayed()
    }

    @Test
    fun officialSunozaLogo_assetsResolveAndBrandMarkRenders() {
        assertNotNull(androidx.core.content.ContextCompat.getDrawable(context, R.drawable.ic_sunoza_logo))
        assertNotNull(androidx.core.content.ContextCompat.getDrawable(context, R.drawable.ic_splash_logo))
        assertNotNull(androidx.core.content.ContextCompat.getDrawable(context, R.drawable.ic_launcher_foreground))
        assertNotNull(androidx.core.content.ContextCompat.getDrawable(context, R.mipmap.ic_launcher))
        assertNotNull(androidx.core.content.ContextCompat.getDrawable(context, R.mipmap.ic_launcher_round))

        composeRule.setContent {
            SunozaTheme {
                com.example.ui.components.SunozaBrandMark(size = 48.dp)
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("sunoza_brand_mark").assertIsDisplayed()
    }

    @Test
    fun playerControlsAndMiniPlayer_showShuffleStatusStopAndActualNextSong() {
        var shuffleToggles = 0
        var stopClicks = 0
        var shuffleFlag = true

        composeRule.setContent {
            SunozaTheme {
                val sampleSong = com.example.model.Song(
                    id = 1L,
                    title = "Midnight Echoes",
                    artist = "Aarav Sen",
                    audioUri = "asset:///midnight.mp3",
                    durationMs = 180_000L,
                    backgroundColorArgb = 0xFF1F2233L,
                    sourceType = com.example.model.SourceType.BUNDLED,
                    sourceLabel = "Built-in Sample",
                    licenseName = "Original Demo",
                    isFavorite = false,
                    lyricsRaw = "",
                    addedAtMs = 1_000L,
                )
                val upNextSong = sampleSong.copy(id = 2L, title = "Velvet Horizon", artist = "Mira Solis")
                androidx.compose.foundation.layout.Column {
                    com.example.ui.components.PlayerControlsPanel(
                        isPlaying = true,
                        isBuffering = false,
                        positionMs = 15_000L,
                        durationMs = 180_000L,
                        shuffleEnabled = shuffleFlag,
                        repeatMode = androidx.media3.common.Player.REPEAT_MODE_ALL,
                        onPlayPause = {},
                        onPrevious = {},
                        onNext = {},
                        onSeekTo = {},
                        onToggleShuffle = { shuffleToggles++ },
                        onCycleRepeat = {},
                        onStopPlayback = { stopClicks++ },
                        isExplicitlyStopped = false,
                    )
                    com.example.ui.components.MiniPlayerBar(
                        song = sampleSong,
                        playback = com.example.player.PlaybackState(
                            isConnected = true,
                            currentSongId = 1L,
                            nextSongId = 2L,
                            isPlaying = true,
                            shuffleEnabled = true,
                        ),
                        onExpand = {},
                        onTogglePlayPause = {},
                        onNext = {},
                        nextSong = upNextSong,
                    )
                }
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("shuffle_button").assertIsDisplayed()
        composeRule.onNodeWithTag("shuffle_status_chip").assertIsDisplayed()
        composeRule.onNodeWithText("Shuffle ON").assertIsDisplayed()
        composeRule.onNodeWithTag("stop_playback_button").assertIsDisplayed()
        composeRule.onNodeWithTag("mini_player_next_song", useUnmergedTree = true).assertIsDisplayed()
        composeRule.onNodeWithText("Shuffle: Velvet Horizon", useUnmergedTree = true).assertIsDisplayed()

        composeRule.onNodeWithTag("shuffle_button").performClick()
        composeRule.onNodeWithTag("stop_playback_button").performClick()
        composeRule.waitForIdle()

        assertEquals(1, shuffleToggles)
        assertEquals(1, stopClicks)
    }

    @Test
    fun playbackController_defaultsToShuffleOnExcludesPreviewsAndRespectsExplicitStop() {
        val controller = com.example.player.PlaybackController(context)
        val offline = com.example.model.Song(
            id = 11L,
            title = "Device Groove",
            artist = "Local Artist",
            audioUri = "asset:///local.mp3",
            durationMs = 190_000L,
            backgroundColorArgb = 0xFF1A1F2CL,
            sourceType = com.example.model.SourceType.OFFLINE_LOCAL,
            sourceLabel = "Device Audio",
            licenseName = "Local Device File",
            isFavorite = false,
            lyricsRaw = "",
            addedAtMs = 1_000L,
        )
        val preview = offline.copy(
            id = 12L,
            title = "Preview Clip",
            audioUri = "https://audio-ssl.itunes.apple.com/prev.m4a",
            sourceType = com.example.model.SourceType.AUTHORIZED_ONLINE,
            licenseName = "Preview Only (30s)",
            durationMs = 30_000L,
        )
        val onlineFull = offline.copy(
            id = 13L,
            title = "Audius Full Song",
            audioUri = "https://api.audius.co/v1/tracks/full99/stream?app_name=SUNOZA",
            sourceType = com.example.model.SourceType.AUTHORIZED_ONLINE,
            licenseName = "Artist Authorized Stream",
            durationMs = 240_000L,
        )

        controller.syncQueue(listOf(offline, preview, onlineFull), selectSongId = offline.id, autoPlay = false)
        assertTrue(controller.state.value.shuffleEnabled)
        assertEquals(11L, controller.state.value.currentSongId)
        assertEquals(13L, controller.state.value.nextSongId)

        controller.toggleShuffle()
        assertFalse(controller.state.value.shuffleEnabled)
        // Sequential order skips preview 12L and picks 13L
        assertEquals(13L, controller.state.value.nextSongId)

        controller.stopPlayback()
        assertTrue(controller.state.value.isExplicitlyStopped)
        assertFalse(controller.state.value.isPlaying)
        controller.release()
    }
}
