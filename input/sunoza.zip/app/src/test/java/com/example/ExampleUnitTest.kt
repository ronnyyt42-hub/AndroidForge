package com.example

import com.example.data.local.ListeningEventEntity
import com.example.data.repository.RecommendationEngine
import com.example.model.EqPreset
import com.example.model.LyricsParser
import com.example.model.PartyEnergyMode
import com.example.model.Song
import com.example.model.SongColorGenerator
import com.example.model.SourceType
import com.example.model.TenBandLabels
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun lyricsParser_parsesLrcAndFindsActiveLine() {
        val raw = """
            [00:06.00]Second line
            [00:00.00]First line
            [00:12.50]Third line
        """.trimIndent()

        val parsed = LyricsParser.parse(raw)
        assertEquals(3, parsed.size)
        assertEquals("First line", parsed[0].text)
        assertEquals(0L, parsed[0].timestampMs)
        assertEquals("Second line", parsed[1].text)
        assertEquals(6_000L, parsed[1].timestampMs)
        assertEquals("Third line", parsed[2].text)
        assertEquals(12_500L, parsed[2].timestampMs)

        assertEquals(0, LyricsParser.activeLineIndex(parsed, 1_500L))
        assertEquals(1, LyricsParser.activeLineIndex(parsed, 7_000L))
        assertEquals(2, LyricsParser.activeLineIndex(parsed, 13_000L))
    }

    @Test
    fun lyricsParser_autoSpacesPlainTextLyrics() {
        val raw = """
            Line one
            Line two
            Line three
        """.trimIndent()

        val parsed = LyricsParser.parse(raw, fallbackDurationMs = 15_000L)
        assertEquals(3, parsed.size)
        assertEquals(0L, parsed[0].timestampMs)
        assertEquals(5_000L, parsed[1].timestampMs)
        assertEquals(10_000L, parsed[2].timestampMs)
    }

    @Test
    fun songColorGenerator_createsOpaqueDistinctDarkColors() {
        val first = SongColorGenerator.nextSolidColorArgb()
        val second = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = first)

        assertEquals(0xFFL, (first shr 24) and 0xFFL)
        assertEquals(0xFFL, (second shr 24) and 0xFFL)
        assertNotEquals(first, second)
        assertTrue(first != 0L)
    }

    @Test
    fun eqPresets_haveAllSevenPresetsAndTenBands() {
        assertEquals(10, TenBandLabels.size)
        assertEquals(7, EqPreset.entries.size)
        EqPreset.entries.forEach { preset ->
            assertEquals(10, preset.bandsDb.size)
        }
        assertTrue(EqPreset.DEEP_BASS.bassBoost > EqPreset.NORMAL.bassBoost)
    }

    @Test
    fun recommendationEngine_personalizesAndBuildsPartyQueue() {
        val s1 = sampleSong(1L, "Midnight Pulse", "Sunoza Synth", "Electronic", 124, 0.88f, fav = true, plays = 4)
        val s2 = sampleSong(2L, "Night Rider", "Sunoza Synth", "Electronic", 126, 0.90f, fav = false, plays = 0)
        val s3 = sampleSong(3L, "Quiet Rain", "Velvet Strings", "Ambient", 72, 0.30f, fav = false, plays = 0)

        val snapshot = RecommendationEngine.buildRecommendations(
            allSongs = listOf(s1, s2, s3),
            currentSong = s1,
            recentEvents = listOf(ListeningEventEntity(songId = 1L, sourceType = "BUNDLED")),
        )

        assertEquals(2L, snapshot.similarToCurrent.first().id)
        assertEquals(2L, snapshot.smartPlayNext.first().id)

        val highEnergyQueue = RecommendationEngine.buildPartyQueue(s1, listOf(s1, s2, s3), PartyEnergyMode.HIGH_ENERGY)
        assertEquals(1L, highEnergyQueue[0].id)
        assertEquals(2L, highEnergyQueue[1].id)
    }

    private fun sampleSong(
        id: Long,
        title: String,
        artist: String,
        genre: String,
        bpm: Int,
        energy: Float,
        fav: Boolean,
        plays: Int,
    ): Song = Song(
        id = id,
        title = title,
        artist = artist,
        audioUri = "asset:///$id",
        durationMs = 180_000L,
        backgroundColorArgb = 0xFF1F2233L,
        sourceType = SourceType.BUNDLED,
        sourceLabel = "Built-in Sample",
        licenseName = "Original Demo",
        isFavorite = fav,
        lyricsRaw = "",
        addedAtMs = 1_000L,
        genre = genre,
        bpm = bpm,
        energyScore = energy,
        playCount = plays,
    )
}
