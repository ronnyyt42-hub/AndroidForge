package com.example

import com.example.data.local.ListeningEventEntity
import com.example.data.repository.RecommendationEngine
import com.example.model.EqPreset
import com.example.model.LyricsParser
import com.example.model.PartyEnergyMode
import com.example.model.Song
import com.example.model.SongColorGenerator
import com.example.model.SourceType
import com.example.model.TenBandLabels
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun lyricsParser_parsesLrcAndFindsActiveLine() {
        val raw = """
            [00:06.00]Second line
            [00:00.00]First line
            [00:12.50]Third line
        """.trimIndent()

        val parsed = LyricsParser.parse(raw)
        assertEquals(3, parsed.size)
        assertEquals("First line", parsed[0].text)
        assertEquals(0L, parsed[0].timestampMs)
        assertEquals("Second line", parsed[1].text)
        assertEquals(6_000L, parsed[1].timestampMs)
        assertEquals("Third line", parsed[2].text)
        assertEquals(12_500L, parsed[2].timestampMs)

        assertEquals(0, LyricsParser.activeLineIndex(parsed, 1_500L))
        assertEquals(1, LyricsParser.activeLineIndex(parsed, 7_000L))
        assertEquals(2, LyricsParser.activeLineIndex(parsed, 13_000L))
    }

    @Test
    fun lyricsParser_autoSpacesPlainTextLyrics() {
        val raw = """
            Line one
            Line two
            Line three
        """.trimIndent()

        val parsed = LyricsParser.parse(raw, fallbackDurationMs = 15_000L)
        assertEquals(3, parsed.size)
        assertEquals(0L, parsed[0].timestampMs)
        assertEquals(5_000L, parsed[1].timestampMs)
        assertEquals(10_000L, parsed[2].timestampMs)
    }

    @Test
    fun songColorGenerator_createsOpaqueDistinctDarkColors() {
        val first = SongColorGenerator.nextSolidColorArgb()
        val second = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = first)

        assertEquals(0xFFL, (first shr 24) and 0xFFL)
        assertEquals(0xFFL, (second shr 24) and 0xFFL)
        assertNotEquals(first, second)
        assertTrue(first != 0L)
    }

    @Test
    fun eqPresets_haveAllSevenPresetsAndTenBands() {
        assertEquals(10, TenBandLabels.size)
        assertEquals(7, EqPreset.entries.size)
        EqPreset.entries.forEach { preset ->
            assertEquals(10, preset.bandsDb.size)
        }
        assertTrue(EqPreset.DEEP_BASS.bassBoost > EqPreset.NORMAL.bassBoost)
    }

    @Test
    fun recommendationEngine_personalizesAndBuildsPartyQueue() {
        val s1 = sampleSong(1L, "Midnight Pulse", "Sunoza Synth", "Electronic", 124, 0.88f, fav = true, plays = 4)
        val s2 = sampleSong(2L, "Night Rider", "Sunoza Synth", "Electronic", 126, 0.90f, fav = false, plays = 0)
        val s3 = sampleSong(3L, "Quiet Rain", "Velvet Strings", "Ambient", 72, 0.30f, fav = false, plays = 0)

        val snapshot = RecommendationEngine.buildRecommendations(
            allSongs = listOf(s1, s2, s3),
            currentSong = s1,
            recentEvents = listOf(ListeningEventEntity(songId = 1L, sourceType = "BUNDLED")),
        )

        assertEquals(2L, snapshot.similarToCurrent.first().id)
        assertEquals(2L, snapshot.smartPlayNext.first().id)

        val highEnergyQueue = RecommendationEngine.buildPartyQueue(s1, listOf(s1, s2, s3), PartyEnergyMode.HIGH_ENERGY)
        assertEquals(1L, highEnergyQueue[0].id)
        assertEquals(2L, highEnergyQueue[1].id)
    }

    @Test
    fun onlineMusicDtos_resolveArtworkCorrectly() {
        val audiusArt = com.example.data.remote.AudiusArtworkDto(
            small = "https://cdn.audius.co/150.jpg",
            medium = "https://cdn.audius.co/480.jpg",
            large = "https://cdn.audius.co/1000.jpg",
        )
        assertEquals("https://cdn.audius.co/480.jpg", audiusArt.bestUrl())

        val itunesTrack = com.example.data.remote.ItunesTrackDto(
            trackId = 42L,
            trackName = "Synth Echo",
            artistName = "Artist",
            artworkUrl100 = "https://is1-ssl.mzstatic.com/image/thumb/Music/100x100bb.jpg",
        )
        assertEquals(
            "https://is1-ssl.mzstatic.com/image/thumb/Music/600x600bb.jpg",
            itunesTrack.highResArtworkUrl(),
        )
    }

    @Test
    fun onlineRanking_prioritizesFullTracksOverPreviewsAndDeduplicates() {
        val preview = com.example.data.remote.OnlineTrackCandidate(
            id = "itunes-1",
            title = "Midnight Echo",
            artist = "Nova",
            album = "Afterhours",
            streamUrl = "https://audio-ssl.itunes.apple.com/preview1.m4a",
            durationMs = 30_000L,
            fullTrackDurationMs = 215_000L,
            providerName = "Apple iTunes Preview",
            licenseName = "Preview Only (30s)",
            isPreviewOnly = true,
        )
        val audiusFull = com.example.data.remote.OnlineTrackCandidate(
            id = "audius-1",
            title = "Midnight Echo",
            artist = "Nova",
            album = "Single · Synthwave",
            streamUrl = "https://api.audius.co/v1/tracks/1/stream?app_name=SUNOZA",
            durationMs = 215_000L,
            providerName = "Audius Open Catalog",
            licenseName = "Artist Authorized Stream",
            isPreviewOnly = false,
        )
        val audiusDup = audiusFull.copy(id = "audius-1-dup")
        val archiveFull = com.example.data.remote.OnlineTrackCandidate(
            id = "ia-1",
            title = "Starlight Signal",
            artist = "Echo Lab",
            album = "Netlabel Sessions",
            streamUrl = "https://archive.org/download/starlight/signal.mp3",
            durationMs = 264_000L,
            providerName = "Internet Archive Audio",
            licenseName = "CC BY",
            isPreviewOnly = false,
        )

        val ranked = com.example.data.repository.MusicRepository.deduplicateAndRankCandidates(
            candidates = listOf(preview, audiusFull, audiusDup, archiveFull),
            query = "Midnight Echo",
        )

        assertEquals(3, ranked.size)
        // Full tracks rank ahead of previews, and exact query match ranks first
        assertEquals("audius-1", ranked[0].id)
        assertEquals("ia-1", ranked[1].id)
        assertEquals("itunes-1", ranked[2].id)
        assertTrue(ranked[0].durationMs > 30_000L)
        assertTrue(ranked[2].isPreviewOnly)
        assertEquals(30_000L, ranked[2].durationMs)
    }

    @Test
    fun onlinePagination_mergeAndDeduplicateAppendsWithoutDuplicates() {
        val page0 = listOf(
            com.example.data.remote.OnlineTrackCandidate(
                id = "audius-1",
                title = "Track One",
                artist = "Artist A",
                streamUrl = "https://api.audius.co/v1/tracks/1/stream?app_name=SUNOZA",
                durationMs = 190_000L,
                providerName = "Audius Open Catalog",
                licenseName = "Artist Authorized Stream",
                isPreviewOnly = false,
            ),
            com.example.data.remote.OnlineTrackCandidate(
                id = "itunes-1",
                title = "Sample One",
                artist = "Artist B",
                streamUrl = "https://audio-ssl.itunes.apple.com/s1.m4a",
                durationMs = 30_000L,
                providerName = "Apple iTunes Preview",
                licenseName = "Preview Only (30s)",
                isPreviewOnly = true,
            ),
        )
        val page1 = listOf(
            page0[0], // duplicate from page 0
            com.example.data.remote.OnlineTrackCandidate(
                id = "audius-2",
                title = "Track Two",
                artist = "Artist C",
                streamUrl = "https://api.audius.co/v1/tracks/2/stream?app_name=SUNOZA",
                durationMs = 240_000L,
                providerName = "Audius Open Catalog",
                licenseName = "Artist Authorized Stream",
                isPreviewOnly = false,
            ),
        )

        val merged = com.example.data.repository.MusicRepository.mergeAndDeduplicateCandidates(page0, page1)
        assertEquals(3, merged.size)
        // Full tracks remain grouped before previews
        assertEquals(listOf("audius-1", "audius-2", "itunes-1"), merged.map { it.id })
    }

    @Test
    fun archiveHelpers_parseDurationsPrivateFlagsAndEscapeQueries() {
        assertEquals(215_500L, com.example.data.remote.ArchiveFileDto(length = "215.5").parseDurationMs())
        assertEquals(222_000L, com.example.data.remote.ArchiveFileDto(length = "03:42").parseDurationMs())
        assertEquals(3_730_000L, com.example.data.remote.ArchiveFileDto(length = "1:02:10").parseDurationMs())
        assertTrue(com.example.data.remote.ArchiveFileDto(private = "true").isPrivateFile())
        assertTrue(com.example.data.remote.ArchiveFileDto(private = true).isPrivateFile())

        val lucene = com.example.data.repository.MusicRepository.buildArchiveLuceneQuery("R&B / Lo-Fi")
        assertTrue(lucene.contains("licenseurl:*creativecommons* OR licenseurl:*publicdomain*"))
        assertTrue(lucene.contains("NOT licenseurl:(*by-nc* OR *nc-sa* OR *nc-nd* OR */nc/* OR *noncommercial*)"))
        assertTrue(lucene.contains("NOT mediatype:collection"))
        assertTrue(lucene.contains("format:(\"VBR MP3\" OR \"MP3\" OR \"Ogg Vorbis\" OR \"Flac\")"))
        assertTrue(lucene.contains("\"Lo\""))

        val bestFile = com.example.data.repository.MusicRepository.selectBestArchiveAudioFile(
            listOf(
                com.example.data.remote.ArchiveFileDto(name = "01_track.flac", length = "240.0"),
                com.example.data.remote.ArchiveFileDto(name = "01_track_64kb.mp3", length = "240.0"),
                com.example.data.remote.ArchiveFileDto(name = "01_track.mp3", length = "240.0"),
            )
        )
        assertEquals("01_track.mp3", bestFile?.name)
    }

    @Test
    fun audiusResilientAdapter_handlesMixedArtworkShapesFloatDurationsAndBadItems() {
        val rawJson = """
            {
              "data": [
                {
                  "id": "V66vyPP",
                  "title": "Fragments",
                  "genre": "Electronic",
                  "duration": 212.6,
                  "permalink": "/xsetra/fragments",
                  "license": "All rights reserved",
                  "is_streamable": true,
                  "stream_conditions": null,
                  "artwork": {
                    "150x150": "https://cdn.audius.co/150.jpg",
                    "480x480": "https://cdn.audius.co/480.jpg",
                    "mirrors": ["https://mirror.audius.co"]
                  },
                  "user": { "name": "Xsetra", "handle": "xsetra" }
                },
                {
                  "id": "StrArt1",
                  "title": "String Art Track",
                  "duration": "195.0",
                  "cc_license": "cc-by",
                  "is_streamable": true,
                  "artwork": "https://cdn.audius.co/direct.jpg",
                  "user": { "name": "Artist2" }
                },
                {
                  "id": "",
                  "title": "Missing Id Should Be Skipped"
                }
              ]
            }
        """.trimIndent()

        val parsed = com.example.data.remote.AudiusApi.resilientMoshi
            .adapter(com.example.data.remote.AudiusTracksResponse::class.java)
            .fromJson(rawJson)

        assertEquals(2, parsed?.data?.size)
        assertEquals("V66vyPP", parsed?.data?.get(0)?.id)
        assertEquals(212, parsed?.data?.get(0)?.duration)
        assertEquals("/xsetra/fragments", parsed?.data?.get(0)?.permalink)
        assertEquals("All rights reserved", parsed?.data?.get(0)?.license)
        assertEquals("https://cdn.audius.co/480.jpg", parsed?.data?.get(0)?.artwork?.bestUrl())
        assertEquals("StrArt1", parsed?.data?.get(1)?.id)
        assertEquals(195, parsed?.data?.get(1)?.duration)
        assertEquals("cc-by", parsed?.data?.get(1)?.ccLicense)
        assertEquals("https://cdn.audius.co/direct.jpg", parsed?.data?.get(1)?.artwork?.bestUrl())
    }

    @Test
    fun songModel_flagsItunesPreviewUrlsRegardlessOfLabels() {
        val legacyItunes = sampleSong(10L, "Blinding Lights", "Artist", "Pop", 120, 0.8f, false, 0).copy(
            sourceType = SourceType.AUTHORIZED_ONLINE,
            audioUri = "https://audio-ssl.itunes.apple.com/itunes-assets/sample.m4a",
            licenseName = "Unknown License",
            mood = "Streaming",
        )
        assertTrue(legacyItunes.isPreviewOnly)

        val audiusSong = legacyItunes.copy(
            audioUri = "https://api.audius.co/v1/tracks/V66vyPP/stream?app_name=SUNOZA",
            licenseName = "Audius API Stream (Artist Opt-In — Verify Track License)",
        )
        assertTrue(!audiusSong.isPreviewOnly)
    }

    @Test
    fun wikimediaParser_extractsFullAudioAndSkipsMissingOrNonCommercialLicenses() {
        val rawJson = """
            {
              "query": {
                "pages": {
                  "1": {
                    "title": "File:NEFFEX_-_Copyright_Free.ogg",
                    "imageinfo": [{
                      "size": 3844401,
                      "duration": 182.9,
                      "url": "https://upload.wikimedia.org/wikipedia/commons/4/47/NEFFEX.ogg?utm_source=x",
                      "extmetadata": {
                        "Artist": { "value": "<a href='https://x'>NEFFEX</a>" },
                        "LicenseShortName": { "value": "CC BY 4.0" },
                        "LicenseUrl": { "value": "https://creativecommons.org/licenses/by/4.0/" }
                      }
                    }]
                  },
                  "2": {
                    "title": "File:En-us-word.ogg",
                    "imageinfo": [{
                      "size": 12000,
                      "duration": 1.2,
                      "url": "https://upload.wikimedia.org/wikipedia/commons/1/11/En-us-word.ogg",
                      "extmetadata": { "LicenseShortName": { "value": "CC0" } }
                    }]
                  },
                  "3": {
                    "title": "File:Short_Effect.ogg",
                    "imageinfo": [{
                      "size": 450000,
                      "duration": 12.0,
                      "url": "https://upload.wikimedia.org/wikipedia/commons/2/22/Short_Effect.ogg",
                      "extmetadata": { "LicenseShortName": { "value": "CC BY 4.0" } }
                    }]
                  },
                  "4": {
                    "title": "File:Missing_License_Song.ogg",
                    "imageinfo": [{
                      "size": 2500000,
                      "duration": 150.0,
                      "url": "https://upload.wikimedia.org/wikipedia/commons/3/33/Missing_License_Song.ogg",
                      "extmetadata": {
                        "Artist": { "value": "Unknown" }
                      }
                    }]
                  },
                  "5": {
                    "title": "File:NonCommercial_Song.ogg",
                    "imageinfo": [{
                      "size": 2500000,
                      "duration": 150.0,
                      "url": "https://upload.wikimedia.org/wikipedia/commons/4/44/NonCommercial_Song.ogg",
                      "extmetadata": {
                        "Artist": { "value": "NC Artist" },
                        "LicenseShortName": { "value": "CC BY-NC 4.0" },
                        "LicenseUrl": { "value": "https://creativecommons.org/licenses/by-nc/4.0/" }
                      }
                    }]
                  }
                }
              }
            }
        """.trimIndent()

        val tracks = com.example.data.repository.MusicRepository.parseWikimediaAudioResults(rawJson)
        assertEquals(1, tracks.size)
        val track = tracks.first()
        assertEquals("NEFFEX", track.artist)
        assertEquals(182_900L, track.durationMs)
        assertTrue(!track.isPreviewOnly)
        assertTrue(track.isLicenseVerified)
        assertEquals("https://creativecommons.org/licenses/by/4.0/", track.licenseUrl)
        assertTrue(track.sourcePageUrl?.contains("commons.wikimedia.org/wiki/File:NEFFEX_-_Copyright_Free.ogg") == true)
        assertTrue(track.attributionText.contains("Wikimedia Commons", ignoreCase = true))
        assertEquals("Wikimedia Commons", track.providerName)
    }

    @Test
    fun curatedSoundHelixCatalog_doesNotClaimUnverifiedCreativeCommons() {
        com.example.data.remote.CuratedAuthorizedCatalog.featuredTracks.forEach { track ->
            assertTrue(!track.isLicenseVerified)
            assertTrue(!track.licenseName.contains("Creative Commons", ignoreCase = true))
            assertTrue(track.sourcePageUrl?.contains("soundhelix.com") == true)
        }
    }

    @Test
    fun playbackQueuePlanner_shuffleAvoidsRepeatsUntilCycleCompletesAndExcludesPreviews() {
        val local1 = sampleSong(1L, "Local Drift", "Offline Artist", "Lo-Fi", 90, 0.5f, false, 0).copy(
            sourceType = SourceType.OFFLINE_LOCAL,
            audioUri = "asset:///local1.mp3",
        )
        val online1 = sampleSong(2L, "Audius Anthem", "Indie", "Electronic", 120, 0.8f, false, 0).copy(
            sourceType = SourceType.AUTHORIZED_ONLINE,
            audioUri = "https://api.audius.co/v1/tracks/abc/stream?app_name=SUNOZA",
        )
        val previewOnly = sampleSong(3L, "iTunes Sample", "Label", "Pop", 110, 0.7f, false, 0).copy(
            sourceType = SourceType.AUTHORIZED_ONLINE,
            audioUri = "https://audio-ssl.itunes.apple.com/sample.m4a",
            licenseName = "Preview Only (30s)",
            durationMs = 30_000L,
        )
        val local2 = sampleSong(4L, "Acoustic Morning", "Offline 2", "Acoustic", 85, 0.4f, false, 0).copy(
            sourceType = SourceType.OFFLINE_LOCAL,
            audioUri = "asset:///local2.mp3",
        )
        val online2 = sampleSong(5L, "Wikimedia Opus", "CC Artist", "Ambient", 76, 0.3f, false, 0).copy(
            sourceType = SourceType.AUTHORIZED_ONLINE,
            audioUri = "https://upload.wikimedia.org/wikipedia/commons/4/47/Track.ogg",
        )

        val planner = com.example.player.PlaybackQueuePlanner(random = kotlin.random.Random(42))
        assertTrue(planner.shuffleEnabled)

        val queue = listOf(local1, online1, previewOnly, local2, online2)
        planner.updateQueue(queue, selectSongId = local1.id)

        val eligibleIds = setOf(1L, 2L, 4L, 5L)
        val playedSequence = mutableListOf(planner.currentSongId!!)

        // Advance through the remainder of the first full cycle (3 advances -> 4 unique tracks)
        repeat(3) {
            val expectedNextId = planner.peekNextSong()?.id
            assertTrue(expectedNextId != null && expectedNextId in eligibleIds)
            val next = planner.advanceToNext(isManualNext = false)
            assertEquals(expectedNextId, next?.id)
            assertTrue(next?.isPreviewOnly == false)
            playedSequence.add(next!!.id)
        }

        // All 4 eligible tracks (both offline & online full tracks) played with ZERO repeats and NO preview
        assertEquals(4, playedSequence.size)
        assertEquals(eligibleIds, playedSequence.toSet())
        assertTrue(3L !in playedSequence)

        // Next advance starts a fresh cycle without repeating the just-finished song immediately
        val lastInCycle = playedSequence.last()
        val cycleTwoFirst = planner.advanceToNext(isManualNext = false)
        assertTrue(cycleTwoFirst != null && cycleTwoFirst.id in eligibleIds)
        assertNotEquals(lastInCycle, cycleTwoFirst!!.id)
    }

    @Test
    fun playbackQueuePlanner_shuffleOffPlaysSequentialAndRespectsRepeatModes() {
        val s1 = sampleSong(1L, "One", "A", "Pop", 100, 0.5f, false, 0)
        val preview = sampleSong(2L, "Preview", "B", "Pop", 100, 0.5f, false, 0).copy(
            sourceType = SourceType.AUTHORIZED_ONLINE,
            audioUri = "https://audio-ssl.itunes.apple.com/p.m4a",
            licenseName = "Preview Only (30s)",
        )
        val s2 = sampleSong(3L, "Two", "C", "Pop", 110, 0.6f, false, 0)
        val s3 = sampleSong(4L, "Three", "D", "Pop", 120, 0.7f, false, 0)

        val planner = com.example.player.PlaybackQueuePlanner(random = kotlin.random.Random(7))
        planner.updateQueue(listOf(s1, preview, s2, s3), selectSongId = s1.id)
        planner.setShuffleEnabled(false)

        // Sequential skips preview track 2L cleanly
        assertEquals(s2.id, planner.peekNextSong()?.id)
        assertEquals(s2.id, planner.advanceToNext(isManualNext = false)?.id)
        assertEquals(s3.id, planner.peekNextSong()?.id)
        assertEquals(s3.id, planner.advanceToNext(isManualNext = false)?.id)

        // REPEAT_MODE_ALL wraps around to s1
        assertEquals(s1.id, planner.advanceToNext(isManualNext = false)?.id)

        // REPEAT_MODE_ONE replays current song on auto-advance, but manual Next moves forward
        planner.setRepeatMode(androidx.media3.common.Player.REPEAT_MODE_ONE)
        assertEquals(s1.id, planner.peekNextSong()?.id)
        assertEquals(s1.id, planner.advanceToNext(isManualNext = false)?.id)
        assertEquals(s2.id, planner.advanceToNext(isManualNext = true)?.id)

        // REPEAT_MODE_OFF stops cleanly at the end of sequential queue
        planner.setRepeatMode(androidx.media3.common.Player.REPEAT_MODE_OFF)
        assertEquals(s3.id, planner.advanceToNext(isManualNext = false)?.id)
        assertEquals(null, planner.advanceToNext(isManualNext = false))
    }

    @Test
    fun playbackQueuePlanner_excludesBrokenTracksStepsBackAndDeduplicatesTransitions() {
        val s1 = sampleSong(10L, "Alpha", "A", "Electronic", 120, 0.7f, false, 0)
        val s2 = sampleSong(20L, "BrokenStream", "B", "Electronic", 120, 0.7f, false, 0).copy(
            sourceType = SourceType.AUTHORIZED_ONLINE,
            audioUri = "https://api.audius.co/v1/tracks/broken/stream?app_name=SUNOZA",
        )
        val s3 = sampleSong(30L, "Gamma", "C", "Electronic", 120, 0.7f, false, 0)

        val planner = com.example.player.PlaybackQueuePlanner(random = kotlin.random.Random(1))
        planner.updateQueue(listOf(s1, s2, s3), selectSongId = s1.id)
        planner.markBroken(s2.id)

        // Broken track must never be selected as planned next or on advance
        assertEquals(s3.id, planner.peekNextSong()?.id)
        val advanced = planner.advanceToNext(isManualNext = false)
        assertEquals(s3.id, advanced?.id)

        // Duplicate ExoPlayer transition signal for already-active track is ignored
        planner.onExoPlayerTransitionedTo(s3.id)
        assertEquals(s3.id, planner.currentSongId)

        // Step back returns cleanly to s1
        val prev = planner.stepToPrevious()
        assertEquals(s1.id, prev?.id)
    }

    @Test
    fun launcherIconAssets_areCenteredWithEqualPaddingAndSquareProportions() {
        fun resolveRes(relative: String): java.io.File? = listOf(
            "src/main/res/$relative",
            "app/src/main/res/$relative",
        ).map { java.io.File(it) }.firstOrNull { it.exists() }

        val brandLogo = resolveRes("drawable/ic_sunoza_logo.png")
        val fgFile = resolveRes("drawable/ic_launcher_logo_centered.png")
        assertTrue("Expected ic_sunoza_logo.png to exist", brandLogo != null)
        assertTrue("Expected ic_launcher_logo_centered.png to exist", fgFile != null)

        fun assertCenteredOriginalProportions(file: java.io.File, label: String, expectRoundCorners: Boolean = false) {
            val img = javax.imageio.ImageIO.read(file)
            assertEquals("$label should be 1:1 square", img.width, img.height)
            if (expectRoundCorners) {
                val cornerAlpha = (img.getRGB(0, 0) ushr 24) and 0xFF
                assertEquals("$label corners should be transparent for round icon mask", 0, cornerAlpha)
            }
            var minX = img.width
            var maxX = -1
            var minY = img.height
            var maxY = -1
            for (y in 0 until img.height) {
                for (x in 0 until img.width) {
                    val rgb = img.getRGB(x, y)
                    val a = (rgb ushr 24) and 0xFF
                    val r = (rgb ushr 16) and 0xFF
                    val g = (rgb ushr 8) and 0xFF
                    val b = rgb and 0xFF
                    if (a > 0 && (r > 12 || g > 12 || b > 12)) {
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                }
            }
            assertTrue("$label should contain visible ring pixels", maxX > minX && maxY > minY)
            assertTrue("$label should not clip ring at outer edge", minX > 0 && minY > 0)
            val leftPad = minX
            val rightPad = (img.width - 1) - maxX
            val topPad = minY
            val bottomPad = (img.height - 1) - maxY
            val contentW = (maxX - minX) + 1
            val contentH = (maxY - minY) + 1
            assertTrue("$label horizontal centering mismatch ($leftPad vs $rightPad)", kotlin.math.abs(leftPad - rightPad) <= 1)
            assertTrue("$label vertical centering mismatch ($topPad vs $bottomPad)", kotlin.math.abs(topPad - bottomPad) <= 1)
            val aspect = contentW.toFloat() / contentH.toFloat()
            assertTrue("$label aspect ratio distorted ($contentW x $contentH, ratio=$aspect)", aspect in 0.98f..1.08f)
        }

        assertCenteredOriginalProportions(brandLogo!!, "ic_sunoza_logo.png")
        assertCenteredOriginalProportions(fgFile!!, "ic_launcher_logo_centered.png")

        listOf("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi").forEach { density ->
            val square = resolveRes("mipmap-$density/ic_launcher.png")
            val round = resolveRes("mipmap-$density/ic_launcher_round.png")
            assertTrue("Expected mipmap-$density/ic_launcher.png to exist", square != null)
            assertTrue("Expected mipmap-$density/ic_launcher_round.png to exist", round != null)
            assertTrue(
                "Legacy webp mipmap-$density/ic_launcher.webp should be removed",
                resolveRes("mipmap-$density/ic_launcher.webp") == null,
            )
            assertTrue(
                "Legacy webp mipmap-$density/ic_launcher_round.webp should be removed",
                resolveRes("mipmap-$density/ic_launcher_round.webp") == null,
            )
            assertCenteredOriginalProportions(square!!, "mipmap-$density/ic_launcher.png")
            assertCenteredOriginalProportions(round!!, "mipmap-$density/ic_launcher_round.png", expectRoundCorners = true)
        }
    }

    private fun sampleSong(
        id: Long,
        title: String,
        artist: String,
        genre: String,
        bpm: Int,
        energy: Float,
        fav: Boolean,
        plays: Int,
    ): Song = Song(
        id = id,
        title = title,
        artist = artist,
        audioUri = "asset:///$id",
        durationMs = 180_000L,
        backgroundColorArgb = 0xFF1F2233L,
        sourceType = SourceType.BUNDLED,
        sourceLabel = "Built-in Sample",
        licenseName = "Original Demo",
        isFavorite = fav,
        lyricsRaw = "",
        addedAtMs = 1_000L,
        genre = genre,
        bpm = bpm,
        energyScore = energy,
        playCount = plays,
    )
}
