package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.SavedMix
import com.example.model.TransitionFilterType

@Entity(tableName = "listening_events")
data class ListeningEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val songId: Long,
    val playedAtMs: Long = System.currentTimeMillis(),
    val sourceType: String,
)

@Entity(tableName = "saved_mixes")
data class SavedMixEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val deckASongId: Long,
    val deckBSongId: Long,
    val crossfader: Float,
    val transitionDurationSec: Int,
    val filterType: String,
    val echoAmount: Float,
    val autoMixEnabled: Boolean,
    val createdAtMs: Long = System.currentTimeMillis(),
) {
    fun toDomain(): SavedMix = SavedMix(
        id = id,
        name = name,
        deckASongId = deckASongId,
        deckBSongId = deckBSongId,
        crossfader = crossfader,
        transitionDurationSec = transitionDurationSec,
        filterType = runCatching { TransitionFilterType.valueOf(filterType) }
            .getOrDefault(TransitionFilterType.SMOOTH_FADE),
        echoAmount = echoAmount,
        autoMixEnabled = autoMixEnabled,
        createdAtMs = createdAtMs,
    )
}
