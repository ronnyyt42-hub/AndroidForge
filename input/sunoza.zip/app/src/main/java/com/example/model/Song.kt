package com.example.model

enum class SourceType(val displayLabel: String) {
    BUNDLED("Built-in Sample"),
    OFFLINE_LOCAL("Device Audio"),
    AUTHORIZED_ONLINE("Online Stream"),
}

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val audioUri: String,
    val durationMs: Long,
    val backgroundColorArgb: Long,
    val sourceType: SourceType,
    val sourceLabel: String,
    val licenseName: String,
    val isFavorite: Boolean,
    val lyricsRaw: String,
    val addedAtMs: Long,
    val album: String = "Single",
    val artworkUri: String? = null,
    val folderName: String = "Sunoza",
    val genre: String = "Electronic",
    val bpm: Int = 100,
    val energyScore: Float = 0.6f,
    val mood: String = "Balanced",
    val playCount: Int = 0,
    val lastPlayedAtMs: Long = 0L,
    val mediaStoreId: Long? = null,
) {
    val parsedLyrics: List<LyricLine>
        get() = LyricsParser.parse(lyricsRaw, durationMs)
}
