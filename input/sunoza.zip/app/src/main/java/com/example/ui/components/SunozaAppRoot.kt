package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.remote.OnlineTrackCandidate
import com.example.model.Song
import com.example.ui.SunozaUiState
import com.example.ui.SunozaViewModel
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSurface

enum class SunozaTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    ONLINE("Online", Icons.Filled.Public),
    LIBRARY("Library", Icons.Filled.LibraryMusic),
    MIXFLOW("MixFlow", Icons.Filled.GraphicEq),
    PROFILE("Profile", Icons.Filled.Person),
}

@Composable
fun SunozaAppRoot(
    uiState: SunozaUiState,
    viewModel: SunozaViewModel,
    onRequestAudioPermission: () -> Unit,
    onPickOfflineAudio: () -> Unit,
) {
    var currentTab by remember { mutableStateOf(SunozaTab.HOME) }
    var djInitialMode by remember { mutableStateOf(DjStudioMode.MIXFLOW) }
    var showFullPlayer by remember { mutableStateOf(false) }
    var showSoundStudio by remember { mutableStateOf(false) }
    var showAuthorizedUrlDialog by remember { mutableStateOf(false) }
    var songForPlaylistAdd by remember { mutableStateOf<Song?>(null) }
    var onlineCandidateForPlaylist by remember { mutableStateOf<OnlineTrackCandidate?>(null) }
    var attributionTarget by remember { mutableStateOf<TrackAttributionInfo?>(null) }
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }
    var reportTarget by remember { mutableStateOf<TrackAttributionInfo?>(null) }
    var showGeneralReportDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    if (!uiState.isReady) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SunozaObsidian),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(color = SunozaPurple)
        }
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 720.dp

        Scaffold(
            containerColor = SunozaObsidian,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = SunozaSurface,
                        contentColor = SunozaIvory,
                    )
                }
            },
            bottomBar = {
                if (!useRail && !showFullPlayer) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SunozaObsidian)
                            .navigationBarsPadding(),
                    ) {
                        uiState.currentSong?.let { song ->
                            MiniPlayerBar(
                                song = song,
                                playback = uiState.playback,
                                onExpand = { showFullPlayer = true },
                                onTogglePlayPause = viewModel::togglePlayPause,
                                onNext = viewModel::nextSong,
                                nextSong = uiState.nextSong,
                            )
                        }
                        NavigationBar(
                            containerColor = SunozaSurface,
                            contentColor = SunozaIvory,
                        ) {
                            SunozaTab.entries.forEach { tab ->
                                NavigationBarItem(
                                    selected = currentTab == tab,
                                    onClick = { currentTab = tab },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = SunozaPink,
                                        selectedTextColor = SunozaPink,
                                        indicatorColor = SunozaPurple.copy(alpha = 0.22f),
                                        unselectedIconColor = SunozaMutedText,
                                        unselectedTextColor = SunozaMutedText,
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                                )
                            }
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .statusBarsPadding(),
            ) {
                if (useRail && !showFullPlayer) {
                    NavigationRail(
                        containerColor = SunozaSurface,
                        contentColor = SunozaIvory,
                        modifier = Modifier.fillMaxHeight(),
                    ) {
                        SunozaTab.entries.forEach { tab ->
                            NavigationRailItem(
                                selected = currentTab == tab,
                                onClick = { currentTab = tab },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = SunozaPink,
                                    selectedTextColor = SunozaPink,
                                    indicatorColor = SunozaPurple.copy(alpha = 0.22f),
                                    unselectedIconColor = SunozaMutedText,
                                    unselectedTextColor = SunozaMutedText,
                                ),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when (currentTab) {
                        SunozaTab.HOME -> HomeScreen(
                            uiState = uiState,
                            onPlaySong = { song ->
                                viewModel.playSongInCurrentOrAllQueue(song)
                            },
                            onPlayCustomQueue = { songs, start ->
                                viewModel.playCustomQueue(songs, start)
                            },
                            onOpenNowPlaying = { showFullPlayer = true },
                            onOpenSoundStudio = { showSoundStudio = true },
                            onOpenMixFlow = {
                                djInitialMode = DjStudioMode.MIXFLOW
                                currentTab = SunozaTab.MIXFLOW
                            },
                            onStartPartyFlow = { starter ->
                                viewModel.startPartyFlow(starter)
                                djInitialMode = DjStudioMode.PARTYFLOW
                                currentTab = SunozaTab.MIXFLOW
                            },
                            onOpenLibrary = { currentTab = SunozaTab.LIBRARY },
                        )

                        SunozaTab.ONLINE -> OnlineScreen(
                            uiState = uiState,
                            onSearchQueryChange = viewModel::updateOnlineSearchQuery,
                            onSearchSubmit = viewModel::searchAuthorizedOnline,
                            onLoadMore = viewModel::loadMoreOnlineTracks,
                            onPlayCandidate = viewModel::importAndPlayAuthorizedCandidate,
                            onAddCandidateToPlaylist = { candidate ->
                                onlineCandidateForPlaylist = candidate
                            },
                            onPlayPlaylistPack = viewModel::playOnlinePlaylistPack,
                            onPlaySong = viewModel::playSongInCurrentOrAllQueue,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onOpenAuthorizedUrlDialog = { showAuthorizedUrlDialog = true },
                            onInspectAttribution = { candidate ->
                                attributionTarget = candidate.toAttributionInfo()
                            },
                        )

                        SunozaTab.LIBRARY -> LibraryScreen(
                            uiState = uiState,
                            onSearchQueryChange = viewModel::updateSearchQuery,
                            onRequestAudioPermission = onRequestAudioPermission,
                            onRescanMediaStore = { viewModel.refreshMediaStoreLibrary(silent = false) },
                            onImportOfflineAudio = onPickOfflineAudio,
                            onPlaySong = viewModel::playSongInCurrentOrAllQueue,
                            onPlayCustomQueue = viewModel::playCustomQueue,
                            onPlayFavorites = { viewModel.playFavorites() },
                            onToggleFavorite = viewModel::toggleFavorite,
                            onAddToPlaylist = { songForPlaylistAdd = it },
                            onDeleteSong = viewModel::deleteSong,
                            onCreatePlaylist = { name -> viewModel.createPlaylist(name) },
                            onRenamePlaylist = viewModel::renamePlaylist,
                            onDeletePlaylist = viewModel::deletePlaylist,
                            onPlayPlaylist = { pl, startSong, shuffle ->
                                viewModel.playPlaylist(pl, startSong, shuffle)
                            },
                            onRemoveSongFromPlaylist = viewModel::toggleSongInPlaylist,
                            onMovePlaylistSong = viewModel::movePlaylistSong,
                        )

                        SunozaTab.MIXFLOW -> MixAndPartyScreen(
                            uiState = uiState,
                            viewModel = viewModel,
                            initialMode = djInitialMode,
                        )

                        SunozaTab.PROFILE -> ProfileScreen(
                            uiState = uiState,
                            onOpenSoundStudio = { showSoundStudio = true },
                            onLoadSavedMix = { mix ->
                                viewModel.loadSavedMix(mix)
                                djInitialMode = DjStudioMode.MIXFLOW
                                currentTab = SunozaTab.MIXFLOW
                            },
                            onDeleteSavedMix = viewModel::deleteSavedMix,
                            onRequestAudioPermission = onRequestAudioPermission,
                            onRescanMediaStore = { viewModel.refreshMediaStoreLibrary(silent = false) },
                            onImportOfflineAudio = onPickOfflineAudio,
                            onOpenPrivacyPolicy = { showPrivacyPolicyDialog = true },
                            onOpenContentReport = { showGeneralReportDialog = true },
                        )
                    }

                    if (useRail && !showFullPlayer) {
                        uiState.currentSong?.let { song ->
                            MiniPlayerBar(
                                song = song,
                                playback = uiState.playback,
                                onExpand = { showFullPlayer = true },
                                onTogglePlayPause = viewModel::togglePlayPause,
                                onNext = viewModel::nextSong,
                                nextSong = uiState.nextSong,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 12.dp),
                            )
                        }
                    }
                }
            }
        }

        // Full-Screen Now Playing Overlay
        AnimatedVisibility(
            visible = showFullPlayer,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        ) {
            FullScreenPlayerScreen(
                uiState = uiState,
                viewModel = viewModel,
                onCollapse = { showFullPlayer = false },
                onOpenSoundStudio = { showSoundStudio = true },
                onOpenMixFlow = {
                    showFullPlayer = false
                    djInitialMode = DjStudioMode.MIXFLOW
                    currentTab = SunozaTab.MIXFLOW
                },
                onStartPartyFlow = { starter ->
                    viewModel.startPartyFlow(starter)
                    showFullPlayer = false
                    djInitialMode = DjStudioMode.PARTYFLOW
                    currentTab = SunozaTab.MIXFLOW
                },
                onOpenAddToPlaylist = { songForPlaylistAdd = it },
                onOpenAttribution = { song -> attributionTarget = song.toAttributionInfo() },
            )
        }
    }

    if (showSoundStudio) {
        SoundStudioSheet(
            state = uiState.soundStudio,
            onDismiss = { showSoundStudio = false },
            onToggleEnabled = viewModel::toggleSoundStudio,
            onSelectPreset = viewModel::applyEqPreset,
            onUpdateBand = viewModel::updateEqBand,
            onUpdateBassBoost = viewModel::updateBassBoost,
            onUpdateTreble = viewModel::updateTrebleBoost,
            onUpdateVirtualizer = viewModel::updateVirtualizer,
            onUpdateReverb = viewModel::updateReverb,
            onUpdateLoudness = viewModel::updateLoudnessGain,
            onReset = viewModel::resetSoundStudio,
        )
    }

    songForPlaylistAdd?.let { song ->
        AddToPlaylistDialog(
            song = song,
            playlists = uiState.playlists,
            onDismiss = { songForPlaylistAdd = null },
            onToggleSongInPlaylist = viewModel::toggleSongInPlaylist,
            onCreatePlaylistWithSong = { name, id -> viewModel.createPlaylist(name, id) },
        )
    }

    onlineCandidateForPlaylist?.let { candidate ->
        AddOnlineCandidateToPlaylistDialog(
            candidate = candidate,
            playlists = uiState.playlists,
            onDismiss = { onlineCandidateForPlaylist = null },
            onSelectPlaylist = { plId -> viewModel.addCandidateToPlaylist(candidate, plId) },
        )
    }

    if (showAuthorizedUrlDialog) {
        AuthorizedStreamUrlDialog(
            onDismiss = { showAuthorizedUrlDialog = false },
            onAddUrl = { url, title, artist ->
                viewModel.addAuthorizedStreamByUrl(url, title, artist) {
                    showAuthorizedUrlDialog = false
                }
            },
        )
    }

    attributionTarget?.let { info ->
        TrackAttributionDialog(
            info = info,
            onDismiss = { attributionTarget = null },
            onReportContent = { target -> reportTarget = target },
        )
    }

    if (showPrivacyPolicyDialog) {
        PrivacyPolicyDialog(
            onDismiss = { showPrivacyPolicyDialog = false },
        )
    }

    if (showGeneralReportDialog || reportTarget != null) {
        ContentReportDialog(
            initialTrack = reportTarget,
            onDismiss = {
                reportTarget = null
                showGeneralReportDialog = false
            },
            onSubmitReport = { url, title, artist, provider, reason, email, details ->
                viewModel.reportTrack(url, title, artist, provider, reason, email, details)
            },
        )
    }
}
