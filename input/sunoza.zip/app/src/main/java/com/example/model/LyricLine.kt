package com.example.model

data class LyricLine(
    val timestampMs: Long,
    val text: String,
)

object LyricsParser {
    private val timestampRegex = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""")

    fun parse(raw: String, fallbackDurationMs: Long = 24_000L): List<LyricLine> {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return emptyList()

        val lrcLines = mutableListOf<LyricLine>()
        val plainLines = mutableListOf<String>()

        trimmed.lines().forEach { line ->
            val cleanLine = line.trim()
            if (cleanLine.isEmpty()) return@forEach

            val matches = timestampRegex.findAll(cleanLine).toList()
            if (matches.isNotEmpty()) {
                val lyricText = timestampRegex.replace(cleanLine, "").trim()
                if (lyricText.isNotEmpty()) {
                    matches.forEach { match ->
                        val minutes = match.groupValues[1].toLongOrNull() ?: 0L
                        val seconds = match.groupValues[2].toLongOrNull() ?: 0L
                        val fractionRaw = match.groupValues[3]
                        val millis = when (fractionRaw.length) {
                            0 -> 0L
                            1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                            2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                            else -> fractionRaw.take(3).toLongOrNull() ?: 0L
                        }
                        val timeMs = (minutes * 60_000L) + (seconds * 1_000L) + millis
                        lrcLines.add(LyricLine(timestampMs = timeMs, text = lyricText))
                    }
                }
            } else if (!cleanLine.startsWith("[")) {
                plainLines.add(cleanLine)
            }
        }

        if (lrcLines.isNotEmpty()) {
            return lrcLines.sortedBy { it.timestampMs }
        }

        if (plainLines.isEmpty()) return emptyList()

        val safeDuration = fallbackDurationMs.coerceAtLeast(plainLines.size * 2_000L)
        val stepMs = safeDuration / plainLines.size.coerceAtLeast(1)
        return plainLines.mapIndexed { index, text ->
            LyricLine(
                timestampMs = index * stepMs,
                text = text,
            )
        }
    }

    fun activeLineIndex(lines: List<LyricLine>, positionMs: Long): Int {
        if (lines.isEmpty()) return -1
        var activeIndex = -1
        for (i in lines.indices) {
            if (lines[i].timestampMs <= positionMs + 150L) {
                activeIndex = i
            } else {
                break
            }
        }
        return if (activeIndex == -1) 0 else activeIndex
    }
}
