package com.example.data.repository

import com.example.data.local.ListeningEventEntity
import com.example.model.PartyEnergyMode
import com.example.model.Song
import kotlin.math.abs

data class RecommendationSnapshot(
    val recommendedForYou: List<Song> = emptyList(),
    val discoverWeekly: List<Song> = emptyList(),
    val similarToCurrent: List<Song> = emptyList(),
    val smartPlayNext: List<Song> = emptyList(),
    val favoriteArtists: List<Pair<String, List<Song>>> = emptyList(),
    val genreBuckets: List<Pair<String, List<Song>>> = emptyList(),
)

object RecommendationEngine {

    fun buildRecommendations(
        allSongs: List<Song>,
        currentSong: Song?,
        recentEvents: List<ListeningEventEntity>,
    ): RecommendationSnapshot {
        if (allSongs.isEmpty()) return RecommendationSnapshot()

        val songMap = allSongs.associateBy { it.id }
        val listenedSongs = recentEvents.mapNotNull { songMap[it.songId] } +
            allSongs.filter { it.isFavorite || it.playCount > 0 }

        val preferredGenres = listenedSongs
            .groupingBy { it.genre.lowercase() }
            .eachCount()
        val preferredArtists = listenedSongs
            .groupingBy { it.artist.lowercase() }
            .eachCount()
        val avgPreferredBpm = listenedSongs
            .takeIf { it.isNotEmpty() }
            ?.map { it.bpm }
            ?.average()
            ?.toFloat()
            ?: 100f
        val avgPreferredEnergy = listenedSongs
            .takeIf { it.isNotEmpty() }
            ?.map { it.energyScore }
            ?.average()
            ?.toFloat()
            ?: 0.6f

        val recommendedForYou = allSongs
            .sortedByDescending { song ->
                var score = 0f
                if (song.isFavorite) score += 2.2f
                score += (preferredGenres[song.genre.lowercase()] ?: 0) * 1.4f
                score += (preferredArtists[song.artist.lowercase()] ?: 0) * 1.8f
                score += (1f - (abs(song.bpm - avgPreferredBpm) / 80f).coerceIn(0f, 1f)) * 1.5f
                score += (1f - abs(song.energyScore - avgPreferredEnergy)) * 1.3f
                score += (song.playCount.coerceAtMost(5)) * 0.3f
                score
            }
            .take(10)

        // Discover Weekly: prioritize unplayed or less-played songs that still align with preferred profile
        val discoverWeekly = allSongs
            .filter { it.id != currentSong?.id }
            .sortedWith(
                compareBy<Song> { it.playCount }
                    .thenByDescending { song ->
                        val genreMatch = if ((preferredGenres[song.genre.lowercase()] ?: 0) > 0) 1.5f else 0f
                        val bpmMatch = 1f - (abs(song.bpm - avgPreferredBpm) / 90f).coerceIn(0f, 1f)
                        genreMatch + bpmMatch
                    }
            )
            .take(8)

        val anchor = currentSong ?: recommendedForYou.firstOrNull()
        val similarToCurrent = if (anchor != null) {
            allSongs
                .filter { it.id != anchor.id }
                .sortedByDescending { candidate -> similarityScore(anchor, candidate) }
                .take(8)
        } else {
            emptyList()
        }

        val smartPlayNext = if (anchor != null) {
            allSongs
                .filter { it.id != anchor.id }
                .sortedByDescending { candidate ->
                    val sim = similarityScore(anchor, candidate)
                    val tempoFlow = 1f - (abs(anchor.bpm - candidate.bpm) / 40f).coerceIn(0f, 1f)
                    sim + tempoFlow
                }
                .take(5)
        } else {
            emptyList()
        }

        val artistScores = allSongs
            .groupBy { it.artist }
            .filterKeys { it.isNotBlank() && it != "Unknown Artist" }
            .entries
            .sortedByDescending { (_, tracks) ->
                tracks.sumOf { (if (it.isFavorite) 3 else 0) + it.playCount + 1 }
            }
            .take(6)
            .map { it.key to it.value }

        val genreBuckets = allSongs
            .groupBy { it.genre.ifBlank { "General" } }
            .entries
            .sortedByDescending { it.value.size }
            .take(6)
            .map { it.key to it.value }

        return RecommendationSnapshot(
            recommendedForYou = recommendedForYou,
            discoverWeekly = discoverWeekly,
            similarToCurrent = similarToCurrent,
            smartPlayNext = smartPlayNext,
            favoriteArtists = artistScores,
            genreBuckets = genreBuckets,
        )
    }

    fun buildPartyQueue(
        startingSong: Song,
        allSongs: List<Song>,
        energyMode: PartyEnergyMode,
        excludeIds: Set<Long> = emptySet(),
    ): List<Song> {
        val candidates = allSongs.filter { it.id != startingSong.id && it.id !in excludeIds }
        val ranked = candidates.sortedByDescending { song ->
            val bpmInRange = if (song.bpm in energyMode.minBpm..energyMode.maxBpm) 2.2f else {
                val dist = minOf(abs(song.bpm - energyMode.minBpm), abs(song.bpm - energyMode.maxBpm))
                (1f - (dist / 60f)).coerceIn(0f, 1f)
            }
            val energyMatch = (1f - abs(song.energyScore - energyMode.targetEnergy)) * 2.4f
            val genreBonus = if (song.genre.equals(startingSong.genre, ignoreCase = true)) 1.0f else 0f
            val favBonus = if (song.isFavorite) 0.6f else 0f
            bpmInRange + energyMatch + genreBonus + favBonus
        }
        return listOf(startingSong) + ranked.take(15)
    }

    private fun similarityScore(a: Song, b: Song): Float {
        var score = 0f
        if (a.genre.equals(b.genre, ignoreCase = true)) score += 2.0f
        if (a.mood.equals(b.mood, ignoreCase = true)) score += 1.5f
        if (a.artist.equals(b.artist, ignoreCase = true)) score += 1.4f
        score += (1f - (abs(a.bpm - b.bpm) / 70f).coerceIn(0f, 1f)) * 2.0f
        score += (1f - abs(a.energyScore - b.energyScore)) * 1.6f
        return score
    }
}
