package com.example.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import com.example.model.Song
import com.example.model.SourceType
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class PlaybackState(
    val isConnected: Boolean = false,
    val currentSongId: Long? = null,
    val nextSongId: Long? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val isExplicitlyStopped: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = true,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,
    val errorMessage: String? = null,
)

class PlaybackController(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private var positionTickerJob: Job? = null
    private var isReleased = false

    private val planner = PlaybackQueuePlanner(
        isSongAvailable = { song -> isSongSourceAccessible(song) },
    )

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private var currentQueue: List<Song> = emptyList()
    private var pendingStartSongId: Long? = null
    private var pendingAutoPlay: Boolean = false
    private var isUserPaused: Boolean = false
    private var isExplicitlyStopped: Boolean = false
    private var lastAutoSkippedErrorCount: Int = 0
    private var activeWindowIndex: Int = 0
    private var activeWindowSongIds: List<Long> = emptyList()
    private var lastTransitionToken: String? = null
    private var transitionCounter: Int = 0

    private var onSongTransitionCallback: ((Long) -> Unit)? = null

    fun setOnSongTransitionListener(listener: (Long) -> Unit) {
        onSongTransitionCallback = listener
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                lastAutoSkippedErrorCount = 0
                isExplicitlyStopped = false
                isUserPaused = false
                startPositionTicker()
            } else {
                stopPositionTicker()
            }
            _state.update {
                it.copy(
                    isPlaying = isPlaying,
                    isExplicitlyStopped = isExplicitlyStopped,
                )
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val controller = mediaController ?: return
            val activeId = controller.currentMediaItem?.mediaId?.toLongOrNull() ?: planner.currentSongId
            _state.update {
                it.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    durationMs = controller.duration.takeIf { d -> d > 0 }
                        ?: currentSongDurationFallback(activeId),
                    positionMs = controller.currentPosition.coerceAtLeast(0L),
                )
            }

            if (playbackState == Player.STATE_ENDED &&
                !isExplicitlyStopped &&
                !isUserPaused &&
                controller.playWhenReady
            ) {
                advanceAfterCompletionOrError(controller)
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val controller = mediaController ?: return
            if (isExplicitlyStopped) {
                if (controller.isPlaying || controller.playWhenReady) {
                    controller.stop()
                }
                return
            }

            // Programmatic queue updates already synchronized planner and state directly
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) {
                val activeId = mediaItem?.mediaId?.toLongOrNull() ?: planner.currentSongId
                _state.update {
                    it.copy(
                        currentSongId = activeId,
                        nextSongId = planner.plannedNextSongId,
                        durationMs = controller.duration.takeIf { d -> d > 0 }
                            ?: currentSongDurationFallback(activeId),
                    )
                }
                return
            }

            val songId = mediaItem?.mediaId?.toLongOrNull() ?: return
            val newIndex = controller.currentMediaItemIndex
            val expectedPreviousSongId = planner.currentSongId

            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK &&
                activeWindowSongIds.isNotEmpty() &&
                newIndex < activeWindowIndex
            ) {
                // External/system MediaSession Previous button pressed
                val prev = planner.stepToPrevious()
                if (prev != null) {
                    syncWindowAroundCurrent(
                        controller = controller,
                        currentSong = prev,
                        previousSong = null,
                        nextSong = planner.peekNextSong(),
                        preservePlayingState = true,
                    )
                    updateStateFromPlanner(controller, clearError = true)
                    notifySongTransition(prev.id, forceNewToken = true)
                    return
                }
            }

            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT ||
                reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK
            ) {
                planner.onExoPlayerTransitionedTo(songId)
                val newCurrent = planner.currentSong()
                val newNext = planner.peekNextSong()
                if (newCurrent != null) {
                    extendRollingWindowForward(
                        controller = controller,
                        previousSongId = expectedPreviousSongId?.takeIf { it != newCurrent.id },
                        currentSong = newCurrent,
                        nextSong = newNext,
                    )
                }
                updateStateFromPlanner(controller, positionMs = 0L, clearError = true)
                notifySongTransition(songId, forceNewToken = true)
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val controller = mediaController
            val failedId = planner.currentSongId ?: controller?.currentMediaItem?.mediaId?.toLongOrNull()
            val failedTitle = failedId?.let { id -> currentQueue.firstOrNull { it.id == id }?.title }
            if (failedId != null) {
                planner.markBroken(failedId)
            }

            val friendlyMessage = when (error.errorCode) {
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ->
                    "Unable to stream track — check your internet connection."
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                    "Audio stream timed out."
                PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                    "Online stream is temporarily unavailable from this provider."
                else -> error.localizedMessage ?: "Unable to play this audio track."
            }

            val maxSkips = (planner.eligibleCount() + 1).coerceAtLeast(1)
            if (!isExplicitlyStopped && !isUserPaused && controller != null &&
                lastAutoSkippedErrorCount < maxSkips
            ) {
                val fallback = planner.advanceToNext(isManualNext = false)
                if (fallback != null && fallback.id != failedId) {
                    lastAutoSkippedErrorCount++
                    val skipNote = if (!failedTitle.isNullOrBlank()) {
                        "Skipped unavailable \"$failedTitle\" · Playing ${fallback.title}"
                    } else {
                        friendlyMessage
                    }
                    startSongInController(
                        controller = controller,
                        targetSong = fallback,
                        previousSong = null,
                        nextSong = planner.peekNextSong(),
                        autoPlay = true,
                        statusError = skipNote,
                    )
                    notifySongTransition(fallback.id, forceNewToken = true)
                    return
                }
            }

            _state.update {
                it.copy(
                    isPlaying = false,
                    isBuffering = false,
                    nextSongId = planner.plannedNextSongId,
                    errorMessage = friendlyMessage,
                )
            }
        }
    }

    fun connect() {
        if (controllerFuture != null || isReleased) return
        val sessionToken = SessionToken(
            context,
            ComponentName(context, SunozaPlaybackService::class.java),
        )
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                if (isReleased) {
                    runCatching { future.get().release() }
                    return@addListener
                }
                runCatching { future.get() }.onSuccess { controller ->
                    mediaController = controller
                    controller.removeListener(playerListener)
                    controller.addListener(playerListener)
                    // Controller + PlaybackQueuePlanner manage repeat/shuffle across cycles
                    controller.repeatMode = Player.REPEAT_MODE_OFF
                    controller.shuffleModeEnabled = false

                    val activeSongId = controller.currentMediaItem?.mediaId?.toLongOrNull()
                    if (activeSongId != null && currentQueue.any { it.id == activeSongId }) {
                        planner.updateQueue(currentQueue, selectSongId = activeSongId)
                    }

                    _state.update {
                        it.copy(
                            isConnected = true,
                            currentSongId = activeSongId ?: planner.currentSongId ?: it.currentSongId,
                            nextSongId = planner.plannedNextSongId,
                            isPlaying = controller.isPlaying,
                            isBuffering = controller.playbackState == Player.STATE_BUFFERING,
                            isExplicitlyStopped = isExplicitlyStopped,
                            positionMs = controller.currentPosition.coerceAtLeast(0L),
                            durationMs = controller.duration.takeIf { d -> d > 0 } ?: it.durationMs,
                            shuffleEnabled = planner.shuffleEnabled,
                            repeatMode = planner.repeatMode,
                        )
                    }
                    if (controller.isPlaying) startPositionTicker()
                    if (!isExplicitlyStopped && currentQueue.isNotEmpty() && controller.mediaItemCount == 0) {
                        syncQueue(currentQueue, pendingStartSongId, pendingAutoPlay)
                    }
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    fun syncQueue(songs: List<Song>, selectSongId: Long? = null, autoPlay: Boolean = false) {
        val validSongs = songs.filter { song ->
            if (song.sourceType == SourceType.AUTHORIZED_ONLINE) {
                AuthorizedSourceValidator.validateUrl(song.audioUri) is SourceValidationResult.Authorized
            } else {
                song.audioUri.isNotBlank()
            }
        }
        currentQueue = validSongs
        pendingStartSongId = selectSongId
        pendingAutoPlay = autoPlay

        planner.updateQueue(validSongs, selectSongId = selectSongId)

        val controller = mediaController
        if (validSongs.isEmpty()) {
            controller?.clearMediaItems()
            activeWindowSongIds = emptyList()
            activeWindowIndex = 0
            _state.update {
                it.copy(
                    currentSongId = null,
                    nextSongId = null,
                    isPlaying = false,
                    positionMs = 0L,
                    durationMs = 0L,
                )
            }
            return
        }

        if (controller == null) {
            _state.update {
                it.copy(
                    currentSongId = planner.currentSongId,
                    nextSongId = planner.plannedNextSongId,
                    shuffleEnabled = planner.shuffleEnabled,
                    repeatMode = planner.repeatMode,
                )
            }
            return
        }

        if (isExplicitlyStopped && !autoPlay) {
            _state.update {
                it.copy(
                    currentSongId = planner.currentSongId,
                    nextSongId = planner.plannedNextSongId,
                    isExplicitlyStopped = true,
                    shuffleEnabled = planner.shuffleEnabled,
                    repeatMode = planner.repeatMode,
                )
            }
            return
        }

        val activeId = controller.currentMediaItem?.mediaId?.toLongOrNull()
        val selectedSong = planner.currentSong()
        if (!autoPlay && controller.mediaItemCount > 0 && activeId != null && activeId == planner.currentSongId) {
            // Keep active track playing/paused seamlessly while refreshing the queued Up Next slot
            replaceTrailingNextItem(controller, planner.peekNextSong())
            updateStateFromPlanner(controller, clearError = false)
            return
        }

        if (selectedSong != null) {
            startSongInController(
                controller = controller,
                targetSong = selectedSong,
                previousSong = null,
                nextSong = planner.peekNextSong(),
                autoPlay = autoPlay,
            )
            if (autoPlay) {
                notifySongTransition(selectedSong.id, forceNewToken = true)
            }
        }
    }

    fun playSong(song: Song, queue: List<Song>) {
        if (song.sourceType == SourceType.AUTHORIZED_ONLINE) {
            val check = AuthorizedSourceValidator.validateUrl(song.audioUri)
            if (check is SourceValidationResult.Rejected) {
                _state.update { it.copy(errorMessage = check.reason) }
                return
            }
        }
        isExplicitlyStopped = false
        isUserPaused = false
        lastAutoSkippedErrorCount = 0
        planner.clearBroken(song.id)

        val validQueue = queue.filter { item ->
            item.id == song.id || (if (item.sourceType == SourceType.AUTHORIZED_ONLINE) {
                AuthorizedSourceValidator.validateUrl(item.audioUri) is SourceValidationResult.Authorized
            } else {
                item.audioUri.isNotBlank()
            })
        }.ifEmpty { listOf(song) }

        currentQueue = validQueue
        pendingStartSongId = song.id
        pendingAutoPlay = true

        planner.updateQueue(validQueue, selectSongId = song.id)
        planner.onManualSongSelected(song.id, pushPreviousToHistory = true)

        val controller = mediaController
        if (controller == null) {
            _state.update {
                it.copy(
                    currentSongId = song.id,
                    nextSongId = planner.plannedNextSongId,
                    isExplicitlyStopped = false,
                    durationMs = song.durationMs,
                    positionMs = 0L,
                    shuffleEnabled = planner.shuffleEnabled,
                    repeatMode = planner.repeatMode,
                    errorMessage = null,
                )
            }
            return
        }

        startSongInController(
            controller = controller,
            targetSong = song,
            previousSong = null,
            nextSong = planner.peekNextSong(),
            autoPlay = true,
        )
        notifySongTransition(song.id, forceNewToken = true)
    }

    fun pausePlayback() {
        isUserPaused = true
        mediaController?.pause()
    }

    fun stopPlayback() {
        isExplicitlyStopped = true
        isUserPaused = true
        pendingAutoPlay = false
        lastAutoSkippedErrorCount = 0
        stopPositionTicker()
        mediaController?.let { controller ->
            controller.stop()
            controller.clearMediaItems()
        }
        activeWindowSongIds = emptyList()
        activeWindowIndex = 0
        _state.update {
            it.copy(
                isPlaying = false,
                isBuffering = false,
                isExplicitlyStopped = true,
                positionMs = 0L,
                errorMessage = null,
            )
        }
    }

    fun setVolume(volume: Float) {
        mediaController?.volume = volume.coerceIn(0f, 1f)
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        isExplicitlyStopped = false
        if (controller.mediaItemCount == 0 && currentQueue.isNotEmpty()) {
            val targetSong = planner.currentSong()
                ?: currentQueue.firstOrNull { planner.isEligibleForAutoPlay(it) }
                ?: currentQueue.first()
            isUserPaused = false
            planner.updateQueue(currentQueue, selectSongId = targetSong.id)
            planner.onManualSongSelected(targetSong.id, pushPreviousToHistory = false)
            startSongInController(
                controller = controller,
                targetSong = targetSong,
                previousSong = null,
                nextSong = planner.peekNextSong(),
                autoPlay = true,
            )
            notifySongTransition(targetSong.id, forceNewToken = true)
            return
        }
        if (controller.isPlaying) {
            isUserPaused = true
            controller.pause()
        } else {
            isUserPaused = false
            if (controller.playbackState == Player.STATE_IDLE || controller.playbackState == Player.STATE_ENDED) {
                controller.prepare()
            }
            controller.play()
        }
    }

    fun seekToNext() {
        val controller = mediaController ?: return
        isExplicitlyStopped = false
        isUserPaused = false
        lastAutoSkippedErrorCount = 0

        val previousSong = planner.currentSong()
        val nextSong = planner.advanceToNext(isManualNext = true) ?: run {
            _state.update {
                it.copy(
                    isPlaying = false,
                    nextSongId = null,
                    errorMessage = "No eligible full tracks available to play next.",
                )
            }
            return
        }

        startSongInController(
            controller = controller,
            targetSong = nextSong,
            previousSong = previousSong?.takeIf { it.id != nextSong.id && planner.isEligibleForAutoPlay(it) },
            nextSong = planner.peekNextSong(),
            autoPlay = true,
        )
        notifySongTransition(nextSong.id, forceNewToken = true)
    }

    fun seekToPrevious() {
        val controller = mediaController ?: return
        isExplicitlyStopped = false
        isUserPaused = false
        lastAutoSkippedErrorCount = 0

        val prevSong = planner.stepToPrevious() ?: planner.currentSong() ?: return
        startSongInController(
            controller = controller,
            targetSong = prevSong,
            previousSong = null,
            nextSong = planner.peekNextSong(),
            autoPlay = true,
        )
        notifySongTransition(prevSong.id, forceNewToken = true)
    }

    fun seekToPosition(positionMs: Long) {
        val controller = mediaController ?: return
        val clamped = positionMs.coerceAtLeast(0L)
        controller.seekTo(clamped)
        _state.update { it.copy(positionMs = clamped) }
    }

    fun toggleShuffle() {
        setShuffleEnabled(!planner.shuffleEnabled)
    }

    fun setShuffleEnabled(enabled: Boolean) {
        planner.setShuffleEnabled(enabled)
        mediaController?.let { controller ->
            if (!isExplicitlyStopped && controller.mediaItemCount > 0) {
                replaceTrailingNextItem(controller, planner.peekNextSong())
            }
        }
        _state.update {
            it.copy(
                shuffleEnabled = planner.shuffleEnabled,
                nextSongId = planner.plannedNextSongId,
            )
        }
    }

    fun cycleRepeatMode() {
        val nextMode = when (planner.repeatMode) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
        planner.setRepeatMode(nextMode)
        mediaController?.let { controller ->
            if (!isExplicitlyStopped && controller.mediaItemCount > 0) {
                replaceTrailingNextItem(controller, planner.peekNextSong())
            }
        }
        _state.update {
            it.copy(
                repeatMode = planner.repeatMode,
                nextSongId = planner.plannedNextSongId,
            )
        }
    }

    fun clearError() {
        _state.update { it.copy(errorMessage = null) }
    }

    private fun advanceAfterCompletionOrError(controller: MediaController) {
        val previousSong = planner.currentSong()
        val nextSong = planner.advanceToNext(isManualNext = false)
        if (nextSong == null) {
            _state.update {
                it.copy(
                    isPlaying = false,
                    isBuffering = false,
                    nextSongId = null,
                )
            }
            return
        }
        startSongInController(
            controller = controller,
            targetSong = nextSong,
            previousSong = previousSong?.takeIf { it.id != nextSong.id && planner.isEligibleForAutoPlay(it) },
            nextSong = planner.peekNextSong(),
            autoPlay = true,
        )
        notifySongTransition(nextSong.id, forceNewToken = true)
    }

    private fun startSongInController(
        controller: MediaController,
        targetSong: Song,
        previousSong: Song?,
        nextSong: Song?,
        autoPlay: Boolean,
        statusError: String? = null,
    ) {
        syncWindowAroundCurrent(
            controller = controller,
            currentSong = targetSong,
            previousSong = previousSong,
            nextSong = nextSong,
            preservePlayingState = false,
        )
        controller.prepare()
        if (autoPlay) {
            controller.play()
        }
        updateStateFromPlanner(
            controller = controller,
            positionMs = 0L,
            clearError = statusError == null,
            explicitError = statusError,
        )
    }

    private fun syncWindowAroundCurrent(
        controller: MediaController,
        currentSong: Song,
        previousSong: Song?,
        nextSong: Song?,
        preservePlayingState: Boolean,
    ) {
        val windowSongs = buildList {
            if (previousSong != null) add(previousSong)
            add(currentSong)
            if (nextSong != null) add(nextSong)
        }
        val startIndex = if (previousSong != null) 1 else 0
        val mediaItems = windowSongs.map { buildMediaItem(it) }
        activeWindowSongIds = windowSongs.map { it.id }
        activeWindowIndex = startIndex
        if (preservePlayingState) {
            replaceTrailingNextItem(controller, nextSong)
        } else {
            controller.setMediaItems(mediaItems, startIndex, 0L)
        }
    }

    private fun extendRollingWindowForward(
        controller: MediaController,
        previousSongId: Long?,
        currentSong: Song,
        nextSong: Song?,
    ) {
        var currentIdx = controller.currentMediaItemIndex.coerceAtLeast(0)
        // Trim extra past items so only at most [prev, current] precede the active index
        if (currentIdx > 1) {
            val removeCount = currentIdx - 1
            controller.removeMediaItems(0, removeCount)
            currentIdx = 1
        }
        // Replace or append upcoming item right after currentIdx
        val afterIdx = currentIdx + 1
        if (controller.mediaItemCount > afterIdx) {
            controller.removeMediaItems(afterIdx, controller.mediaItemCount)
        }
        if (nextSong != null) {
            controller.addMediaItem(buildMediaItem(nextSong))
        }
        val prevList = if (currentIdx == 1 && previousSongId != null) listOf(previousSongId) else emptyList()
        val nextList = if (nextSong != null) listOf(nextSong.id) else emptyList()
        activeWindowSongIds = prevList + listOf(currentSong.id) + nextList
        activeWindowIndex = currentIdx
    }

    private fun replaceTrailingNextItem(controller: MediaController, nextSong: Song?) {
        val currentIdx = controller.currentMediaItemIndex.coerceAtLeast(0)
        val afterIdx = currentIdx + 1
        if (controller.mediaItemCount > afterIdx) {
            controller.removeMediaItems(afterIdx, controller.mediaItemCount)
        }
        if (nextSong != null && controller.mediaItemCount > currentIdx) {
            controller.addMediaItem(buildMediaItem(nextSong))
        }
        val prefixIds = (0..minOf(currentIdx, controller.mediaItemCount - 1)).mapNotNull { idx ->
            controller.getMediaItemAt(idx).mediaId.toLongOrNull()
        }
        activeWindowSongIds = if (nextSong != null) prefixIds + nextSong.id else prefixIds
        activeWindowIndex = currentIdx
    }

    private fun updateStateFromPlanner(
        controller: MediaController,
        positionMs: Long = controller.currentPosition.coerceAtLeast(0L),
        clearError: Boolean = false,
        explicitError: String? = null,
    ) {
        val activeId = planner.currentSongId
        _state.update {
            it.copy(
                currentSongId = activeId,
                nextSongId = planner.plannedNextSongId,
                isExplicitlyStopped = isExplicitlyStopped,
                durationMs = controller.duration.takeIf { d -> d > 0 }
                    ?: currentSongDurationFallback(activeId),
                positionMs = positionMs,
                shuffleEnabled = planner.shuffleEnabled,
                repeatMode = planner.repeatMode,
                errorMessage = explicitError ?: if (clearError) null else it.errorMessage,
            )
        }
    }

    private fun notifySongTransition(songId: Long, forceNewToken: Boolean) {
        val token = if (forceNewToken) {
            transitionCounter++
            "$songId#$transitionCounter"
        } else {
            "$songId#$transitionCounter"
        }
        if (lastTransitionToken == token) return
        lastTransitionToken = token
        onSongTransitionCallback?.invoke(songId)
    }

    private fun buildMediaItem(song: Song): MediaItem {
        val metadataBuilder = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
        song.artworkUri?.let { art ->
            runCatching { Uri.parse(art) }.getOrNull()?.let { metadataBuilder.setArtworkUri(it) }
        }
        return MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(song.audioUri)
            .setMediaMetadata(metadataBuilder.build())
            .build()
    }

    private fun isSongSourceAccessible(song: Song): Boolean {
        if (song.audioUri.isBlank()) return false
        return when (song.sourceType) {
            SourceType.AUTHORIZED_ONLINE ->
                AuthorizedSourceValidator.validateUrl(song.audioUri) is SourceValidationResult.Authorized
            SourceType.OFFLINE_LOCAL -> {
                val parsed = runCatching { Uri.parse(song.audioUri) }.getOrNull() ?: return false
                when (parsed.scheme?.lowercase()) {
                    "file" -> parsed.path?.let { File(it).exists() } == true
                    else -> true
                }
            }
            SourceType.BUNDLED -> true
        }
    }

    private fun currentSongDurationFallback(songId: Long?): Long {
        if (songId == null) return 0L
        return currentQueue.firstOrNull { it.id == songId }?.durationMs ?: 0L
    }

    private fun startPositionTicker() {
        if (positionTickerJob?.isActive == true) return
        positionTickerJob = scope.launch {
            while (true) {
                val controller = mediaController
                if (controller != null) {
                    val pos = controller.currentPosition.coerceAtLeast(0L)
                    val dur = controller.duration.takeIf { it > 0 }
                        ?: currentSongDurationFallback(controller.currentMediaItem?.mediaId?.toLongOrNull())
                    _state.update { it.copy(positionMs = pos, durationMs = dur) }
                }
                delay(100L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    fun release() {
        isReleased = true
        stopPositionTicker()
        mediaController?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        mediaController = null
    }
}
