package com.example.data.local

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.example.model.SongColorGenerator
import com.example.model.SourceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaStoreAudioScanner(
    private val context: Context,
    private val dao: SunozaDao,
) {
    private var observer: ContentObserver? = null

    fun hasAudioPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
    }

    fun registerObserver(onChanged: () -> Unit) {
        if (observer != null || !hasAudioPermission()) return
        val contentObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                onChanged()
            }
        }
        observer = contentObserver
        runCatching {
            context.contentResolver.registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                true,
                contentObserver,
            )
        }
    }

    fun unregisterObserver() {
        observer?.let {
            runCatching { context.contentResolver.unregisterContentObserver(it) }
        }
        observer = null
    }

    suspend fun scanAndSync(): Int = withContext(Dispatchers.IO) {
        if (!hasAudioPermission()) return@withContext 0

        val resolver = context.contentResolver
        val projection = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.ARTIST)
            add(MediaStore.Audio.Media.ALBUM)
            add(MediaStore.Audio.Media.ALBUM_ID)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.DATE_ADDED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.Audio.Media.RELATIVE_PATH)
            } else {
                @Suppress("DEPRECATION")
                add(MediaStore.Audio.Media.DATA)
            }
        }.toTypedArray()

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 5000"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        val foundMediaStoreIds = HashSet<Long>()
        val toInsert = mutableListOf<SongEntity>()
        var lastColor: Long? = null

        runCatching {
            resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder,
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val relPathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
                } else {
                    -1
                }
                @Suppress("DEPRECATION")
                val dataCol = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                } else {
                    -1
                }

                while (cursor.moveToNext()) {
                    val mediaId = cursor.getLong(idCol)
                    foundMediaStoreIds.add(mediaId)

                    val existing = dao.getSongByMediaStoreId(mediaId)
                    if (existing != null) continue

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        mediaId,
                    ).toString()

                    if (dao.getSongByUri(contentUri) != null) continue

                    val rawTitle = cursor.getString(titleCol)?.trim().orEmpty()
                    val rawArtist = cursor.getString(artistCol)?.trim().orEmpty()
                    val rawAlbum = cursor.getString(albumCol)?.trim().orEmpty()
                    val albumId = cursor.getLong(albumIdCol)
                    val durationMs = cursor.getLong(durationCol).coerceAtLeast(1_000L)
                    val dateAddedSec = cursor.getLong(dateCol)

                    val folder = when {
                        relPathCol >= 0 -> {
                            cursor.getString(relPathCol)
                                ?.trim('/')
                                ?.substringAfterLast('/')
                                ?.ifBlank { "Internal Audio" }
                                ?: "Internal Audio"
                        }
                        dataCol >= 0 -> {
                            val path = cursor.getString(dataCol).orEmpty()
                            File(path).parentFile?.name?.ifBlank { "Device Storage" } ?: "Device Storage"
                        }
                        else -> "Device Storage"
                    }

                    val artworkUri = if (albumId > 0L) {
                        ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"),
                            albumId,
                        ).toString()
                    } else {
                        null
                    }

                    val color = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = lastColor)
                    lastColor = color

                    val cleanArtist = if (rawArtist.isBlank() || rawArtist == "<unknown>") {
                        "Unknown Artist"
                    } else {
                        rawArtist
                    }

                    toInsert.add(
                        SongEntity(
                            title = rawTitle.ifBlank { "Track $mediaId" },
                            artist = cleanArtist,
                            audioUri = contentUri,
                            durationMs = durationMs,
                            backgroundColorArgb = color,
                            sourceType = SourceType.OFFLINE_LOCAL.name,
                            sourceLabel = "Device Library",
                            licenseName = "Local MediaStore",
                            isFavorite = false,
                            lyricsRaw = "",
                            addedAtMs = if (dateAddedSec > 0L) dateAddedSec * 1000L else System.currentTimeMillis(),
                            album = if (rawAlbum.isBlank() || rawAlbum == "<unknown>") "Single" else rawAlbum,
                            artworkUri = artworkUri,
                            folderName = folder,
                            genre = inferGenreFromFolderOrAlbum(folder, rawAlbum),
                            bpm = 104,
                            energyScore = 0.6f,
                            mood = "Balanced",
                            mediaStoreId = mediaId,
                        )
                    )
                }
            }
        }

        if (toInsert.isNotEmpty()) {
            dao.insertSongsIgnore(toInsert)
        }

        // Remove stale MediaStore songs that were deleted from device storage
        val existingIds = dao.getAllMediaStoreIds()
        val removed = existingIds.filter { it !in foundMediaStoreIds }
        if (removed.isNotEmpty()) {
            dao.deleteByMediaStoreIds(removed)
        }

        toInsert.size
    }

    private fun inferGenreFromFolderOrAlbum(folder: String, album: String): String {
        val text = "$folder $album".lowercase()
        return when {
            text.contains("rock") || text.contains("metal") -> "Rock"
            text.contains("jazz") -> "Jazz"
            text.contains("classic") || text.contains("symphony") -> "Classical"
            text.contains("chill") || text.contains("lofi") || text.contains("lo-fi") -> "Lo-Fi Chill"
            text.contains("hip") || text.contains("rap") -> "Hip-Hop"
            text.contains("pop") -> "Pop"
            text.contains("edm") || text.contains("dance") || text.contains("house") -> "Electronic"
            text.contains("acoustic") || text.contains("folk") -> "Acoustic"
            else -> "Local Audio"
        }
    }
}
