package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.remote.CuratedAuthorizedCatalog
import com.example.data.remote.OnlineTrackCandidate
import com.example.model.Song
import com.example.ui.SunozaUiState
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurfaceElevated

private enum class OnlineSearchScope(val label: String) {
    ALL("Songs & Artists"),
    ARTISTS("Artists"),
    ALBUMS("Albums & Archives"),
}

@Composable
fun OnlineScreen(
    uiState: SunozaUiState,
    onSearchQueryChange: (String) -> Unit,
    onSearchSubmit: (String) -> Unit,
    onPlayCandidate: (OnlineTrackCandidate) -> Unit,
    onAddCandidateToPlaylist: (OnlineTrackCandidate) -> Unit,
    onPlayPlaylistPack: (List<OnlineTrackCandidate>) -> Unit,
    onPlaySong: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onOpenAuthorizedUrlDialog: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var searchScope by remember { mutableStateOf(OnlineSearchScope.ALL) }
    val providerStatus = CuratedAuthorizedCatalog.providerStatus

    val scopedCandidates = remember(uiState.onlineCandidates, uiState.onlineSearchQuery, searchScope) {
        val q = uiState.onlineSearchQuery.trim()
        if (q.isEmpty()) {
            uiState.onlineCandidates
        } else {
            when (searchScope) {
                OnlineSearchScope.ALL -> uiState.onlineCandidates
                OnlineSearchScope.ARTISTS -> uiState.onlineCandidates.filter {
                    it.artist.contains(q, ignoreCase = true) || it.title.contains(q, ignoreCase = true)
                }.ifEmpty { uiState.onlineCandidates }
                OnlineSearchScope.ALBUMS -> uiState.onlineCandidates.filter {
                    it.providerName.contains(q, ignoreCase = true) || it.title.contains(q, ignoreCase = true)
                }.ifEmpty { uiState.onlineCandidates }
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SunozaObsidian)
            .testTag("online_screen"),
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            SunozaBrandHeader(
                title = "Online Streaming",
                subtitle = "Licensed Creative Commons & Public Domain",
                trailingContent = {
                    FilledTonalButton(
                        onClick = onOpenAuthorizedUrlDialog,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SunozaSurfaceElevated,
                            contentColor = SunozaIvory,
                        ),
                        modifier = Modifier.testTag("online_add_url_button"),
                    ) {
                        Icon(Icons.Filled.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("URL")
                    }
                },
            )
        }

        // Honest provider configuration status banner
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SunozaSurfaceElevated)
                    .border(1.dp, SunozaMint.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.VerifiedUser,
                    contentDescription = "Authorized streaming status",
                    tint = SunozaMint,
                    modifier = Modifier.size(20.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = providerStatus.activeProviderName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = providerStatus.statusMessage,
                        style = MaterialTheme.typography.labelMedium,
                        color = SunozaMutedText,
                    )
                }
            }
        }

        // Search Songs / Artists / Albums
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = uiState.onlineSearchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search songs, artists, albums…") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("online_tab_search_input"),
                    )
                    Button(
                        onClick = { onSearchSubmit(uiState.onlineSearchQuery) },
                        colors = ButtonDefaults.buttonColors(containerColor = SunozaPurple),
                        modifier = Modifier.testTag("online_tab_search_button"),
                    ) {
                        Text("Find")
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OnlineSearchScope.entries.forEach { scope ->
                        FilterChip(
                            selected = searchScope == scope,
                            onClick = { searchScope = scope },
                            label = { Text(scope.label) },
                        )
                    }
                }
            }
        }

        // Popular Online Playlists
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeading(
                    title = "Popular Playlists",
                    subtitle = "Curated authorized open-license sessions",
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(CuratedAuthorizedCatalog.popularPlaylists, key = { it.id }) { pack ->
                        Column(
                            modifier = Modifier
                                .width(220.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(SunozaSurfaceElevated)
                                .border(1.dp, SunozaPurple.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                                .clickable { onPlayPlaylistPack(pack.tracks) }
                                .padding(16.dp)
                                .testTag("online_pack_${pack.id}"),
                        ) {
                            Text(
                                text = pack.genre.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = SunozaOrange,
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = pack.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SunozaIvory,
                            )
                            Text(
                                text = pack.subtitle,
                                style = MaterialTheme.typography.labelMedium,
                                color = SunozaMutedText,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = "Play playlist",
                                    tint = SunozaPink,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Play ${pack.tracks.size} tracks",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SunozaPink,
                                )
                            }
                        }
                    }
                }
            }
        }

        // Trending & Music Discovery Results
        item {
            SectionHeading(
                title = if (uiState.onlineSearchQuery.isBlank()) "Trending & Discovery" else "Search Results",
                subtitle = "Tap to stream live or add to your playlists",
            )
        }

        if (uiState.isOnlineSearching) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator(color = SunozaPurple)
                }
            }
        } else {
            items(scopedCandidates, key = { it.id }) { candidate ->
                OnlineCandidateRow(
                    candidate = candidate,
                    onPlay = { onPlayCandidate(candidate) },
                    onAddToPlaylist = { onAddCandidateToPlaylist(candidate) },
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }

        // Recently Played Online
        if (uiState.recentlyPlayedOnlineSongs.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeading(
                    title = "Recently Played Online",
                    subtitle = "Your recent verified streams",
                )
            }
            items(uiState.recentlyPlayedOnlineSongs, key = { "rec_online_${it.id}" }) { song ->
                TrackRowItem(
                    song = song,
                    isCurrent = song.id == uiState.currentSong?.id,
                    onClick = { onPlaySong(song) },
                    onToggleFavorite = { onToggleFavorite(song) },
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }

        // Recommended Music
        if (uiState.recommendations.recommendedForYou.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeading(
                    title = "Recommended Music",
                    subtitle = "Personalized from your listening profile",
                )
            }
            items(uiState.recommendations.recommendedForYou.take(5), key = { "online_rec_${it.id}" }) { song ->
                TrackRowItem(
                    song = song,
                    isCurrent = song.id == uiState.currentSong?.id,
                    onClick = { onPlaySong(song) },
                    onToggleFavorite = { onToggleFavorite(song) },
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }
    }
}

@Composable
private fun OnlineCandidateRow(
    candidate: OnlineTrackCandidate,
    onPlay: () -> Unit,
    onAddToPlaylist: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SunozaSurfaceElevated)
            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onPlay)
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("online_track_${candidate.id}"),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SunozaPurple.copy(alpha = 0.22f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.CloudQueue,
                contentDescription = null,
                tint = SunozaMint,
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = candidate.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = SunozaIvory,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "${candidate.artist} · ${candidate.providerName}",
                style = MaterialTheme.typography.labelMedium,
                color = SunozaMutedText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "${candidate.licenseName} · ${formatDuration(candidate.durationMs)}",
                style = MaterialTheme.typography.labelSmall,
                color = SunozaMint,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        IconButton(
            onClick = onAddToPlaylist,
            modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.PlaylistAdd,
                contentDescription = "Add online song to playlist",
                tint = SunozaMutedText,
            )
        }

        IconButton(
            onClick = onPlay,
            modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
            Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = "Stream online song",
                tint = SunozaIvory,
            )
        }
    }
}
