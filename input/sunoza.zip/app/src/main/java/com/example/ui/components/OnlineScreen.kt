package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.remote.CuratedAuthorizedCatalog
import com.example.data.remote.OnlineTrackCandidate
import com.example.model.Song
import com.example.ui.SunozaUiState
import com.example.ui.theme.SunozaErrorRed
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated

enum class OnlinePlaybackFilter(val label: String) {
    ALL("All"),
    FULL_TRACKS("Full Tracks"),
    PREVIEWS("Previews (30s)"),
}

private enum class OnlineSearchScope(val label: String) {
    ALL("All Fields"),
    TITLES("Titles"),
    ARTISTS("Artists"),
    ALBUMS("Albums"),
}

@Composable
fun OnlineScreen(
    uiState: SunozaUiState,
    onSearchQueryChange: (String) -> Unit,
    onSearchSubmit: (String) -> Unit,
    onLoadMore: () -> Unit,
    onPlayCandidate: (OnlineTrackCandidate) -> Unit,
    onAddCandidateToPlaylist: (OnlineTrackCandidate) -> Unit,
    onPlayPlaylistPack: (List<OnlineTrackCandidate>) -> Unit,
    onPlaySong: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onOpenAuthorizedUrlDialog: () -> Unit,
    onInspectAttribution: (OnlineTrackCandidate) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    var playbackFilter by remember { mutableStateOf(OnlinePlaybackFilter.ALL) }
    var searchScope by remember { mutableStateOf(OnlineSearchScope.ALL) }
    val providerStatus = CuratedAuthorizedCatalog.providerStatus
    val keyboardController = LocalSoftwareKeyboardController.current

    val scopedCandidates = remember(uiState.onlineCandidates, uiState.onlineSearchQuery, searchScope) {
        val q = uiState.onlineSearchQuery.trim()
        if (q.isEmpty() || searchScope == OnlineSearchScope.ALL) {
            uiState.onlineCandidates
        } else {
            val tokens = q.lowercase().split(Regex("""\s+""")).filter { it.isNotBlank() }
            when (searchScope) {
                OnlineSearchScope.ALL -> uiState.onlineCandidates
                OnlineSearchScope.TITLES -> uiState.onlineCandidates.filter { track ->
                    tokens.all { track.title.contains(it, ignoreCase = true) }
                }
                OnlineSearchScope.ARTISTS -> uiState.onlineCandidates.filter { track ->
                    tokens.all { track.artist.contains(it, ignoreCase = true) }
                }
                OnlineSearchScope.ALBUMS -> uiState.onlineCandidates.filter { track ->
                    tokens.all {
                        track.album.contains(it, ignoreCase = true) ||
                            track.providerName.contains(it, ignoreCase = true)
                    }
                }
            }
        }
    }

    val fullTracks = remember(scopedCandidates, playbackFilter) {
        if (playbackFilter == OnlinePlaybackFilter.PREVIEWS) {
            emptyList()
        } else {
            scopedCandidates.filterNot {
                it.isPreviewOnly || it.streamUrl.contains("audio-ssl.itunes.apple.com", ignoreCase = true)
            }
        }
    }

    val previewTracks = remember(scopedCandidates, playbackFilter) {
        if (playbackFilter == OnlinePlaybackFilter.FULL_TRACKS) {
            emptyList()
        } else {
            scopedCandidates.filter {
                it.isPreviewOnly || it.streamUrl.contains("audio-ssl.itunes.apple.com", ignoreCase = true)
            }
        }
    }

    val totalVisibleCount = fullTracks.size + previewTracks.size

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SunozaObsidian)
            .testTag("online_screen"),
        contentPadding = PaddingValues(bottom = 132.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            SunozaBrandHeader(
                title = "Online Streaming",
                subtitle = "Audius · Archive CC · Wikimedia · iTunes 30s Previews",
                trailingContent = {
                    FilledTonalButton(
                        onClick = onOpenAuthorizedUrlDialog,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SunozaSurfaceElevated,
                            contentColor = SunozaIvory,
                        ),
                        modifier = Modifier.testTag("online_add_url_button"),
                    ) {
                        Icon(Icons.Filled.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("URL")
                    }
                },
            )
        }

        // Provider configuration / legality status banner
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SunozaSurfaceElevated)
                    .border(1.dp, SunozaMint.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.VerifiedUser,
                    contentDescription = "Authorized streaming status",
                    tint = SunozaMint,
                    modifier = Modifier.size(20.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = providerStatus.activeProviderName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = providerStatus.statusMessage,
                        style = MaterialTheme.typography.labelMedium,
                        color = SunozaMutedText,
                    )
                }
            }
        }

        // Search Songs / Artists / Albums + Full Track vs Preview Filters
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = uiState.onlineSearchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search available catalog (song, artist, album)…") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (uiState.onlineSearchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        onSearchQueryChange("")
                                        onSearchSubmit("")
                                    },
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                keyboardController?.hide()
                                onSearchSubmit(uiState.onlineSearchQuery)
                            },
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("online_tab_search_input"),
                    )
                    Button(
                        onClick = {
                            keyboardController?.hide()
                            onSearchSubmit(uiState.onlineSearchQuery)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SunozaPurple),
                        modifier = Modifier.testTag("online_tab_search_button"),
                    ) {
                        Text("Find")
                    }
                }

                // Playback length filter (Full Tracks vs Previews)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(OnlinePlaybackFilter.entries) { filter ->
                        FilterChip(
                            selected = playbackFilter == filter,
                            onClick = { playbackFilter = filter },
                            label = { Text(filter.label) },
                            modifier = Modifier.testTag("online_filter_${filter.name.lowercase()}"),
                        )
                    }
                }

                // Field matching filter (All Fields / Titles / Artists / Albums)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(OnlineSearchScope.entries) { scope ->
                        FilterChip(
                            selected = searchScope == scope,
                            onClick = { searchScope = scope },
                            label = { Text(scope.label) },
                            modifier = Modifier.testTag("online_scope_${scope.name.lowercase()}"),
                        )
                    }
                }
            }
        }

        // Clear Error / Offline Banner with Retry button
        if (!uiState.onlineErrorMessage.isNullOrBlank()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(SunozaErrorRed.copy(alpha = 0.14f))
                        .border(1.dp, SunozaErrorRed.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                        .testTag("online_error_banner"),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudOff,
                            contentDescription = "Connection error",
                            tint = SunozaErrorRed,
                        )
                        Text(
                            text = uiState.onlineErrorMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = SunozaIvory,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    FilledTonalButton(
                        onClick = { onSearchSubmit(uiState.onlineSearchQuery) },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SunozaSurface,
                            contentColor = SunozaIvory,
                        ),
                        modifier = Modifier.testTag("online_retry_button"),
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Retry")
                    }
                }
            }
        }

        // Popular Online Playlists (shown when browsing; hidden while actively searching so results appear immediately)
        if (uiState.onlineSearchQuery.isBlank()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeading(
                        title = "Popular Playlists",
                        subtitle = "Full-length Creative Commons sessions",
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(CuratedAuthorizedCatalog.popularPlaylists, key = { it.id }) { pack ->
                            Column(
                                modifier = Modifier
                                    .width(220.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(SunozaSurfaceElevated)
                                    .border(1.dp, SunozaPurple.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                                    .clickable { onPlayPlaylistPack(pack.tracks) }
                                    .padding(16.dp)
                                    .testTag("online_pack_${pack.id}"),
                            ) {
                                Text(
                                    text = pack.genre.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SunozaOrange,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = pack.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SunozaIvory,
                                )
                                Text(
                                    text = pack.subtitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SunozaMutedText,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = "Play playlist",
                                        tint = SunozaPink,
                                        modifier = Modifier.size(18.dp),
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Play ${pack.tracks.size} full tracks",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = SunozaPink,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (uiState.isOnlineSearching) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp)
                        .testTag("online_loading_indicator"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    CircularProgressIndicator(color = SunozaPurple)
                    Text(
                        text = "Searching Audius, Archive CC, Wikimedia & iTunes Previews…",
                        style = MaterialTheme.typography.labelMedium,
                        color = SunozaMutedText,
                    )
                }
            }
        } else if (totalVisibleCount == 0) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(SunozaSurfaceElevated)
                        .padding(24.dp)
                        .testTag("online_empty_state"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = if (playbackFilter == OnlinePlaybackFilter.FULL_TRACKS && uiState.onlineCandidates.isNotEmpty()) {
                            "No full-length matches in catalog"
                        } else {
                            "No matching tracks in available catalogs"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    Text(
                        text = uiState.onlineErrorMessage
                            ?: if (playbackFilter == OnlinePlaybackFilter.FULL_TRACKS &&
                                uiState.onlineCandidates.any { it.isPreviewOnly }
                            ) {
                                "Audius, Internet Archive CC, and Wikimedia Commons returned no full tracks for \"${uiState.onlineSearchQuery}\". 30-second iTunes previews are kept separate and are not shown under Full Tracks."
                            } else if (uiState.onlineCandidates.isNotEmpty()) {
                                "No tracks matched your active filter (${playbackFilter.label} / ${searchScope.label}). Switch back to All to see loaded results."
                            } else {
                                "No matches found in Audius Open Catalog, Internet Archive CC, Wikimedia Commons, or iTunes Previews. Try another artist, song title, or genre."
                            },
                        style = MaterialTheme.typography.bodyMedium,
                        color = SunozaMutedText,
                    )
                }
            }
        } else {
            // Section 1: Prioritized Full-Length Tracks
            if (fullTracks.isNotEmpty()) {
                item {
                    SectionHeading(
                        title = if (uiState.onlineSearchQuery.isBlank()) "Trending Full Tracks" else "Full-Length Tracks",
                        subtitle = "${fullTracks.size} full tracks from Audius, Archive CC, Wikimedia & SoundHelix",
                        actionLabel = "Play All",
                        onActionClick = { onPlayPlaylistPack(fullTracks) },
                    )
                }

                items(fullTracks, key = { "full_${it.id}" }) { candidate ->
                    val isCurrentStream = uiState.currentSong?.audioUri == candidate.streamUrl
                    val isPlayingThis = isCurrentStream && uiState.playback.isPlaying
                    val isBufferingThis = isCurrentStream && uiState.playback.isBuffering

                    OnlineCandidateRow(
                        candidate = candidate,
                        isActive = isCurrentStream,
                        isPlaying = isPlayingThis,
                        isBuffering = isBufferingThis,
                        onPlay = { onPlayCandidate(candidate) },
                        onAddToPlaylist = { onAddCandidateToPlaylist(candidate) },
                        onInspectAttribution = { onInspectAttribution(candidate) },
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            } else if (playbackFilter == OnlinePlaybackFilter.ALL && previewTracks.isNotEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SunozaOrange.copy(alpha = 0.12f))
                            .border(1.dp, SunozaOrange.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                            .testTag("online_no_full_tracks_notice"),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = "No Full-Length Tracks Found",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = SunozaOrange,
                        )
                        Text(
                            text = "Audius, Internet Archive CC, and Wikimedia Commons had no full-length matches for this search. Sunoza will not silently play a 30s preview as a full track — the items below are 30-second Apple iTunes previews only.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SunozaIvory,
                        )
                    }
                }
            }

            // Section 2: Clearly Separated 30s Previews
            if (previewTracks.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    SectionHeading(
                        title = "Preview Only · 30s Samples",
                        subtitle = "${previewTracks.size} official 30s previews · Provided courtesy of iTunes (streaming only)",
                    )
                }

                items(previewTracks, key = { "preview_${it.id}" }) { candidate ->
                    val isCurrentStream = uiState.currentSong?.audioUri == candidate.streamUrl
                    val isPlayingThis = isCurrentStream && uiState.playback.isPlaying
                    val isBufferingThis = isCurrentStream && uiState.playback.isBuffering

                    OnlineCandidateRow(
                        candidate = candidate,
                        isActive = isCurrentStream,
                        isPlaying = isPlayingThis,
                        isBuffering = isBufferingThis,
                        onPlay = { onPlayCandidate(candidate) },
                        onAddToPlaylist = { onAddCandidateToPlaylist(candidate) },
                        onInspectAttribution = { onInspectAttribution(candidate) },
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            }

            // Pagination: Load More Results
            if (uiState.canLoadMoreOnline || uiState.isLoadingMoreOnline) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        OutlinedButton(
                            onClick = onLoadMore,
                            enabled = !uiState.isLoadingMoreOnline,
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("online_load_more_button"),
                        ) {
                            if (uiState.isLoadingMoreOnline) {
                                CircularProgressIndicator(
                                    color = SunozaPink,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Loading more results…", color = SunozaIvory)
                            } else {
                                Text("Load More Results", color = SunozaPink, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }

        // Recently Played Online
        if (uiState.recentlyPlayedOnlineSongs.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeading(
                    title = "Recently Played Online",
                    subtitle = "Your recent verified streams",
                )
            }
            items(uiState.recentlyPlayedOnlineSongs, key = { "rec_online_${it.id}" }) { song ->
                TrackRowItem(
                    song = song,
                    isCurrent = song.id == uiState.currentSong?.id,
                    onClick = { onPlaySong(song) },
                    onToggleFavorite = { onToggleFavorite(song) },
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }

        // Recommended Music
        if (uiState.recommendations.recommendedForYou.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeading(
                    title = "Recommended Music",
                    subtitle = "Personalized from your listening profile",
                )
            }
            items(uiState.recommendations.recommendedForYou.take(5), key = { "online_rec_${it.id}" }) { song ->
                TrackRowItem(
                    song = song,
                    isCurrent = song.id == uiState.currentSong?.id,
                    onClick = { onPlaySong(song) },
                    onToggleFavorite = { onToggleFavorite(song) },
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }
    }
}

@Composable
private fun OnlineCandidateRow(
    candidate: OnlineTrackCandidate,
    isActive: Boolean,
    isPlaying: Boolean,
    isBuffering: Boolean,
    onPlay: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onInspectAttribution: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val uriHandler = LocalUriHandler.current
    val durationLabel = if (candidate.durationMs > 0L) {
        formatDuration(candidate.durationMs)
    } else {
        "Full Stream"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isActive) SunozaPurple.copy(alpha = 0.18f) else SunozaSurfaceElevated)
            .border(
                width = 1.dp,
                color = if (isActive) SunozaPink else SunozaSubtleBorder,
                shape = RoundedCornerShape(16.dp),
            )
            .clickable(onClick = onPlay)
            .padding(start = 12.dp, end = 8.dp, top = 12.dp, bottom = 6.dp)
            .testTag("online_track_${candidate.id}"),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SunozaPurple.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) {
                if (!candidate.artworkUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = candidate.artworkUrl,
                        contentDescription = "${candidate.title} album art",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.CloudQueue,
                        contentDescription = null,
                        tint = SunozaMint,
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = candidate.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isActive) SunozaPink else SunozaIvory,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (candidate.isPreviewOnly) {
                        Text(
                            text = "PREVIEW ONLY",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SunozaObsidian,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(SunozaOrange)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                .testTag("preview_badge_${candidate.id}"),
                        )
                    }
                }
                Text(
                    text = "${candidate.artist} · ${candidate.album}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SunozaMutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val metaLine = if (candidate.isPreviewOnly) {
                    val fullLen = candidate.fullTrackDurationMs?.let { " · Album len ${formatDuration(it)}" }.orEmpty()
                    "${candidate.providerName} · Plays $durationLabel preview$fullLen"
                } else {
                    val licenseTag = if (candidate.isLicenseVerified) candidate.licenseName else "Verify Track License"
                    "${candidate.providerName} · $durationLabel · $licenseTag"
                }
                Text(
                    text = metaLine,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (candidate.isPreviewOnly) SunozaOrange else SunozaMint,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            IconButton(
                onClick = onPlay,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(CircleShape)
                    .background(if (isActive) SunozaPink else SunozaSurface)
                    .testTag("online_play_button_${candidate.id}"),
            ) {
                if (isBuffering) {
                    CircularProgressIndicator(
                        color = SunozaIvory,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(18.dp),
                    )
                } else {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pause online song" else "Stream online song",
                        tint = SunozaIvory,
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (candidate.isPreviewOnly) {
                val storeUrl = candidate.externalStoreUrl ?: candidate.sourcePageUrl
                Text(
                    text = candidate.attributionText.ifBlank { "Provided courtesy of iTunes" },
                    style = MaterialTheme.typography.labelSmall,
                    color = SunozaMutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (!storeUrl.isNullOrBlank()) {
                    Text(
                        text = "Apple Music / iTunes",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SunozaSurface)
                            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(6.dp))
                            .clickable { runCatching { uriHandler.openUri(storeUrl) } }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("itunes_store_badge_${candidate.id}"),
                    )
                }
            } else {
                Text(
                    text = candidate.attributionText.ifBlank {
                        if (candidate.isLicenseVerified) "License verified · Tap info for terms" else "Tap info for rights & attribution"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = SunozaMutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
            }

            IconButton(
                onClick = onInspectAttribution,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("online_info_button_${candidate.id}"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = "Track license and attribution",
                    tint = SunozaMutedText,
                )
            }

            IconButton(
                onClick = onAddToPlaylist,
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.PlaylistAdd,
                    contentDescription = "Add online song to playlist",
                    tint = SunozaMutedText,
                )
            }
        }
    }
}
