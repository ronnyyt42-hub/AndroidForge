package com.example.data.remote

import java.net.URI

data class AuthorizedDomainRule(
    val domain: String,
    val providerName: String,
    val unverifiedLabel: String,
)

sealed interface SourceValidationResult {
    data class Authorized(
        val normalizedUrl: String,
        val providerName: String,
        val licenseName: String,
        val isLicenseVerified: Boolean,
    ) : SourceValidationResult

    data class Rejected(val reason: String) : SourceValidationResult
}

object AuthorizedSourceValidator {
    val authorizedProviders: List<AuthorizedDomainRule> = listOf(
        AuthorizedDomainRule(
            domain = "audius.co",
            providerName = "Audius Open Catalog",
            unverifiedLabel = "Audius API Stream (Artist Opt-In — Verify Track License)",
        ),
        AuthorizedDomainRule(
            domain = "audio-ssl.itunes.apple.com",
            providerName = "Apple iTunes Preview",
            unverifiedLabel = "Apple iTunes 30s Preview (Promotional Only)",
        ),
        AuthorizedDomainRule(
            domain = "archive.org",
            providerName = "Internet Archive Audio",
            unverifiedLabel = "External Archive.org URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "upload.wikimedia.org",
            providerName = "Wikimedia Commons",
            unverifiedLabel = "External Wikimedia URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "commons.wikimedia.org",
            providerName = "Wikimedia Commons",
            unverifiedLabel = "External Wikimedia URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "files.freemusicarchive.org",
            providerName = "Free Music Archive",
            unverifiedLabel = "External FMA URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "freemusicarchive.org",
            providerName = "Free Music Archive",
            unverifiedLabel = "External FMA URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "incompetech.com",
            providerName = "Incompetech",
            unverifiedLabel = "External Incompetech URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "opengameart.org",
            providerName = "OpenGameArt",
            unverifiedLabel = "External OpenGameArt URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "ccmixter.org",
            providerName = "ccMixter",
            unverifiedLabel = "External ccMixter URL (License Unverified — Confirm Rights)",
        ),
        AuthorizedDomainRule(
            domain = "soundhelix.com",
            providerName = "SoundHelix Audio Examples",
            unverifiedLabel = "SoundHelix Example Audio (Attribution Required — Verify Commercial Terms)",
        ),
    )

    private val allowedExtensions = setOf("mp3", "ogg", "wav", "flac", "m4a", "aac", "opus")

    private val nonCommercialRegex = Regex(
        """(\bby-nc(-sa|-nd)?\b|/licenses/by-nc|/nc/|non-?commercial|\bcc[\s_-]?by[\s_-]?nc\b)""",
        RegexOption.IGNORE_CASE,
    )

    fun isNonCommercialLicense(rawLicense: String?): Boolean {
        if (rawLicense.isNullOrBlank()) return false
        return nonCommercialRegex.containsMatchIn(rawLicense)
    }

    fun validateUrl(rawUrl: String, explicitLicense: String? = null): SourceValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return SourceValidationResult.Rejected("Please enter an HTTPS audio URL.")
        }

        val uri = runCatching { URI(trimmed.replace(" ", "%20")) }.getOrNull()
            ?: return SourceValidationResult.Rejected("Invalid URL format.")

        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme != "https") {
            return SourceValidationResult.Rejected("Only secure HTTPS streams from authorized sources are permitted.")
        }

        val host = uri.host?.lowercase()?.removePrefix("www.").orEmpty()
        if (host.isEmpty()) {
            return SourceValidationResult.Rejected("Missing host in stream URL.")
        }

        val matchedRule = authorizedProviders.firstOrNull { rule ->
            host == rule.domain || host.endsWith(".${rule.domain}")
        } ?: return SourceValidationResult.Rejected(
            "Source \"$host\" is not in Sunoza's authorized streaming registry."
        )

        val path = uri.path?.lowercase().orEmpty()
        val ext = path.substringAfterLast('.', "")
        val hasAudioExtension = ext in allowedExtensions
        val isArchiveDownload = matchedRule.domain == "archive.org" && path.contains("/download/")
        val isAudiusStream = matchedRule.domain == "audius.co" && path.contains("/stream")

        if (!hasAudioExtension && !isArchiveDownload && !isAudiusStream) {
            return SourceValidationResult.Rejected(
                "URL must point directly to a supported audio stream (.mp3, .ogg, .wav, .flac, .m4a, .aac)."
            )
        }

        if (explicitLicense.isNullOrBlank()) {
            return SourceValidationResult.Authorized(
                normalizedUrl = trimmed,
                providerName = matchedRule.providerName,
                licenseName = matchedRule.unverifiedLabel,
                isLicenseVerified = false,
            )
        }

        val lowerLicense = explicitLicense.lowercase()
        if (isNonCommercialLicense(explicitLicense) || lowerLicense.contains("all rights reserved")) {
            return SourceValidationResult.Rejected(
                "Non-commercial (-NC) or All Rights Reserved tracks are excluded from Sunoza production results."
            )
        }

        val isVerifiedOpenLicense = lowerLicense.contains("creativecommons") ||
            lowerLicense.contains("creative commons") ||
            lowerLicense.contains("publicdomain") ||
            lowerLicense.contains("public domain") ||
            lowerLicense.contains("cc0") ||
            lowerLicense.contains("cc-by") ||
            lowerLicense.contains("cc by") ||
            lowerLicense.contains("cc-sa") ||
            lowerLicense.contains("pd-")

        val isPlatformOptInOrPreview = lowerLicense.contains("audius") ||
            lowerLicense.contains("artist authorized") ||
            lowerLicense.contains("official 30s preview") ||
            lowerLicense.contains("preview only") ||
            lowerLicense.contains("apple itunes 30s preview") ||
            lowerLicense.contains("soundhelix example audio")

        if (!isVerifiedOpenLicense && !isPlatformOptInOrPreview) {
            return SourceValidationResult.Rejected(
                "Track license could not be verified as a commercial-safe open license or official preview."
            )
        }

        val (resolvedLabel, isVerified) = when {
            lowerLicense.contains("apple itunes") ||
                lowerLicense.contains("official 30s preview") ||
                lowerLicense.contains("preview only") ->
                "Apple iTunes 30s Preview (Promotional Only)" to false
            lowerLicense.contains("audius") || lowerLicense.contains("artist authorized") ->
                "Audius API Stream (Artist Opt-In — Verify Track License)" to false
            lowerLicense.contains("soundhelix example audio") ->
                matchedRule.unverifiedLabel to false
            else ->
                (formatLicenseLabel(explicitLicense) ?: matchedRule.unverifiedLabel) to true
        }

        return SourceValidationResult.Authorized(
            normalizedUrl = trimmed,
            providerName = matchedRule.providerName,
            licenseName = resolvedLabel,
            isLicenseVerified = isVerified,
        )
    }

    private fun formatLicenseLabel(rawLicense: String?): String? {
        if (rawLicense.isNullOrBlank()) return null
        val lower = rawLicense.lowercase()
        return when {
            lower.contains("publicdomain/zero") || lower.contains("cc0") -> "CC0 Public Domain"
            lower.contains("publicdomain/mark") || lower.contains("publicdomain") || lower.contains("public domain") -> "Public Domain"
            lower.contains("by-nc") -> "CC BY-NC (Excluded)"
            lower.contains("by-sa") -> "CC BY-SA"
            lower.contains("by-nd") -> "CC BY-ND"
            lower.contains("licenses/by") || lower.contains("cc-by") || lower.contains("cc by") -> "CC BY"
            lower.contains("creativecommons.org") || lower.contains("creative commons") -> "Creative Commons (Commercial-Safe)"
            else -> rawLicense
        }
    }
}
