package com.example.data.remote

import android.net.Uri

data class AuthorizedDomainRule(
    val domain: String,
    val providerName: String,
    val defaultLicense: String,
)

sealed interface SourceValidationResult {
    data class Authorized(
        val normalizedUrl: String,
        val providerName: String,
        val licenseName: String,
    ) : SourceValidationResult

    data class Rejected(val reason: String) : SourceValidationResult
}

object AuthorizedSourceValidator {
    val authorizedProviders: List<AuthorizedDomainRule> = listOf(
        AuthorizedDomainRule(
            domain = "audius.co",
            providerName = "Audius Open Catalog",
            defaultLicense = "Artist Authorized Stream",
        ),
        AuthorizedDomainRule(
            domain = "audio-ssl.itunes.apple.com",
            providerName = "Apple iTunes Preview",
            defaultLicense = "Official 30s Preview",
        ),
        AuthorizedDomainRule(
            domain = "archive.org",
            providerName = "Internet Archive Audio",
            defaultLicense = "Creative Commons / Public Domain",
        ),
        AuthorizedDomainRule(
            domain = "upload.wikimedia.org",
            providerName = "Wikimedia Commons",
            defaultLicense = "Creative Commons / Public Domain",
        ),
        AuthorizedDomainRule(
            domain = "commons.wikimedia.org",
            providerName = "Wikimedia Commons",
            defaultLicense = "Creative Commons / Public Domain",
        ),
        AuthorizedDomainRule(
            domain = "files.freemusicarchive.org",
            providerName = "Free Music Archive",
            defaultLicense = "Creative Commons",
        ),
        AuthorizedDomainRule(
            domain = "freemusicarchive.org",
            providerName = "Free Music Archive",
            defaultLicense = "Creative Commons",
        ),
        AuthorizedDomainRule(
            domain = "incompetech.com",
            providerName = "Incompetech",
            defaultLicense = "CC-BY 4.0",
        ),
        AuthorizedDomainRule(
            domain = "opengameart.org",
            providerName = "OpenGameArt",
            defaultLicense = "CC0 / CC-BY",
        ),
        AuthorizedDomainRule(
            domain = "ccmixter.org",
            providerName = "ccMixter",
            defaultLicense = "Creative Commons",
        ),
        AuthorizedDomainRule(
            domain = "soundhelix.com",
            providerName = "SoundHelix CC",
            defaultLicense = "Creative Commons",
        ),
    )

    private val allowedExtensions = setOf("mp3", "ogg", "wav", "flac", "m4a", "aac", "opus")

    fun validateUrl(rawUrl: String, explicitLicense: String? = null): SourceValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return SourceValidationResult.Rejected("Please enter an HTTPS audio URL.")
        }

        val uri = runCatching { Uri.parse(trimmed) }.getOrNull()
            ?: return SourceValidationResult.Rejected("Invalid URL format.")

        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme != "https") {
            return SourceValidationResult.Rejected("Only secure HTTPS streams from authorized sources are permitted.")
        }

        val host = uri.host?.lowercase()?.removePrefix("www.").orEmpty()
        if (host.isEmpty()) {
            return SourceValidationResult.Rejected("Missing host in stream URL.")
        }

        val matchedRule = authorizedProviders.firstOrNull { rule ->
            host == rule.domain || host.endsWith(".${rule.domain}")
        } ?: return SourceValidationResult.Rejected(
            "Source \"$host\" is not in Sunoza's authorized streaming registry."
        )

        val path = uri.path?.lowercase().orEmpty()
        val ext = path.substringAfterLast('.', "")
        val hasAudioExtension = ext in allowedExtensions
        val isArchiveDownload = matchedRule.domain == "archive.org" && path.contains("/download/")
        val isAudiusStream = matchedRule.domain == "audius.co" && path.contains("/stream")

        if (!hasAudioExtension && !isArchiveDownload && !isAudiusStream) {
            return SourceValidationResult.Rejected(
                "URL must point directly to a supported audio stream (.mp3, .ogg, .wav, .flac, .m4a, .aac)."
            )
        }

        if (explicitLicense != null && explicitLicense.isNotBlank()) {
            val lowerLicense = explicitLicense.lowercase()
            val isOpenOrOfficial = lowerLicense.contains("creativecommons") ||
                lowerLicense.contains("creative commons") ||
                lowerLicense.contains("publicdomain") ||
                lowerLicense.contains("public domain") ||
                lowerLicense.contains("cc0") ||
                lowerLicense.contains("cc-by") ||
                lowerLicense.contains("cc by") ||
                lowerLicense.contains("audius") ||
                lowerLicense.contains("artist authorized") ||
                lowerLicense.contains("official 30s preview")
            if (!isOpenOrOfficial) {
                return SourceValidationResult.Rejected(
                    "Track license could not be verified as open-license or official preview."
                )
            }
        }

        return SourceValidationResult.Authorized(
            normalizedUrl = trimmed,
            providerName = matchedRule.providerName,
            licenseName = formatLicenseLabel(explicitLicense) ?: matchedRule.defaultLicense,
        )
    }

    private fun formatLicenseLabel(rawLicense: String?): String? {
        if (rawLicense.isNullOrBlank()) return null
        val lower = rawLicense.lowercase()
        return when {
            lower.contains("publicdomain/zero") || lower.contains("cc0") -> "CC0 Public Domain"
            lower.contains("publicdomain/mark") || lower.contains("publicdomain") -> "Public Domain"
            lower.contains("licenses/by-sa") -> "CC BY-SA"
            lower.contains("licenses/by-nc") -> "CC BY-NC"
            lower.contains("licenses/by") -> "CC BY"
            lower.contains("creativecommons.org") -> "Creative Commons"
            else -> rawLicense
        }
    }
}
