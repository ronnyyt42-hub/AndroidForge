package com.example.player

import androidx.media3.common.Player
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import com.example.model.Song
import com.example.model.SourceType
import kotlin.random.Random

/**
 * Pure, deterministic-testable queue planner governing Sunoza's shuffle cycles,
 * sequential order, eligibility filtering, back history, and upcoming track prediction.
 */
class PlaybackQueuePlanner(
    private val random: Random = Random.Default,
    private val isSongAvailable: (Song) -> Boolean = { song ->
        song.audioUri.isNotBlank() &&
            (song.sourceType != SourceType.AUTHORIZED_ONLINE ||
                AuthorizedSourceValidator.validateUrl(song.audioUri) is SourceValidationResult.Authorized)
    },
) {
    var shuffleEnabled: Boolean = true
        private set

    var repeatMode: Int = Player.REPEAT_MODE_ALL
        private set

    var currentSongId: Long? = null
        private set

    var plannedNextSongId: Long? = null
        private set

    private var queue: List<Song> = emptyList()
    private val brokenSongIds = mutableSetOf<Long>()
    private val playedInCycleIds = mutableSetOf<Long>()
    private val backHistory = mutableListOf<Long>()

    fun isEligibleForAutoPlay(song: Song): Boolean {
        if (song.audioUri.isBlank()) return false
        if (song.isPreviewOnly) return false
        if (song.id in brokenSongIds) return false
        if (song.sourceType == SourceType.AUTHORIZED_ONLINE &&
            AuthorizedSourceValidator.validateUrl(song.audioUri) !is SourceValidationResult.Authorized
        ) {
            return false
        }
        return isSongAvailable(song)
    }

    fun updateQueue(songs: List<Song>, selectSongId: Long? = null) {
        val previousQueueIds = queue.map { it.id }
        queue = songs
        val queueIds = songs.map { it.id }.toSet()
        playedInCycleIds.retainAll(queueIds)
        backHistory.retainAll(queueIds)

        val resolvedCurrentId = when {
            selectSongId != null && selectSongId in queueIds -> selectSongId
            currentSongId != null && currentSongId in queueIds -> currentSongId
            else -> songs.firstOrNull { isEligibleForAutoPlay(it) }?.id ?: songs.firstOrNull()?.id
        }

        val currentChanged = resolvedCurrentId != currentSongId
        currentSongId = resolvedCurrentId
        if (resolvedCurrentId != null) {
            val currentSong = songs.firstOrNull { it.id == resolvedCurrentId }
            if (currentSong != null && isEligibleForAutoPlay(currentSong)) {
                playedInCycleIds.add(resolvedCurrentId)
            }
        }

        val eligibleCount = eligibleSongs().size
        val plannedValid = plannedNextSongId != null &&
            plannedNextSongId in queueIds &&
            songs.firstOrNull { it.id == plannedNextSongId }?.let { isEligibleForAutoPlay(it) } == true &&
            (repeatMode == Player.REPEAT_MODE_ONE || eligibleCount <= 1 || plannedNextSongId != currentSongId) &&
            !(shuffleEnabled && playedInCycleIds.contains(plannedNextSongId) && unplayedEligibleExcludingCurrent().isNotEmpty())

        val queueOrderChanged = previousQueueIds != songs.map { it.id }
        if (currentChanged || !plannedValid || !shuffleEnabled || repeatMode == Player.REPEAT_MODE_ONE || queueOrderChanged) {
            if (!shuffleEnabled || !plannedValid || currentChanged || repeatMode == Player.REPEAT_MODE_ONE) {
                plannedNextSongId = computeNextSongId(isManualNext = false)
            }
        }
    }

    fun setShuffleEnabled(enabled: Boolean) {
        if (shuffleEnabled == enabled) return
        shuffleEnabled = enabled
        plannedNextSongId = computeNextSongId(isManualNext = false)
    }

    fun setRepeatMode(mode: Int) {
        if (repeatMode == mode) return
        repeatMode = mode
        plannedNextSongId = computeNextSongId(isManualNext = false)
    }

    fun markBroken(songId: Long) {
        brokenSongIds.add(songId)
        playedInCycleIds.remove(songId)
        if (plannedNextSongId == songId || plannedNextSongId == null) {
            plannedNextSongId = computeNextSongId(isManualNext = false)
        }
    }

    fun clearBroken(songId: Long) {
        brokenSongIds.remove(songId)
    }

    fun clearAllBroken() {
        brokenSongIds.clear()
    }

    fun currentSong(): Song? = currentSongId?.let { id -> queue.firstOrNull { it.id == id } }

    fun peekNextSong(): Song? = plannedNextSongId?.let { id -> queue.firstOrNull { it.id == id } }

    fun onManualSongSelected(songId: Long, pushPreviousToHistory: Boolean = true) {
        clearBroken(songId)
        val previousId = currentSongId
        if (pushPreviousToHistory && previousId != null && previousId != songId) {
            pushToHistory(previousId)
        }
        currentSongId = songId
        queue.firstOrNull { it.id == songId }?.let { selected ->
            if (isEligibleForAutoPlay(selected)) {
                playedInCycleIds.add(songId)
            }
        }
        plannedNextSongId = computeNextSongId(isManualNext = false)
    }

    /**
     * Advances planner state after natural track completion, auto-skip on error, or manual Next.
     * Returns the selected next Song, or null if playback should stop cleanly.
     */
    fun advanceToNext(isManualNext: Boolean): Song? {
        if (!isManualNext && repeatMode == Player.REPEAT_MODE_ONE) {
            val current = currentSong()
            if (current != null && isEligibleForAutoPlay(current)) {
                plannedNextSongId = computeNextSongId(isManualNext = false)
                return current
            }
        }

        val eligible = eligibleSongs()
        if (eligible.isEmpty()) {
            plannedNextSongId = null
            return null
        }

        val chosenId = resolveChosenNextId(isManualNext = isManualNext, eligible = eligible) ?: run {
            plannedNextSongId = null
            return null
        }

        val chosenSong = queue.firstOrNull { it.id == chosenId } ?: return null
        val previousId = currentSongId
        if (previousId != null && previousId != chosenId) {
            pushToHistory(previousId)
        }

        // Start a fresh non-repeating cycle once all eligible songs in the active playlist have played
        val eligibleIds = eligible.map { it.id }.toSet()
        if (shuffleEnabled && playedInCycleIds.containsAll(eligibleIds)) {
            playedInCycleIds.clear()
        }

        currentSongId = chosenId
        playedInCycleIds.add(chosenId)
        plannedNextSongId = computeNextSongId(isManualNext = false)
        return chosenSong
    }

    /**
     * Synchronizes planner state when ExoPlayer automatically transitioned in the background
     * to a pre-queued item (typically [plannedNextSongId]).
     */
    fun onExoPlayerTransitionedTo(songId: Long) {
        if (songId == currentSongId && repeatMode != Player.REPEAT_MODE_ONE) {
            return
        }
        val previousId = currentSongId
        if (previousId != null && previousId != songId) {
            pushToHistory(previousId)
        }

        val eligibleIds = eligibleSongs().map { it.id }.toSet()
        if (shuffleEnabled && eligibleIds.isNotEmpty() && playedInCycleIds.containsAll(eligibleIds)) {
            playedInCycleIds.clear()
        }

        currentSongId = songId
        queue.firstOrNull { it.id == songId }?.let { song ->
            if (isEligibleForAutoPlay(song)) {
                playedInCycleIds.add(songId)
            }
        }
        plannedNextSongId = computeNextSongId(isManualNext = false)
    }

    fun stepToPrevious(): Song? {
        val eligibleIds = eligibleSongs().map { it.id }.toSet()
        while (backHistory.isNotEmpty()) {
            val candidateId = backHistory.removeAt(backHistory.lastIndex)
            if (candidateId != currentSongId && candidateId in eligibleIds) {
                currentSongId = candidateId
                playedInCycleIds.add(candidateId)
                plannedNextSongId = computeNextSongId(isManualNext = false)
                return queue.firstOrNull { it.id == candidateId }
            }
        }

        if (queue.isEmpty()) return null
        val currentIdx = queue.indexOfFirst { it.id == currentSongId }
        val startOffset = if (currentIdx >= 0) currentIdx else 0
        for (step in 1..queue.size) {
            val idx = ((startOffset - step) % queue.size + queue.size) % queue.size
            val candidate = queue[idx]
            if (isEligibleForAutoPlay(candidate) && (eligibleIds.size <= 1 || candidate.id != currentSongId)) {
                currentSongId = candidate.id
                playedInCycleIds.add(candidate.id)
                plannedNextSongId = computeNextSongId(isManualNext = false)
                return candidate
            }
        }
        return null
    }

    fun getPlayedInCycleCount(): Int = playedInCycleIds.size

    fun eligibleCount(): Int = eligibleSongs().size

    private fun resolveChosenNextId(isManualNext: Boolean, eligible: List<Song>): Long? {
        val planned = plannedNextSongId
        val plannedStillEligible = planned != null && eligible.any { it.id == planned }
        if (plannedStillEligible && (!isManualNext || repeatMode != Player.REPEAT_MODE_ONE || eligible.size <= 1)) {
            if (!isManualNext || planned != currentSongId || eligible.size <= 1) {
                return planned
            }
        }
        return computeNextSongId(isManualNext = isManualNext)
    }

    private fun computeNextSongId(isManualNext: Boolean): Long? {
        val eligible = eligibleSongs()
        if (eligible.isEmpty()) return null

        if (!isManualNext && repeatMode == Player.REPEAT_MODE_ONE) {
            val current = currentSong()
            if (current != null && isEligibleForAutoPlay(current)) {
                return current.id
            }
        }

        if (shuffleEnabled) {
            val unplayed = unplayedEligibleExcludingCurrent(eligible)
            if (unplayed.isNotEmpty()) {
                return unplayed[random.nextInt(unplayed.size)].id
            }
            if (!isManualNext && repeatMode == Player.REPEAT_MODE_OFF) {
                // In Shuffle + Repeat OFF, stop cleanly after every eligible track in the playlist has played once
                return null
            }
            val others = eligible.filter { it.id != currentSongId }
            return if (others.isNotEmpty()) {
                others[random.nextInt(others.size)].id
            } else if (repeatMode == Player.REPEAT_MODE_ALL || isManualNext) {
                eligible.first().id
            } else {
                null
            }
        }

        // Sequential queue order (Shuffle OFF)
        val currentIdx = queue.indexOfFirst { it.id == currentSongId }
        val wrap = repeatMode != Player.REPEAT_MODE_OFF || isManualNext
        if (currentIdx < 0) {
            return eligible.first().id
        }
        for (offset in 1..queue.size) {
            val rawIdx = currentIdx + offset
            if (!wrap && rawIdx >= queue.size) {
                return null
            }
            val candidate = queue[rawIdx % queue.size]
            if (isEligibleForAutoPlay(candidate)) {
                return candidate.id
            }
        }
        return null
    }

    private fun eligibleSongs(): List<Song> = queue.filter { isEligibleForAutoPlay(it) }

    private fun unplayedEligibleExcludingCurrent(eligible: List<Song> = eligibleSongs()): List<Song> =
        eligible.filter { it.id !in playedInCycleIds && it.id != currentSongId }

    private fun pushToHistory(songId: Long) {
        if (backHistory.lastOrNull() == songId) return
        backHistory.add(songId)
        if (backHistory.size > MAX_HISTORY_SIZE) {
            backHistory.removeAt(0)
        }
    }

    companion object {
        private const val MAX_HISTORY_SIZE = 100
    }
}
