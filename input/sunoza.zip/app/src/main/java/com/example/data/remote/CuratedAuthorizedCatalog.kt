package com.example.data.remote

data class OnlineTrackCandidate(
    val id: String,
    val title: String,
    val artist: String,
    val streamUrl: String,
    val durationMs: Long,
    val providerName: String,
    val licenseName: String,
    val lyricsRaw: String = "",
)

data class OnlinePlaylistPack(
    val id: String,
    val title: String,
    val subtitle: String,
    val genre: String,
    val tracks: List<OnlineTrackCandidate>,
)

data class OnlineProviderStatus(
    val activeProviderName: String,
    val isCommercialBackendConfigured: Boolean,
    val statusMessage: String,
)

object CuratedAuthorizedCatalog {
    val providerStatus = OnlineProviderStatus(
        activeProviderName = "Internet Archive CC & SoundHelix CC",
        isCommercialBackendConfigured = false,
        statusMessage = "Streaming via authorized open-license providers (Internet Archive Creative Commons & SoundHelix). Configure a backend proxy or licensed provider key via AI Studio Secrets to unlock commercial catalogs.",
    )

    val featuredTracks: List<OnlineTrackCandidate> = listOf(
        OnlineTrackCandidate(
            id = "soundhelix-1",
            title = "SoundHelix Song 1",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            durationMs = 372_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = """
                [00:00.00]Algorithmic pulse awakening in stereo
                [00:12.00]Layered arpeggios rising through the dark
                [00:24.00]Steady bassline carrying the motion forward
                [00:36.00]Harmonic chords unfolding in wide space
                [00:48.00]Instrumental drift — tap Edit Lyrics to customize
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-2",
            title = "SoundHelix Song 2",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            durationMs = 425_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = """
                [00:00.00]Electric motifs weaving through the night
                [00:14.00]Syncopated rhythm echoing across the room
                [00:28.00]Melodic shimmer floating over warm bass
                [00:42.00]Instrumental session — authorized open stream
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-3",
            title = "SoundHelix Song 3",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
            durationMs = 344_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = """
                [00:00.00]Clean synth chimes opening the third movement
                [00:15.00]Deep groove locking into the midnight tempo
                [00:30.00]Bright overtones glowing against solid dark
                [00:45.00]Authorized open stream via SoundHelix CC
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-4",
            title = "SoundHelix Song 4",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
            durationMs = 302_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = "",
        ),
        OnlineTrackCandidate(
            id = "soundhelix-5",
            title = "SoundHelix Song 5",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
            durationMs = 353_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = "",
        ),
        OnlineTrackCandidate(
            id = "soundhelix-6",
            title = "SoundHelix Song 6",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
            durationMs = 280_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = "",
        ),
    )

    val popularPlaylists: List<OnlinePlaylistPack> = listOf(
        OnlinePlaylistPack(
            id = "pack-electronic",
            title = "CC Synth & Groove",
            subtitle = "Upbeat Creative Commons electronic sessions",
            genre = "Electronic",
            tracks = featuredTracks.take(3),
        ),
        OnlinePlaylistPack(
            id = "pack-focus",
            title = "Deep Focus Streams",
            subtitle = "Continuous open-license instrumental loops",
            genre = "Ambient",
            tracks = featuredTracks.drop(3),
        ),
    )
}
