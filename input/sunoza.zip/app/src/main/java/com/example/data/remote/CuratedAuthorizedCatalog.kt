package com.example.data.remote

data class OnlineTrackCandidate(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "Single",
    val artworkUrl: String? = null,
    val genre: String = "Electronic",
    val streamUrl: String,
    val durationMs: Long,
    val providerName: String,
    val licenseName: String,
    val isPreviewOnly: Boolean = false,
    val lyricsRaw: String = "",
)

data class OnlinePlaylistPack(
    val id: String,
    val title: String,
    val subtitle: String,
    val genre: String,
    val tracks: List<OnlineTrackCandidate>,
)

data class OnlineProviderStatus(
    val activeProviderName: String,
    val isCommercialBackendConfigured: Boolean,
    val statusMessage: String,
)

object CuratedAuthorizedCatalog {
    val providerStatus = OnlineProviderStatus(
        activeProviderName = "Audius Open Catalog · iTunes Official Previews · Internet Archive CC",
        isCommercialBackendConfigured = false,
        statusMessage = "Live search & playback powered by Audius full-track open streams, Apple iTunes 30s official previews, and Internet Archive Creative Commons (no API key needed). Full commercial label streaming requires a licensed backend/API key.",
    )

    val featuredTracks: List<OnlineTrackCandidate> = listOf(
        OnlineTrackCandidate(
            id = "soundhelix-1",
            title = "SoundHelix Song 1",
            artist = "T. Schürger",
            album = "SoundHelix Generative CC",
            genre = "Electronic",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            durationMs = 372_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons",
            lyricsRaw = """
                [00:00.00]Algorithmic pulse awakening in stereo
                [00:12.00]Layered arpeggios rising through the dark
                [00:24.00]Steady bassline carrying the motion forward
                [00:36.00]Harmonic chords unfolding in wide space
                [00:48.00]Instrumental drift — tap Edit Lyrics to customize
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-2",
            title = "SoundHelix Song 2",
            artist = "T. Schürger",
            album = "SoundHelix Generative CC",
            genre = "Synthwave",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            durationMs = 425_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons",
            lyricsRaw = """
                [00:00.00]Electric motifs weaving through the night
                [00:14.00]Syncopated rhythm echoing across the room
                [00:28.00]Melodic shimmer floating over warm bass
                [00:42.00]Instrumental session — authorized open stream
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-3",
            title = "SoundHelix Song 3",
            artist = "T. Schürger",
            album = "SoundHelix Generative CC",
            genre = "Ambient",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
            durationMs = 344_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons",
            lyricsRaw = """
                [00:00.00]Clean synth chimes opening the third movement
                [00:15.00]Deep groove locking into the midnight tempo
                [00:30.00]Bright overtones glowing against solid dark
                [00:45.00]Authorized open stream via SoundHelix CC
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-4",
            title = "SoundHelix Song 4",
            artist = "T. Schürger",
            album = "SoundHelix Generative CC",
            genre = "Electronic",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
            durationMs = 302_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons",
        ),
        OnlineTrackCandidate(
            id = "soundhelix-5",
            title = "SoundHelix Song 5",
            artist = "T. Schürger",
            album = "SoundHelix Generative CC",
            genre = "Chill",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
            durationMs = 353_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons",
        ),
        OnlineTrackCandidate(
            id = "soundhelix-6",
            title = "SoundHelix Song 6",
            artist = "T. Schürger",
            album = "SoundHelix Generative CC",
            genre = "Focus",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
            durationMs = 280_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons",
        ),
    )

    val popularPlaylists: List<OnlinePlaylistPack> = listOf(
        OnlinePlaylistPack(
            id = "pack-electronic",
            title = "CC Synth & Groove",
            subtitle = "Full-length Creative Commons electronic sessions",
            genre = "Electronic",
            tracks = featuredTracks.take(3),
        ),
        OnlinePlaylistPack(
            id = "pack-focus",
            title = "Deep Focus Streams",
            subtitle = "Continuous open-license instrumental sets",
            genre = "Ambient",
            tracks = featuredTracks.drop(3),
        ),
    )
}
