package com.example

import android.app.Application
import com.example.data.local.SoundStudioPreferences
import com.example.data.local.SunozaDatabase
import com.example.data.remote.ArchiveOrgApi
import com.example.data.repository.MusicRepository
import com.example.player.AudioBpmAnalyzer
import com.example.player.MixFlowEngine
import com.example.player.PlaybackController
import com.example.player.SoundStudioEngine

class SunozaApplication : Application() {
    val database: SunozaDatabase by lazy { SunozaDatabase.getInstance(this) }
    val archiveApi: ArchiveOrgApi by lazy { ArchiveOrgApi.create() }
    val soundStudioPreferences: SoundStudioPreferences by lazy { SoundStudioPreferences(this) }
    val soundStudioEngine: SoundStudioEngine by lazy { SoundStudioEngine() }
    val audioBpmAnalyzer: AudioBpmAnalyzer by lazy { AudioBpmAnalyzer(this) }
    val musicRepository: MusicRepository by lazy {
        MusicRepository(
            context = this,
            dao = database.sunozaDao(),
            archiveApi = archiveApi,
        )
    }
    val playbackController: PlaybackController by lazy { PlaybackController(this) }
    val mixFlowEngine: MixFlowEngine by lazy {
        MixFlowEngine(
            context = this,
            bpmAnalyzer = audioBpmAnalyzer,
            onPauseMainPlayer = { playbackController.pausePlayback() },
        )
    }
}
