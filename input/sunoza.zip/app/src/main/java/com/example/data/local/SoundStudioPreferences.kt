package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.EqPreset
import com.example.model.ReverbOption
import com.example.model.SoundStudioState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sunozaPrefsDataStore by preferencesDataStore(name = "sunoza_sound_studio_prefs")

class SoundStudioPreferences(private val context: Context) {
    private object Keys {
        val ENABLED = booleanPreferencesKey("eq_enabled")
        val PRESET = stringPreferencesKey("eq_preset")
        val BANDS = stringPreferencesKey("eq_bands_csv")
        val BASS_BOOST = intPreferencesKey("bass_boost")
        val TREBLE_BOOST = floatPreferencesKey("treble_boost")
        val VIRTUALIZER = intPreferencesKey("virtualizer")
        val REVERB = stringPreferencesKey("reverb_option")
        val LOUDNESS = intPreferencesKey("loudness_gain_mb")
    }

    val settingsFlow: Flow<SoundStudioState> = context.sunozaPrefsDataStore.data.map { prefs ->
        val presetName = prefs[Keys.PRESET] ?: EqPreset.NORMAL.label
        val bandsCsv = prefs[Keys.BANDS]
        val bands = bandsCsv
            ?.split(",")
            ?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == 10 }
            ?: EqPreset.NORMAL.bandsDb

        val reverbName = prefs[Keys.REVERB] ?: ReverbOption.NONE.name
        val reverb = runCatching { ReverbOption.valueOf(reverbName) }.getOrDefault(ReverbOption.NONE)

        SoundStudioState(
            isEnabled = prefs[Keys.ENABLED] ?: true,
            activePresetName = presetName,
            bandsDb = bands,
            bassBoost = prefs[Keys.BASS_BOOST] ?: 0,
            trebleBoost = prefs[Keys.TREBLE_BOOST] ?: 0f,
            virtualizer = prefs[Keys.VIRTUALIZER] ?: 0,
            reverb = reverb,
            loudnessGainMb = prefs[Keys.LOUDNESS] ?: 0,
        )
    }

    suspend fun saveState(state: SoundStudioState) {
        context.sunozaPrefsDataStore.edit { prefs ->
            prefs[Keys.ENABLED] = state.isEnabled
            prefs[Keys.PRESET] = state.activePresetName
            prefs[Keys.BANDS] = state.bandsDb.joinToString(",")
            prefs[Keys.BASS_BOOST] = state.bassBoost
            prefs[Keys.TREBLE_BOOST] = state.trebleBoost
            prefs[Keys.VIRTUALIZER] = state.virtualizer
            prefs[Keys.REVERB] = state.reverb.name
            prefs[Keys.LOUDNESS] = state.loudnessGainMb
        }
    }
}
