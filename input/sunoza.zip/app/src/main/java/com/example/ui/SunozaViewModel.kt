package com.example.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.ListeningEventEntity
import com.example.data.local.SoundStudioPreferences
import com.example.data.remote.OnlineTrackCandidate
import com.example.data.repository.MusicRepository
import com.example.data.repository.RecommendationEngine
import com.example.data.repository.RecommendationSnapshot
import com.example.model.AudioAnalysisResult
import com.example.model.EqPreset
import com.example.model.PartyEnergyMode
import com.example.model.PlaylistWithSongs
import com.example.model.ReverbOption
import com.example.model.SavedMix
import com.example.model.Song
import com.example.model.SoundStudioState
import com.example.model.SourceType
import com.example.model.TransitionFilterType
import com.example.player.AudioBpmAnalyzer
import com.example.player.MixFlowEngine
import com.example.player.MixFlowUiState
import com.example.player.PlaybackController
import com.example.player.PlaybackState
import com.example.player.SoundStudioEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface QueueFilter {
    data object AllSongs : QueueFilter
    data object Favorites : QueueFilter
    data object PartyFlow : QueueFilter
    data class Playlist(val playlistId: Long, val name: String) : QueueFilter

    val label: String
        get() = when (this) {
            AllSongs -> "All Songs"
            Favorites -> "Favourites"
            PartyFlow -> "PartyFlow Auto DJ"
            is Playlist -> name
        }
}

data class PartyFlowState(
    val isActive: Boolean = false,
    val autoDjEnabled: Boolean = true,
    val smartSkipEnabled: Boolean = true,
    val energyMode: PartyEnergyMode = PartyEnergyMode.BALANCED,
    val crossfadeSec: Int = 5,
    val queue: List<Song> = emptyList(),
    val currentAnalysis: AudioAnalysisResult? = null,
    val smartSkipStatus: String = "Ready to analyze track",
)

data class SunozaUiState(
    val isReady: Boolean = false,
    val hasAudioPermission: Boolean = false,
    val isScanningLibrary: Boolean = false,
    val allSongs: List<Song> = emptyList(),
    val favoriteSongs: List<Song> = emptyList(),
    val recentlyPlayedSongs: List<Song> = emptyList(),
    val recentlyPlayedOnlineSongs: List<Song> = emptyList(),
    val playlists: List<PlaylistWithSongs> = emptyList(),
    val savedMixes: List<SavedMix> = emptyList(),
    val activeQueueFilter: QueueFilter = QueueFilter.AllSongs,
    val activeQueue: List<Song> = emptyList(),
    val currentSong: Song? = null,
    val currentQueueIndex: Int = 0,
    val recommendations: RecommendationSnapshot = RecommendationSnapshot(),
    val searchQuery: String = "",
    val searchResults: List<Song> = emptyList(),
    val onlineSearchQuery: String = "",
    val onlineCandidates: List<OnlineTrackCandidate> = emptyList(),
    val isOnlineSearching: Boolean = false,
    val onlineErrorMessage: String? = null,
    val statusMessage: String? = null,
    val playback: PlaybackState = PlaybackState(),
    val soundStudio: SoundStudioState = SoundStudioState(),
    val mixFlow: MixFlowUiState = MixFlowUiState(),
    val partyFlow: PartyFlowState = PartyFlowState(),
)

private data class LibraryBundle(
    val allSongs: List<Song>,
    val favoriteSongs: List<Song>,
    val recentlyPlayed: List<Song>,
    val playlists: List<PlaylistWithSongs>,
    val events: List<ListeningEventEntity>,
    val savedMixes: List<SavedMix>,
)

private data class ControlsBundle(
    val isReady: Boolean,
    val hasAudioPermission: Boolean,
    val isScanningLibrary: Boolean,
    val queueFilter: QueueFilter,
    val searchQuery: String,
    val onlineSearchQuery: String,
    val onlineCandidates: List<OnlineTrackCandidate>,
    val isOnlineSearching: Boolean,
    val onlineErrorMessage: String?,
    val statusMessage: String?,
)

class SunozaViewModel(
    private val repository: MusicRepository,
    private val playbackController: PlaybackController,
    private val soundStudioEngine: SoundStudioEngine,
    private val soundStudioPreferences: SoundStudioPreferences,
    private val audioBpmAnalyzer: AudioBpmAnalyzer,
    private val mixFlowEngine: MixFlowEngine,
) : ViewModel() {

    private val isReady = MutableStateFlow(false)
    private val hasAudioPermission = MutableStateFlow(repository.hasAudioPermission())
    private val isScanningLibrary = MutableStateFlow(false)
    private val queueFilter = MutableStateFlow<QueueFilter>(QueueFilter.AllSongs)
    private val searchQuery = MutableStateFlow("")
    private val onlineSearchQuery = MutableStateFlow("")
    private val onlineCandidates = MutableStateFlow<List<OnlineTrackCandidate>>(emptyList())
    private val isOnlineSearching = MutableStateFlow(false)
    private val onlineErrorMessage = MutableStateFlow<String?>(null)
    private val statusMessage = MutableStateFlow<String?>(null)
    private val partyFlowState = MutableStateFlow(PartyFlowState())

    private var partyTransitionInProgress = false
    private var lastSmartSkippedIntroSongId: Long? = null
    private var lastAutoRecordedSongId: Long? = null
    private var scanRefreshJob: Job? = null
    private var pendingPlaySongId: Long? = null

    private val libraryBundle = combine(
        repository.allSongs,
        repository.favoriteSongs,
        repository.recentlyPlayedSongs,
        repository.playlists,
        repository.recentListeningEvents,
        repository.savedMixes,
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        LibraryBundle(
            allSongs = values[0] as List<Song>,
            favoriteSongs = values[1] as List<Song>,
            recentlyPlayed = values[2] as List<Song>,
            playlists = values[3] as List<PlaylistWithSongs>,
            events = values[4] as List<ListeningEventEntity>,
            savedMixes = values[5] as List<SavedMix>,
        )
    }

    private val controlsBundle = combine(
        isReady,
        hasAudioPermission,
        isScanningLibrary,
        queueFilter,
        searchQuery,
        onlineSearchQuery,
        onlineCandidates,
        isOnlineSearching,
        onlineErrorMessage,
        statusMessage,
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        ControlsBundle(
            isReady = values[0] as Boolean,
            hasAudioPermission = values[1] as Boolean,
            isScanningLibrary = values[2] as Boolean,
            queueFilter = values[3] as QueueFilter,
            searchQuery = values[4] as String,
            onlineSearchQuery = values[5] as String,
            onlineCandidates = values[6] as List<OnlineTrackCandidate>,
            isOnlineSearching = values[7] as Boolean,
            onlineErrorMessage = values[8] as String?,
            statusMessage = values[9] as String?,
        )
    }

    private val audioEnginesBundle = combine(
        playbackController.state,
        soundStudioEngine.state,
        mixFlowEngine.state,
        partyFlowState,
    ) { playback, studio, mix, party ->
        listOf(playback, studio, mix, party)
    }

    val uiState: StateFlow<SunozaUiState> = combine(
        libraryBundle,
        controlsBundle,
        audioEnginesBundle,
    ) { library, controls, engines ->
        val playback = engines[0] as PlaybackState
        val studio = engines[1] as SoundStudioState
        val mix = engines[2] as MixFlowUiState
        val party = engines[3] as PartyFlowState

        val resolvedQueue = when (val filter = controls.queueFilter) {
            QueueFilter.AllSongs -> library.allSongs
            QueueFilter.Favorites -> library.favoriteSongs.ifEmpty { library.allSongs }
            QueueFilter.PartyFlow -> party.queue.ifEmpty { library.allSongs }
            is QueueFilter.Playlist -> {
                val found = library.playlists.firstOrNull { it.id == filter.playlistId }
                found?.songs?.takeIf { it.isNotEmpty() } ?: library.allSongs
            }
        }

        val currentIdx = playback.currentSongId
            ?.let { id -> resolvedQueue.indexOfFirst { it.id == id } }
            ?.takeIf { it >= 0 }
            ?: 0

        val activeSong = playback.currentSongId
            ?.let { id -> library.allSongs.firstOrNull { it.id == id } }
            ?: resolvedQueue.getOrNull(currentIdx)
        val trimmedQuery = controls.searchQuery.trim()
        val filteredSongs = if (trimmedQuery.isEmpty()) {
            library.allSongs
        } else {
            library.allSongs.filter { song ->
                song.title.contains(trimmedQuery, ignoreCase = true) ||
                    song.artist.contains(trimmedQuery, ignoreCase = true) ||
                    song.album.contains(trimmedQuery, ignoreCase = true) ||
                    song.genre.contains(trimmedQuery, ignoreCase = true) ||
                    song.lyricsRaw.contains(trimmedQuery, ignoreCase = true)
            }
        }

        val recommendations = RecommendationEngine.buildRecommendations(
            allSongs = library.allSongs,
            currentSong = activeSong,
            recentEvents = library.events,
        )

        val recentOnline = library.recentlyPlayed.filter { it.sourceType == SourceType.AUTHORIZED_ONLINE }

        SunozaUiState(
            isReady = controls.isReady,
            hasAudioPermission = controls.hasAudioPermission,
            isScanningLibrary = controls.isScanningLibrary,
            allSongs = library.allSongs,
            favoriteSongs = library.favoriteSongs,
            recentlyPlayedSongs = library.recentlyPlayed,
            recentlyPlayedOnlineSongs = recentOnline,
            playlists = library.playlists,
            savedMixes = library.savedMixes,
            activeQueueFilter = controls.queueFilter,
            activeQueue = resolvedQueue,
            currentSong = activeSong,
            currentQueueIndex = currentIdx,
            recommendations = recommendations,
            searchQuery = controls.searchQuery,
            searchResults = filteredSongs,
            onlineSearchQuery = controls.onlineSearchQuery,
            onlineCandidates = controls.onlineCandidates,
            isOnlineSearching = controls.isOnlineSearching,
            onlineErrorMessage = controls.onlineErrorMessage,
            statusMessage = controls.statusMessage ?: playback.errorMessage,
            playback = playback,
            soundStudio = studio,
            mixFlow = mix,
            partyFlow = party,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = SunozaUiState(),
    )

    init {
        playbackController.connect()
        playbackController.setOnSongTransitionListener { songId ->
            onActiveSongChanged(songId)
        }

        viewModelScope.launch {
            val savedStudio = soundStudioPreferences.settingsFlow.first()
            soundStudioEngine.applyLoadedState(savedStudio)
        }

        viewModelScope.launch {
            repository.ensureSeeded()
            if (repository.hasAudioPermission()) {
                refreshMediaStoreLibrary(silent = true)
                repository.registerMediaStoreObserver {
                    refreshMediaStoreLibrary(silent = true)
                }
            }
            isReady.value = true
            searchAuthorizedOnline("")
        }

        // Keep ExoPlayer queue aligned ONLY when initial queue loads or queue IDs change cleanly
        viewModelScope.launch {
            var lastSyncedIds: List<Long> = emptyList()
            var lastConnected = false
            uiState.collect { state ->
                val queueIds = state.activeQueue.map { it.id }
                val connected = state.playback.isConnected
                if (state.isReady && state.activeQueue.isNotEmpty() && connected &&
                    (queueIds != lastSyncedIds || !lastConnected)
                ) {
                    val currentId = state.playback.currentSongId
                    val pendingId = pendingPlaySongId
                    if (pendingId != null && pendingId !in queueIds) {
                        // Room Flow hasn't emitted the newly inserted online/imported song yet; do NOT clobber playback!
                        return@collect
                    }
                    if (pendingId != null && pendingId in queueIds) {
                        pendingPlaySongId = null
                    }
                    lastSyncedIds = queueIds
                    lastConnected = true
                    val targetId = when {
                        currentId != null && currentId in queueIds -> currentId
                        else -> state.activeQueue.first().id
                    }
                    playbackController.syncQueue(
                        songs = state.activeQueue,
                        selectSongId = targetId,
                        autoPlay = false,
                    )
                }
                if (state.isReady && state.allSongs.size >= 2 &&
                    state.mixFlow.deckA.song == null && state.mixFlow.deckB.song == null
                ) {
                    mixFlowEngine.loadDeckA(state.allSongs[0])
                    mixFlowEngine.loadDeckB(state.allSongs[1])
                }
            }
        }

        // PartyFlow Auto DJ + Smart Skip live monitor
        viewModelScope.launch {
            playbackController.state.collect { playback ->
                val party = partyFlowState.value
                val song = uiState.value.currentSong
                if (party.isActive && song != null && playback.isPlaying && !partyTransitionInProgress) {
                    val analysis = party.currentAnalysis
                    if (party.smartSkipEnabled && analysis != null && analysis.isReliableAnalysis) {
                        if (analysis.introSkipMs > 0L &&
                            playback.positionMs in 150L..1_800L &&
                            lastSmartSkippedIntroSongId != song.id
                        ) {
                            lastSmartSkippedIntroSongId = song.id
                            playbackController.seekToPosition(analysis.introSkipMs)
                            partyFlowState.update {
                                it.copy(smartSkipStatus = "Smart Skip: jumped ${analysis.introSkipMs / 1000}s quiet intro")
                            }
                        }

                        val triggerAtMs = if (party.autoDjEnabled) {
                            minOf(
                                analysis.outroStartMs,
                                (playback.durationMs - (party.crossfadeSec * 1_000L)).coerceAtLeast(playback.durationMs / 2),
                            )
                        } else {
                            analysis.outroStartMs
                        }

                        if (playback.durationMs > 8_000L && playback.positionMs >= triggerAtMs) {
                            triggerPartySmoothTransition()
                        }
                    } else if (party.autoDjEnabled && playback.durationMs > 8_000L) {
                        val fadeStart = (playback.durationMs - (party.crossfadeSec * 1_000L))
                            .coerceAtLeast(playback.durationMs / 2)
                        if (playback.positionMs >= fadeStart) {
                            triggerPartySmoothTransition()
                        }
                    }
                }
            }
        }
    }

    private fun onActiveSongChanged(songId: Long) {
        if (lastAutoRecordedSongId == songId) return
        val song = uiState.value.allSongs.firstOrNull { it.id == songId } ?: return
        lastAutoRecordedSongId = songId
        viewModelScope.launch {
            repository.recordSongPlayed(song)
            val analysis = audioBpmAnalyzer.analyzeSong(song)
            if (analysis.isReliableAnalysis) {
                repository.updateSongAnalysis(song.id, analysis.bpm, analysis.energyScore)
            }
            if (partyFlowState.value.isActive) {
                partyFlowState.update {
                    it.copy(
                        currentAnalysis = analysis,
                        smartSkipStatus = when {
                            !it.smartSkipEnabled -> "Smart Skip disabled"
                            !analysis.isReliableAnalysis -> "Online/stream track: Smart Skip paused for safety"
                            analysis.introSkipMs > 0L -> "Detected ${analysis.introSkipMs / 1000}s low-energy intro"
                            else -> "Full energy track · ${analysis.bpm} BPM"
                        },
                    )
                }
            }
        }
    }

    private fun triggerPartySmoothTransition() {
        if (partyTransitionInProgress) return
        partyTransitionInProgress = true
        viewModelScope.launch {
            val fadeSec = partyFlowState.value.crossfadeSec.coerceIn(1, 10)
            val steps = 10
            val stepMs = (fadeSec * 500L) / steps
            for (i in steps downTo 1) {
                playbackController.setVolume(i.toFloat() / steps)
                delay(stepMs)
            }
            playbackController.seekToNext()
            for (i in 1..steps) {
                playbackController.setVolume(i.toFloat() / steps)
                delay(stepMs)
            }
            playbackController.setVolume(1.0f)
            partyTransitionInProgress = false
        }
    }

    fun onAudioPermissionResult(granted: Boolean) {
        hasAudioPermission.value = granted || repository.hasAudioPermission()
        if (hasAudioPermission.value) {
            refreshMediaStoreLibrary(silent = false)
            repository.registerMediaStoreObserver {
                refreshMediaStoreLibrary(silent = true)
            }
        }
    }

    fun refreshMediaStoreLibrary(silent: Boolean = false) {
        scanRefreshJob?.cancel()
        scanRefreshJob = viewModelScope.launch {
            isScanningLibrary.value = true
            val count = repository.scanDeviceAudio()
            isScanningLibrary.value = false
            if (!silent) {
                statusMessage.value = if (count > 0) {
                    "Scanned $count new device audio track${if (count == 1) "" else "s"}"
                } else {
                    "Offline library is up to date"
                }
            }
        }
    }

    fun onSwipeToQueueIndex(index: Int) {
        val queue = uiState.value.activeQueue
        val target = queue.getOrNull(index) ?: return
        if (target.id != uiState.value.playback.currentSongId) {
            playbackController.playSong(target, queue)
        }
    }

    fun playSongInCurrentOrAllQueue(song: Song) {
        mixFlowEngine.stopAll()
        val state = uiState.value
        val inCurrent = state.activeQueue.any { it.id == song.id }
        val targetQueue = if (inCurrent) {
            state.activeQueue
        } else {
            queueFilter.value = QueueFilter.AllSongs
            state.allSongs
        }
        playbackController.playSong(song, targetQueue)
    }

    fun playCustomQueue(songs: List<Song>, startSong: Song? = null) {
        if (songs.isEmpty()) return
        mixFlowEngine.stopAll()
        queueFilter.value = QueueFilter.AllSongs
        playbackController.playSong(startSong ?: songs.first(), songs)
    }

    fun playPlaylist(playlist: PlaylistWithSongs, startSong: Song? = null, shuffle: Boolean = false) {
        if (playlist.songs.isEmpty()) {
            statusMessage.value = "Playlist \"${playlist.name}\" is empty. Add songs first."
            return
        }
        mixFlowEngine.stopAll()
        queueFilter.value = QueueFilter.Playlist(playlist.id, playlist.name)
        val ordered = if (shuffle) playlist.songs.shuffled() else playlist.songs
        val target = startSong ?: ordered.first()
        playbackController.playSong(target, ordered)
    }

    fun playFavorites(startSong: Song? = null) {
        val favs = uiState.value.favoriteSongs
        if (favs.isEmpty()) {
            statusMessage.value = "No favourite songs yet. Tap the heart on any track."
            return
        }
        mixFlowEngine.stopAll()
        queueFilter.value = QueueFilter.Favorites
        playbackController.playSong(startSong ?: favs.first(), favs)
    }

    fun togglePlayPause() {
        mixFlowEngine.stopAll()
        playbackController.togglePlayPause()
    }

    fun nextSong() = playbackController.seekToNext()

    fun previousSong() = playbackController.seekToPrevious()

    fun seekTo(positionMs: Long) = playbackController.seekToPosition(positionMs)

    fun toggleShuffle() = playbackController.toggleShuffle()

    fun cycleRepeatMode() = playbackController.cycleRepeatMode()

    // --- Sound Studio DSP ---
    fun toggleSoundStudio(enabled: Boolean) {
        val next = soundStudioEngine.setEnabled(enabled)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun applyEqPreset(preset: EqPreset) {
        val next = soundStudioEngine.applyPreset(preset)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun updateEqBand(index: Int, db: Float) {
        val next = soundStudioEngine.updateBand(index, db)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun updateBassBoost(strength: Int) {
        val next = soundStudioEngine.setBassBoost(strength)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun updateTrebleBoost(trebleDb: Float) {
        val next = soundStudioEngine.setTrebleBoost(trebleDb)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun updateVirtualizer(strength: Int) {
        val next = soundStudioEngine.setVirtualizer(strength)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun updateReverb(option: ReverbOption) {
        val next = soundStudioEngine.setReverb(option)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun updateLoudnessGain(gainMb: Int) {
        val next = soundStudioEngine.setLoudnessGain(gainMb)
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
    }

    fun resetSoundStudio() {
        val next = soundStudioEngine.reset()
        viewModelScope.launch { soundStudioPreferences.saveState(next) }
        statusMessage.value = "Sound Studio reset to Normal"
    }

    // --- MixFlow Controls ---
    fun loadMixDeckA(song: Song) = mixFlowEngine.loadDeckA(song)
    fun loadMixDeckB(song: Song) = mixFlowEngine.loadDeckB(song)
    fun toggleDeckAPlayPause() = mixFlowEngine.toggleDeckAPlayPause()
    fun toggleDeckBPlayPause() = mixFlowEngine.toggleDeckBPlayPause()
    fun seekDeckA(posMs: Long) = mixFlowEngine.seekDeckA(posMs)
    fun seekDeckB(posMs: Long) = mixFlowEngine.seekDeckB(posMs)
    fun setMixCrossfader(value: Float) = mixFlowEngine.setCrossfader(value)
    fun setMixTransitionDuration(sec: Int) = mixFlowEngine.setTransitionDuration(sec)
    fun setMixFilterType(type: TransitionFilterType) = mixFlowEngine.setFilterType(type)
    fun setMixEchoAmount(amount: Float) = mixFlowEngine.setEchoAmount(amount)
    fun setAutoMixEnabled(enabled: Boolean) = mixFlowEngine.setAutoMix(enabled)
    fun toggleBeatSync() = mixFlowEngine.toggleBeatSync()
    fun startMixPreview() = mixFlowEngine.startMixPreview()
    fun triggerMixTransition() = mixFlowEngine.triggerSmoothCrossfadeTransition()

    fun blendCurrentAndNextInMixFlow() {
        val queue = uiState.value.activeQueue
        if (queue.size < 2) {
            statusMessage.value = "Add at least 2 songs to blend."
            return
        }
        val idx = uiState.value.currentQueueIndex
        val current = queue[idx]
        val next = queue[(idx + 1) % queue.size]
        mixFlowEngine.loadBlendPair(current, next)
        statusMessage.value = "Loaded \"${current.title}\" & \"${next.title}\" into MixFlow"
    }

    fun saveCurrentMix(name: String) {
        val mix = uiState.value.mixFlow
        val songA = mix.deckA.song
        val songB = mix.deckB.song
        if (songA == null || songB == null) {
            statusMessage.value = "Load songs on both Deck A and Deck B before saving."
            return
        }
        viewModelScope.launch {
            repository.saveMixPreset(
                name = name,
                deckASongId = songA.id,
                deckBSongId = songB.id,
                crossfader = mix.crossfader,
                transitionDurationSec = mix.transitionDurationSec,
                filterType = mix.filterType,
                echoAmount = mix.echoAmount,
                autoMixEnabled = mix.autoMixEnabled,
            )
            statusMessage.value = "Saved mix \"$name\""
        }
    }

    fun loadSavedMix(savedMix: SavedMix) {
        val songs = uiState.value.allSongs
        val a = songs.firstOrNull { it.id == savedMix.deckASongId }
        val b = songs.firstOrNull { it.id == savedMix.deckBSongId }
        if (a != null) mixFlowEngine.loadDeckA(a)
        if (b != null) mixFlowEngine.loadDeckB(b)
        mixFlowEngine.setCrossfader(savedMix.crossfader)
        mixFlowEngine.setTransitionDuration(savedMix.transitionDurationSec)
        mixFlowEngine.setFilterType(savedMix.filterType)
        mixFlowEngine.setEchoAmount(savedMix.echoAmount)
        mixFlowEngine.setAutoMix(savedMix.autoMixEnabled)
        statusMessage.value = "Loaded mix \"${savedMix.name}\""
    }

    fun deleteSavedMix(mixId: Long) {
        viewModelScope.launch {
            repository.deleteSavedMix(mixId)
            statusMessage.value = "Removed saved mix"
        }
    }

    fun saveMixAsPlaylist(name: String) {
        val mix = uiState.value.mixFlow
        val ids = listOfNotNull(mix.deckA.song?.id, mix.deckB.song?.id).distinct()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val playlistId = repository.createPlaylist(name.ifBlank { "MixFlow Set" })
            ids.forEach { repository.addSongToPlaylist(playlistId, it) }
            statusMessage.value = "Saved mix tracks as playlist \"$name\""
        }
    }

    // --- PartyFlow Smart Auto DJ ---
    fun startPartyFlow(startingSong: Song? = null) {
        mixFlowEngine.stopAll()
        val all = uiState.value.allSongs
        val anchor = startingSong ?: uiState.value.currentSong ?: all.firstOrNull() ?: return
        val mode = partyFlowState.value.energyMode
        val queue = RecommendationEngine.buildPartyQueue(anchor, all, mode)
        queueFilter.value = QueueFilter.PartyFlow
        partyFlowState.update {
            it.copy(
                isActive = true,
                queue = queue,
                smartSkipStatus = "Analyzing ${anchor.title}…",
            )
        }
        playbackController.playSong(anchor, queue)
        onActiveSongChanged(anchor.id)
        statusMessage.value = "PartyFlow started with ${anchor.title}"
    }

    fun setPartyEnergyMode(mode: PartyEnergyMode) {
        val current = uiState.value.currentSong ?: partyFlowState.value.queue.firstOrNull()
        val all = uiState.value.allSongs
        val rebuiltQueue = if (current != null) {
            RecommendationEngine.buildPartyQueue(current, all, mode)
        } else {
            emptyList()
        }
        partyFlowState.update {
            it.copy(
                energyMode = mode,
                queue = rebuiltQueue.ifEmpty { it.queue },
            )
        }
        if (partyFlowState.value.isActive && current != null && rebuiltQueue.isNotEmpty()) {
            queueFilter.value = QueueFilter.PartyFlow
            playbackController.syncQueue(rebuiltQueue, selectSongId = current.id, autoPlay = true)
        }
    }

    fun togglePartyAutoDj() {
        partyFlowState.update { it.copy(autoDjEnabled = !it.autoDjEnabled) }
    }

    fun togglePartySmartSkip() {
        partyFlowState.update {
            val next = !it.smartSkipEnabled
            it.copy(
                smartSkipEnabled = next,
                smartSkipStatus = if (next) "Smart Skip active" else "Smart Skip paused by user",
            )
        }
    }

    fun setPartyCrossfade(sec: Int) {
        partyFlowState.update { it.copy(crossfadeSec = sec.coerceIn(2, 12)) }
    }

    fun keepVibeAlive() {
        val all = uiState.value.allSongs
        val current = uiState.value.currentSong ?: partyFlowState.value.queue.firstOrNull() ?: all.firstOrNull() ?: return
        val existingIds = partyFlowState.value.queue.map { it.id }.toSet()
        val additions = RecommendationEngine.buildPartyQueue(
            startingSong = current,
            allSongs = all,
            energyMode = partyFlowState.value.energyMode,
            excludeIds = existingIds,
        ).drop(1).take(4)

        val refreshed = if (additions.isNotEmpty()) {
            partyFlowState.value.queue + additions
        } else {
            // Re-order upcoming songs to keep energy fresh when library is small
            val tail = all.filter { it.id != current.id }.shuffled()
            listOf(current) + tail
        }
        partyFlowState.update { it.copy(isActive = true, queue = refreshed) }
        queueFilter.value = QueueFilter.PartyFlow
        playbackController.syncQueue(refreshed, selectSongId = current.id, autoPlay = true)
        statusMessage.value = "Kept the vibe alive with fresh ${partyFlowState.value.energyMode.label} tracks"
    }

    fun addSongToPartyQueue(song: Song) {
        val currentQueue = partyFlowState.value.queue
        if (currentQueue.any { it.id == song.id }) return
        val updated = currentQueue + song
        partyFlowState.update { it.copy(queue = updated) }
        if (partyFlowState.value.isActive) {
            playbackController.syncQueue(updated, selectSongId = uiState.value.currentSong?.id, autoPlay = false)
        }
    }

    fun removeSongFromPartyQueue(song: Song) {
        val updated = partyFlowState.value.queue.filterNot { it.id == song.id }
        partyFlowState.update { it.copy(queue = updated) }
        if (partyFlowState.value.isActive && updated.isNotEmpty()) {
            playbackController.syncQueue(updated, selectSongId = uiState.value.currentSong?.id, autoPlay = false)
        }
    }

    fun stopPartyFlow() {
        partyFlowState.update { it.copy(isActive = false) }
        queueFilter.value = QueueFilter.AllSongs
        playbackController.pausePlayback()
    }

    // --- Search & Online Discovery ---
    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun updateOnlineSearchQuery(query: String) {
        onlineSearchQuery.value = query
    }

    fun searchAuthorizedOnline(query: String = onlineSearchQuery.value) {
        viewModelScope.launch {
            isOnlineSearching.value = true
            onlineErrorMessage.value = null
            val outcome = repository.searchAuthorizedOnlineTracks(query)
            onlineCandidates.value = outcome.tracks
            onlineErrorMessage.value = outcome.errorMessage
            isOnlineSearching.value = false
        }
    }

    fun importAndPlayAuthorizedCandidate(candidate: OnlineTrackCandidate) {
        viewModelScope.launch {
            val activeSong = uiState.value.currentSong
            if (activeSong != null &&
                activeSong.audioUri == candidate.streamUrl &&
                uiState.value.playback.errorMessage == null &&
                uiState.value.playback.isConnected
            ) {
                playbackController.togglePlayPause()
                return@launch
            }
            mixFlowEngine.stopAll()
            repository.addAuthorizedOnlineCandidate(candidate)
                .onSuccess { song ->
                    pendingPlaySongId = song.id
                    queueFilter.value = QueueFilter.AllSongs
                    val updatedQueue = (uiState.value.allSongs + song).distinctBy { it.id }
                    playbackController.playSong(song, updatedQueue)
                    statusMessage.value = "Streaming: ${song.title}"
                }
                .onFailure { err ->
                    statusMessage.value = err.message ?: "Stream rejected by source policy."
                }
        }
    }

    fun addCandidateToPlaylist(candidate: OnlineTrackCandidate, playlistId: Long) {
        viewModelScope.launch {
            repository.addAuthorizedOnlineCandidate(candidate)
                .onSuccess { song ->
                    repository.addSongToPlaylist(playlistId, song.id)
                    statusMessage.value = "Added \"${song.title}\" to playlist"
                }
                .onFailure { err ->
                    statusMessage.value = err.message ?: "Unable to add online track."
                }
        }
    }

    fun playOnlinePlaylistPack(tracks: List<OnlineTrackCandidate>) {
        if (tracks.isEmpty()) return
        viewModelScope.launch {
            val added = tracks.mapNotNull { candidate ->
                repository.addAuthorizedOnlineCandidate(candidate).getOrNull()
            }
            if (added.isNotEmpty()) {
                mixFlowEngine.stopAll()
                val firstSong = added.first()
                pendingPlaySongId = firstSong.id
                queueFilter.value = QueueFilter.AllSongs
                val updatedQueue = (uiState.value.allSongs + added).distinctBy { it.id }
                playbackController.playSong(firstSong, updatedQueue)
                statusMessage.value = "Streaming ${added.size} authorized online tracks"
            } else {
                statusMessage.value = "Unable to stream tracks in this playlist."
            }
        }
    }

    fun addAuthorizedStreamByUrl(url: String, title: String, artist: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.addAuthorizedStreamByUrl(url, title, artist)
                .onSuccess { song ->
                    mixFlowEngine.stopAll()
                    pendingPlaySongId = song.id
                    queueFilter.value = QueueFilter.AllSongs
                    val updatedQueue = (uiState.value.allSongs + song).distinctBy { it.id }
                    playbackController.playSong(song, updatedQueue)
                    statusMessage.value = "Streaming authorized source: ${song.title}"
                    onSuccess()
                }
                .onFailure { err ->
                    statusMessage.value = err.message ?: "Only authorized music sources are permitted."
                }
        }
    }

    fun importOfflineFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val ids = repository.importOfflineAudioFiles(uris)
            if (ids.isNotEmpty()) {
                mixFlowEngine.stopAll()
                queueFilter.value = QueueFilter.AllSongs
                statusMessage.value = "Imported ${ids.size} offline audio file${if (ids.size > 1) "s" else ""}"
                val firstId = ids.first()
                val updatedList = repository.allSongs.first { songs -> songs.any { it.id == firstId } }
                updatedList.firstOrNull { it.id == firstId }?.let { imported ->
                    playbackController.playSong(imported, updatedList)
                }
            }
        }
    }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id, !song.isFavorite)
        }
    }

    fun updateLyrics(songId: Long, lyricsRaw: String) {
        viewModelScope.launch {
            repository.updateLyrics(songId, lyricsRaw)
            statusMessage.value = "Synchronized lyrics saved"
        }
    }

    fun randomizeSongColor(song: Song) {
        viewModelScope.launch {
            repository.randomizeSongColor(song.id, song.backgroundColorArgb)
        }
    }

    fun deleteSong(song: Song) {
        viewModelScope.launch {
            repository.deleteSong(song.id)
            statusMessage.value = "Removed \"${song.title}\""
        }
    }

    fun createPlaylist(name: String, initialSongId: Long? = null) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val playlistId = repository.createPlaylist(clean)
            if (initialSongId != null) {
                repository.addSongToPlaylist(playlistId, initialSongId)
                statusMessage.value = "Created \"$clean\" and added song"
            } else {
                statusMessage.value = "Created playlist \"$clean\""
            }
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            repository.renamePlaylist(playlistId, newName)
            statusMessage.value = "Playlist renamed"
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            if ((queueFilter.value as? QueueFilter.Playlist)?.playlistId == playlistId) {
                queueFilter.value = QueueFilter.AllSongs
            }
            repository.deletePlaylist(playlistId)
            statusMessage.value = "Playlist deleted"
        }
    }

    fun toggleSongInPlaylist(playlist: PlaylistWithSongs, songId: Long) {
        viewModelScope.launch {
            val exists = playlist.songs.any { it.id == songId }
            if (exists) {
                repository.removeSongFromPlaylist(playlist.id, songId)
                statusMessage.value = "Removed from ${playlist.name}"
            } else {
                repository.addSongToPlaylist(playlist.id, songId)
                statusMessage.value = "Added to ${playlist.name}"
            }
        }
    }

    fun movePlaylistSong(playlist: PlaylistWithSongs, fromIndex: Int, toIndex: Int) {
        if (fromIndex !in playlist.songs.indices || toIndex !in playlist.songs.indices) return
        val mutable = playlist.songs.map { it.id }.toMutableList()
        val moved = mutable.removeAt(fromIndex)
        mutable.add(toIndex, moved)
        viewModelScope.launch {
            repository.reorderPlaylistSongs(playlist.id, mutable)
        }
    }

    fun clearStatusMessage() {
        statusMessage.value = null
        playbackController.clearError()
    }

    override fun onCleared() {
        repository.unregisterMediaStoreObserver()
        super.onCleared()
    }

    class Factory(
        private val repository: MusicRepository,
        private val playbackController: PlaybackController,
        private val soundStudioEngine: SoundStudioEngine,
        private val soundStudioPreferences: SoundStudioPreferences,
        private val audioBpmAnalyzer: AudioBpmAnalyzer,
        private val mixFlowEngine: MixFlowEngine,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SunozaViewModel(
                repository = repository,
                playbackController = playbackController,
                soundStudioEngine = soundStudioEngine,
                soundStudioPreferences = soundStudioPreferences,
                audioBpmAnalyzer = audioBpmAnalyzer,
                mixFlowEngine = mixFlowEngine,
            ) as T
        }
    }
}
