package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.CuratedAuthorizedCatalog
import com.example.model.SavedMix
import com.example.ui.SunozaUiState
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurfaceElevated

@Composable
fun ProfileScreen(
    uiState: SunozaUiState,
    onOpenSoundStudio: () -> Unit,
    onLoadSavedMix: (SavedMix) -> Unit,
    onDeleteSavedMix: (Long) -> Unit,
    onRequestAudioPermission: () -> Unit,
    onRescanMediaStore: () -> Unit,
    onImportOfflineAudio: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit = {},
    onOpenContentReport: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val totalPlays = uiState.allSongs.sumOf { it.playCount }
    val providerStatus = CuratedAuthorizedCatalog.providerStatus

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SunozaObsidian)
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            SunozaBrandHeader(
                title = "Sunoza Profile",
                subtitle = "Audio engine, saved mixes & device library",
            )
        }

        // Stats Summary
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                StatTile("Tracks", "${uiState.allSongs.size}", Modifier.weight(1f))
                StatTile("Favourites", "${uiState.favoriteSongs.size}", Modifier.weight(1f))
                StatTile("Playlists", "${uiState.playlists.size}", Modifier.weight(1f))
                StatTile("Plays", "$totalPlays", Modifier.weight(1f))
            }
        }

        // Sound Studio Card
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SunozaSurfaceElevated)
                    .border(1.dp, SunozaPurple.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                    .clickable(onClick = onOpenSoundStudio)
                    .padding(16.dp)
                    .testTag("profile_sound_studio_card"),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Equalizer, contentDescription = null, tint = SunozaPurple, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Sunoza Sound Studio",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    Text(
                        text = "Preset: ${uiState.soundStudio.activePresetName} · Bass ${uiState.soundStudio.bassBoost / 10}% · Reverb ${uiState.soundStudio.reverb.label}",
                        style = MaterialTheme.typography.labelMedium,
                        color = SunozaMutedText,
                    )
                }
                Text("Open", color = SunozaPink, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            }
        }

        // Offline Library Scanner Status
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SunozaSurfaceElevated)
                    .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = "Device Audio Library",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                )
                Text(
                    text = if (uiState.hasAudioPermission) {
                        "MediaStore auto-sync active — internal storage and accessible SD card tracks update automatically."
                    } else {
                        "Audio storage permission not granted yet. Grant permission to auto-scan device tracks, or import individual files."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!uiState.hasAudioPermission) {
                        Button(
                            onClick = onRequestAudioPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaOrange, contentColor = SunozaObsidian),
                        ) {
                            Text("Grant Permission")
                        }
                    } else {
                        Button(
                            onClick = onRescanMediaStore,
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaPurple),
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Rescan Device")
                        }
                    }
                    Button(
                        onClick = onImportOfflineAudio,
                        colors = ButtonDefaults.buttonColors(containerColor = SunozaObsidian),
                    ) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pick File")
                    }
                }
            }
        }

        // Saved Mixes
        item {
            SectionHeading(
                title = "Saved MixFlow Sets",
                subtitle = "${uiState.savedMixes.size} saved DJ preset${if (uiState.savedMixes.size == 1) "" else "s"}",
            )
        }

        if (uiState.savedMixes.isEmpty()) {
            item {
                Text(
                    text = "Save a blend from MixFlow to reload your dual-deck settings anytime.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        } else {
            items(uiState.savedMixes, key = { "saved_mix_${it.id}" }) { mix ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(16.dp))
                        .clickable { onLoadSavedMix(mix) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = SunozaPink)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mix.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SunozaIvory)
                        Text(
                            text = "${mix.filterType.label} · ${mix.transitionDurationSec}s transition",
                            style = MaterialTheme.typography.labelMedium,
                            color = SunozaMutedText,
                        )
                    }
                    IconButton(onClick = { onLoadSavedMix(mix) }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Load mix", tint = SunozaIvory)
                    }
                    IconButton(onClick = { onDeleteSavedMix(mix.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete mix", tint = SunozaMutedText)
                    }
                }
            }
        }

        // Privacy Policy & Content Reporting
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SunozaSurfaceElevated)
                    .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp)
                    .testTag("profile_legal_card"),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = "Privacy, Legal & Content Reporting",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                )
                val blockedSummary = if (uiState.reportedTracks.isNotEmpty()) {
                    " · ${uiState.reportedTracks.size} stream(s) blocked locally"
                } else {
                    ""
                }
                Text(
                    text = "Review on-device data practices or file a copyright / content takedown report$blockedSummary.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SunozaMutedText,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onOpenPrivacyPolicy,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("profile_privacy_policy_button"),
                    ) {
                        Icon(Icons.Filled.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Privacy Policy", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = onOpenContentReport,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("profile_report_content_button"),
                    ) {
                        Icon(Icons.Filled.Flag, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Report Content", maxLines = 1)
                    }
                }
            }
        }

        // Provider setup info
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SunozaSurfaceElevated)
                    .border(1.dp, SunozaMint.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = SunozaMint, modifier = Modifier.size(18.dp))
                    Text(
                        text = "Streaming Provider Configuration",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                }
                Text(
                    text = providerStatus.statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = SunozaMutedText,
                )
            }
        }
    }
}

@Composable
private fun StatTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(SunozaSurfaceElevated)
            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(16.dp))
            .padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = SunozaIvory)
        Text(label, style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
    }
}
