package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface SunozaDao {
    @Query("SELECT * FROM songs ORDER BY addedAtMs ASC, id ASC")
    fun observeAllSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isFavorite = 1 ORDER BY lastPlayedAtMs DESC, addedAtMs ASC")
    fun observeFavoriteSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE lastPlayedAtMs > 0 ORDER BY lastPlayedAtMs DESC LIMIT 25")
    fun observeRecentlyPlayedSongs(): Flow<List<SongEntity>>

    @Query("SELECT COUNT(*) FROM songs")
    suspend fun getSongCount(): Int

    @Query("SELECT * FROM songs WHERE audioUri = :uri LIMIT 1")
    suspend fun getSongByUri(uri: String): SongEntity?

    @Query("SELECT * FROM songs WHERE mediaStoreId = :mediaStoreId LIMIT 1")
    suspend fun getSongByMediaStoreId(mediaStoreId: Long): SongEntity?

    @Query("SELECT mediaStoreId FROM songs WHERE mediaStoreId IS NOT NULL")
    suspend fun getAllMediaStoreIds(): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSong(song: SongEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSongsIgnore(songs: List<SongEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSongs(songs: List<SongEntity>): List<Long>

    @Query("UPDATE songs SET isFavorite = :isFavorite WHERE id = :songId")
    suspend fun setFavorite(songId: Long, isFavorite: Boolean)

    @Query("UPDATE songs SET lyricsRaw = :lyricsRaw WHERE id = :songId")
    suspend fun updateLyrics(songId: Long, lyricsRaw: String)

    @Query("UPDATE songs SET backgroundColorArgb = :colorArgb WHERE id = :songId")
    suspend fun updateBackgroundColor(songId: Long, colorArgb: Long)

    @Query("UPDATE songs SET playCount = playCount + 1, lastPlayedAtMs = :playedAtMs WHERE id = :songId")
    suspend fun recordSongPlay(songId: Long, playedAtMs: Long)

    @Query("UPDATE songs SET bpm = :bpm, energyScore = :energyScore WHERE id = :songId")
    suspend fun updateAudioAnalysis(songId: Long, bpm: Int, energyScore: Float)

    @Query("UPDATE songs SET artworkUri = :artworkUri, album = :album, genre = :genre WHERE id = :songId")
    suspend fun updateSongMetadata(songId: Long, artworkUri: String?, album: String, genre: String)

    @Query("DELETE FROM songs WHERE id = :songId")
    suspend fun deleteSongById(songId: Long)

    @Query("DELETE FROM songs WHERE mediaStoreId IN (:removedIds)")
    suspend fun deleteByMediaStoreIds(removedIds: List<Long>)

    @Query("SELECT * FROM playlists ORDER BY createdAtMs ASC, id ASC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlist_song_cross_ref ORDER BY playlistId ASC, position ASC, addedAtMs ASC")
    fun observePlaylistCrossRefs(): Flow<List<PlaylistSongCrossRef>>

    @Query("SELECT COALESCE(MAX(position), -1) FROM playlist_song_cross_ref WHERE playlistId = :playlistId")
    suspend fun getMaxPlaylistPosition(playlistId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, name: String)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addSongToPlaylist(crossRef: PlaylistSongCrossRef)

    @Query("UPDATE playlist_song_cross_ref SET position = :position WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun updatePlaylistSongPosition(playlistId: Long, songId: Long, position: Int)

    @Transaction
    suspend fun updatePlaylistOrder(playlistId: Long, orderedSongIds: List<Long>) {
        orderedSongIds.forEachIndexed { index, songId ->
            updatePlaylistSongPosition(playlistId = playlistId, songId = songId, position = index)
        }
    }

    @Query("DELETE FROM playlist_song_cross_ref WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

    @Insert
    suspend fun insertListeningEvent(event: ListeningEventEntity)

    @Query("SELECT * FROM listening_events ORDER BY playedAtMs DESC LIMIT 100")
    fun observeRecentListeningEvents(): Flow<List<ListeningEventEntity>>

    @Query("SELECT * FROM saved_mixes ORDER BY createdAtMs DESC")
    fun observeSavedMixes(): Flow<List<SavedMixEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedMix(mix: SavedMixEntity): Long

    @Query("DELETE FROM saved_mixes WHERE id = :mixId")
    suspend fun deleteSavedMix(mixId: Long)
}
