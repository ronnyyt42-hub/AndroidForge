package com.example.player

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.example.model.AudioAnalysisResult
import com.example.model.Song
import com.example.model.SourceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class AudioBpmAnalyzer(private val context: Context) {
    private val cache = ConcurrentHashMap<Long, AudioAnalysisResult>()

    suspend fun analyzeSong(song: Song): AudioAnalysisResult = withContext(Dispatchers.IO) {
        cache[song.id]?.let { return@withContext it }

        val decoded = when {
            song.sourceType == SourceType.BUNDLED -> decodeBundledOrLocalSamples(song.audioUri)
            song.sourceType == SourceType.OFFLINE_LOCAL -> decodeViaMediaCodec(Uri.parse(song.audioUri))
            else -> null
        }

        val result = if (decoded != null && decoded.envelope.size >= 16) {
            buildAnalysisFromEnvelope(
                envelope = decoded.envelope,
                frameDurationMs = decoded.frameDurationMs,
                durationMs = song.durationMs,
                fallbackBpm = song.bpm,
            )
        } else {
            buildDeterministicStreamFallback(song)
        }

        cache[song.id] = result
        result
    }

    private data class DecodedEnvelope(
        val envelope: FloatArray,
        val frameDurationMs: Float,
    )

    private fun decodeBundledOrLocalSamples(uriString: String): DecodedEnvelope? {
        return runCatching {
            val uri = Uri.parse(uriString)
            val resId = uri.lastPathSegment?.toIntOrNull()
            val stream = if (resId != null) {
                context.resources.openRawResource(resId)
            } else {
                context.contentResolver.openInputStream(uri)
            } ?: return null

            stream.use { input ->
                val bytes = input.readBytes()
                if (bytes.size <= 44) return null
                // Parse standard 16-bit PCM WAV sample rate & channels
                val sampleRate = readIntLe(bytes, 24).coerceIn(8000, 96000)
                val channels = readShortLe(bytes, 22).coerceIn(1, 2)
                val dataOffset = 44
                val sampleCount = (bytes.size - dataOffset) / (2 * channels)
                val windowSamples = (sampleRate / 20).coerceAtLeast(256) // 50ms windows
                val frameCount = (sampleCount / windowSamples).coerceAtLeast(1)
                val envelope = FloatArray(frameCount)

                for (f in 0 until frameCount) {
                    var sumSq = 0.0
                    val startSample = f * windowSamples
                    val endSample = min(sampleCount, startSample + windowSamples)
                    var count = 0
                    for (s in startSample until endSample) {
                        val byteIdx = dataOffset + s * 2 * channels
                        if (byteIdx + 1 < bytes.size) {
                            val pcm = ((bytes[byteIdx + 1].toInt() shl 8) or (bytes[byteIdx].toInt() and 0xFF)).toShort()
                            val norm = pcm / 32768.0
                            sumSq += norm * norm
                            count++
                        }
                    }
                    envelope[f] = if (count > 0) sqrt(sumSq / count).toFloat() else 0f
                }
                DecodedEnvelope(envelope = envelope, frameDurationMs = (windowSamples * 1000f) / sampleRate)
            }
        }.getOrNull()
    }

    private fun decodeViaMediaCodec(uri: Uri): DecodedEnvelope? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        return try {
            extractor.setDataSource(context, uri, null)
            var audioTrackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val trackFormat = extractor.getTrackFormat(i)
                val mime = trackFormat.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    format = trackFormat
                    break
                }
            }
            if (audioTrackIndex < 0 || format == null) return null

            extractor.selectTrack(audioTrackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                format.getInteger(MediaFormat.KEY_SAMPLE_RATE).coerceIn(8000, 96000)
            } else {
                44100
            }
            val channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
            } else {
                2
            }

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            val rmsList = mutableListOf<Float>()
            var sawInputEOS = false
            var sawOutputEOS = false
            var decodedFrames = 0
            val maxDecodedChunks = 500 // Cap decoding time for battery & responsiveness (~12–25s sample)

            while (!sawOutputEOS && decodedFrames < maxDecodedChunks) {
                if (!sawInputEOS) {
                    val inIdx = codec.dequeueInputBuffer(4_000L)
                    if (inIdx >= 0) {
                        val inBuf: ByteBuffer? = codec.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            val sampleSize = extractor.readSampleData(inBuf, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                sawInputEOS = true
                            } else {
                                codec.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(bufferInfo, 4_000L)
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && bufferInfo.size > 0) {
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        val shortBuf = outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        var sumSq = 0.0
                        var count = 0
                        while (shortBuf.hasRemaining()) {
                            val sample = shortBuf.get() / 32768.0
                            sumSq += sample * sample
                            count++
                        }
                        if (count > 0) {
                            rmsList.add(sqrt(sumSq / count).toFloat())
                            decodedFrames++
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        sawOutputEOS = true
                    }
                }
            }

            if (rmsList.size < 16) return null
            val approxChunkMs = max(20f, (1024f * 1000f) / (sampleRate * channels.coerceAtLeast(1) / 2f))
            DecodedEnvelope(envelope = rmsList.toFloatArray(), frameDurationMs = approxChunkMs.coerceIn(20f, 80f))
        } catch (_: Exception) {
            null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun buildAnalysisFromEnvelope(
        envelope: FloatArray,
        frameDurationMs: Float,
        durationMs: Long,
        fallbackBpm: Int,
    ): AudioAnalysisResult {
        val peak = envelope.maxOrNull()?.coerceAtLeast(0.001f) ?: 1f
        val normalized = FloatArray(envelope.size) { (envelope[it] / peak).coerceIn(0f, 1f) }

        // Downsample to 56 waveform bars
        val barCount = 56
        val waveform = List(barCount) { bar ->
            val start = (bar * normalized.size) / barCount
            val end = (((bar + 1) * normalized.size) / barCount).coerceAtLeast(start + 1)
            var maxVal = 0.12f
            for (i in start until min(end, normalized.size)) {
                if (normalized[i] > maxVal) maxVal = normalized[i]
            }
            maxVal.coerceIn(0.10f, 1.0f)
        }

        // Compute energy onset flux for autocorrelation BPM detection
        val flux = FloatArray(normalized.size)
        for (i in 1 until normalized.size) {
            flux[i] = max(0f, normalized[i] - normalized[i - 1])
        }

        val minLag = ((60_000f / 160f) / frameDurationMs).toInt().coerceAtLeast(3)
        val maxLag = ((60_000f / 68f) / frameDurationMs).toInt().coerceAtMost(normalized.size / 2)

        var bestLag = -1
        var bestScore = -1f
        if (maxLag > minLag) {
            for (lag in minLag..maxLag) {
                var corr = 0f
                for (i in 0 until flux.size - lag) {
                    corr += flux[i] * flux[i + lag]
                }
                if (corr > bestScore) {
                    bestScore = corr
                    bestLag = lag
                }
            }
        }

        val estimatedBpm = if (bestLag > 0) {
            val rawBpm = (60_000f / (bestLag * frameDurationMs)).toInt()
            when {
                rawBpm < 68 -> rawBpm * 2
                rawBpm > 165 -> rawBpm / 2
                else -> rawBpm
            }.coerceIn(68, 160)
        } else {
            fallbackBpm
        }

        val avgEnergy = normalized.average().toFloat().coerceIn(0.15f, 0.98f)

        // Conservative Smart Skip detection: only mark low-energy intro/outro when genuinely quiet (< 24% peak)
        val quietThreshold = 0.24f
        var introFrames = 0
        while (introFrames < normalized.size / 4 && normalized[introFrames] < quietThreshold) {
            introFrames++
        }
        val detectedIntroMs = (introFrames * frameDurationMs).toLong()
        val safeIntroSkipMs = if (detectedIntroMs in 4_000L..(durationMs / 4)) {
            detectedIntroMs - 1_000L
        } else {
            0L
        }

        var outroQuietFrames = 0
        var idx = normalized.lastIndex
        while (idx > (normalized.size * 3) / 4 && normalized[idx] < quietThreshold) {
            outroQuietFrames++
            idx--
        }
        val detectedOutroTailMs = (outroQuietFrames * frameDurationMs).toLong()
        val safeOutroStartMs = if (detectedOutroTailMs in 4_000L..(durationMs / 4)) {
            (durationMs - detectedOutroTailMs + 1_000L).coerceAtLeast(durationMs / 2)
        } else {
            durationMs
        }

        return AudioAnalysisResult(
            bpm = estimatedBpm,
            energyScore = avgEnergy,
            waveform = waveform,
            introSkipMs = safeIntroSkipMs,
            outroStartMs = safeOutroStartMs,
            isReliableAnalysis = true,
        )
    }

    private fun buildDeterministicStreamFallback(song: Song): AudioAnalysisResult {
        val seed = abs(song.title.hashCode() + song.artist.hashCode())
        val waveform = List(56) { i ->
            val phase = ((seed % 17) + i) * 0.45
            val valRaw = 0.32f + 0.55f * abs(kotlin.math.sin(phase).toFloat())
            valRaw.coerceIn(0.15f, 0.96f)
        }
        return AudioAnalysisResult(
            bpm = song.bpm.coerceIn(70, 150),
            energyScore = song.energyScore.coerceIn(0.2f, 0.95f),
            waveform = waveform,
            introSkipMs = 0L, // Never guess Smart Skip without reliable local audio envelope
            outroStartMs = song.durationMs,
            isReliableAnalysis = false,
        )
    }

    private fun readIntLe(bytes: ByteArray, offset: Int): Int {
        if (offset + 3 >= bytes.size) return 44100
        return (bytes[offset].toInt() and 0xFF) or
            ((bytes[offset + 1].toInt() and 0xFF) shl 8) or
            ((bytes[offset + 2].toInt() and 0xFF) shl 16) or
            ((bytes[offset + 3].toInt() and 0xFF) shl 24)
    }

    private fun readShortLe(bytes: ByteArray, offset: Int): Int {
        if (offset + 1 >= bytes.size) return 1
        return (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)
    }
}
