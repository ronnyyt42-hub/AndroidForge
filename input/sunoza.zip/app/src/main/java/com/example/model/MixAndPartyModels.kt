package com.example.model

enum class TransitionFilterType(val label: String) {
    SMOOTH_FADE("Smooth Fade"),
    LOW_PASS_SWEEP("Filter Sweep"),
    HIGH_PASS_SWEEP("Air Lift"),
    ECHO_FADE("Echo Blend"),
}

enum class PartyEnergyMode(
    val label: String,
    val description: String,
    val minBpm: Int,
    val maxBpm: Int,
    val targetEnergy: Float,
) {
    CHILL("Chill", "Warm grooves · 65–95 BPM", 65, 95, 0.38f),
    BALANCED("Balanced", "Dynamic flow · 90–120 BPM", 90, 120, 0.65f),
    HIGH_ENERGY("High Energy", "Peak drive · 112–160 BPM", 112, 160, 0.90f),
}

data class AudioAnalysisResult(
    val bpm: Int,
    val energyScore: Float,
    val waveform: List<Float>,
    val introSkipMs: Long,
    val outroStartMs: Long,
    val isReliableAnalysis: Boolean,
)

data class SavedMix(
    val id: Long,
    val name: String,
    val deckASongId: Long,
    val deckBSongId: Long,
    val crossfader: Float,
    val transitionDurationSec: Int,
    val filterType: TransitionFilterType,
    val echoAmount: Float,
    val autoMixEnabled: Boolean,
    val createdAtMs: Long,
)
