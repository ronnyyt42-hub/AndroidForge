package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        SongEntity::class,
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        ListeningEventEntity::class,
        SavedMixEntity::class,
        ReportedTrackEntity::class,
    ],
    version = 3,
    exportSchema = true,
)
abstract class SunozaDatabase : RoomDatabase() {
    abstract fun sunozaDao(): SunozaDao

    companion object {
        @Volatile
        private var instance: SunozaDatabase? = null

        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `listening_events` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `songId` INTEGER NOT NULL,
                        `playedAtMs` INTEGER NOT NULL,
                        `sourceType` TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `saved_mixes` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `name` TEXT NOT NULL,
                        `deckASongId` INTEGER NOT NULL,
                        `deckBSongId` INTEGER NOT NULL,
                        `crossfader` REAL NOT NULL,
                        `transitionDurationSec` INTEGER NOT NULL,
                        `filterType` TEXT NOT NULL,
                        `echoAmount` REAL NOT NULL,
                        `autoMixEnabled` INTEGER NOT NULL,
                        `createdAtMs` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_2_3: Migration = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `songs` ADD COLUMN `licenseUrl` TEXT")
                db.execSQL("ALTER TABLE `songs` ADD COLUMN `sourcePageUrl` TEXT")
                db.execSQL("ALTER TABLE `songs` ADD COLUMN `externalStoreUrl` TEXT")
                db.execSQL("ALTER TABLE `songs` ADD COLUMN `isLicenseVerified` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `songs` ADD COLUMN `attributionText` TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `reported_tracks` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `streamUrl` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `artist` TEXT NOT NULL,
                        `providerName` TEXT NOT NULL,
                        `reason` TEXT NOT NULL,
                        `reporterEmail` TEXT NOT NULL,
                        `details` TEXT NOT NULL,
                        `reportedAtMs` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): SunozaDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SunozaDatabase::class.java,
                    "sunoza_database.db",
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { instance = it }
            }
        }
    }
}
