package com.example.data.repository

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.local.ListeningEventEntity
import com.example.data.local.MediaStoreAudioScanner
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.ReportedTrackEntity
import com.example.data.local.SavedMixEntity
import com.example.data.local.SeedCatalog
import com.example.data.local.SongEntity
import com.example.data.local.SunozaDao
import com.example.data.remote.ArchiveOrgApi
import com.example.data.remote.AudiusApi
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.CuratedAuthorizedCatalog
import com.example.data.remote.ItunesSearchApi
import com.example.data.remote.OnlineHttpClientProvider
import com.example.data.remote.OnlineTrackCandidate
import com.example.data.remote.SourceValidationResult
import com.example.data.remote.WikimediaAudioApi
import com.example.model.PlaylistWithSongs
import com.example.model.SavedMix
import com.example.model.Song
import com.example.model.SongColorGenerator
import com.example.model.SourceType
import com.example.model.TransitionFilterType
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder

data class OnlineSearchOutcome(
    val tracks: List<OnlineTrackCandidate>,
    val page: Int = 0,
    val hasMore: Boolean = false,
    val errorMessage: String? = null,
    val isOffline: Boolean = false,
)

class MusicRepository(
    private val context: Context,
    private val dao: SunozaDao,
    private val archiveApi: ArchiveOrgApi,
    private val audiusApi: AudiusApi = AudiusApi.create(OnlineHttpClientProvider.sharedClient),
    private val itunesApi: ItunesSearchApi = ItunesSearchApi.create(OnlineHttpClientProvider.sharedClient),
    private val wikimediaApi: WikimediaAudioApi? = null,
    private val streamHttpClient: OkHttpClient? = null,
    private val fallbackAudiusApi: AudiusApi? = null,
) {
    private val mediaStoreScanner = MediaStoreAudioScanner(context, dao)

    val allSongs: Flow<List<Song>> = dao.observeAllSongs().map { list ->
        list.map { it.toDomain() }
    }

    val favoriteSongs: Flow<List<Song>> = dao.observeFavoriteSongs().map { list ->
        list.map { it.toDomain() }
    }

    val recentlyPlayedSongs: Flow<List<Song>> = dao.observeRecentlyPlayedSongs().map { list ->
        list.map { it.toDomain() }
    }

    val recentListeningEvents: Flow<List<ListeningEventEntity>> = dao.observeRecentListeningEvents()

    val savedMixes: Flow<List<SavedMix>> = dao.observeSavedMixes().map { list ->
        list.map { it.toDomain() }
    }

    val reportedTracks: Flow<List<ReportedTrackEntity>> = dao.observeReportedTracks()

    val playlists: Flow<List<PlaylistWithSongs>> = combine(
        dao.observePlaylists(),
        dao.observePlaylistCrossRefs(),
        allSongs,
    ) { playlistEntities, crossRefs, songs ->
        val songById = songs.associateBy { it.id }
        val refsByPlaylist = crossRefs.groupBy { it.playlistId }
        playlistEntities.map { pl ->
            val orderedSongs = refsByPlaylist[pl.id]
                .orEmpty()
                .sortedWith(compareBy<PlaylistSongCrossRef> { it.position }.thenBy { it.addedAtMs })
                .mapNotNull { songById[it.songId] }
            PlaylistWithSongs(
                id = pl.id,
                name = pl.name,
                createdAtMs = pl.createdAtMs,
                songs = orderedSongs,
            )
        }
    }

    fun hasAudioPermission(): Boolean = mediaStoreScanner.hasAudioPermission()

    fun registerMediaStoreObserver(onLibraryChanged: () -> Unit) {
        mediaStoreScanner.registerObserver(onLibraryChanged)
    }

    fun unregisterMediaStoreObserver() {
        mediaStoreScanner.unregisterObserver()
    }

    suspend fun scanDeviceAudio(): Int = mediaStoreScanner.scanAndSync()

    fun isNetworkConnected(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        dao.normalizeLegacyItunesPreviews()
        if (dao.getSongCount() == 0) {
            val seedSongs = SeedCatalog.buildSeedSongs(context)
            val insertedIds = dao.insertSongs(seedSongs)
            if (insertedIds.isNotEmpty()) {
                val chillId = dao.insertPlaylist(PlaylistEntity(name = "Midnight Chill"))
                val focusId = dao.insertPlaylist(PlaylistEntity(name = "Focus & Drift"))
                insertedIds.take(2).forEachIndexed { idx, songId ->
                    dao.addSongToPlaylist(
                        PlaylistSongCrossRef(playlistId = chillId, songId = songId, position = idx)
                    )
                }
                insertedIds.drop(2).forEachIndexed { idx, songId ->
                    dao.addSongToPlaylist(
                        PlaylistSongCrossRef(playlistId = focusId, songId = songId, position = idx)
                    )
                }
            }
        }
    }

    suspend fun importOfflineAudioFiles(uris: List<Uri>): List<Long> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val importedIds = mutableListOf<Long>()
        var lastColor: Long? = null

        for (uri in uris) {
            runCatching {
                resolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }

            val uriStr = uri.toString()
            val existing = dao.getSongByUri(uriStr)
            if (existing != null) {
                importedIds.add(existing.id)
                continue
            }

            val meta = extractAudioMetadata(resolver, uri)
            val color = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = lastColor)
            lastColor = color

            val insertedId = dao.insertSong(
                SongEntity(
                    title = meta.title,
                    artist = meta.artist,
                    audioUri = uriStr,
                    durationMs = meta.durationMs,
                    backgroundColorArgb = color,
                    sourceType = SourceType.OFFLINE_LOCAL.name,
                    sourceLabel = "Offline Device File",
                    licenseName = "Local Storage",
                    isFavorite = false,
                    lyricsRaw = meta.lyrics,
                    addedAtMs = System.currentTimeMillis(),
                    album = meta.album,
                    folderName = "Imported Files",
                    genre = meta.genre,
                    bpm = 104,
                    energyScore = 0.62f,
                    mood = "Balanced",
                )
            )
            importedIds.add(insertedId)
        }
        importedIds
    }

    suspend fun searchAuthorizedOnlineTracks(query: String, page: Int = 0): OnlineSearchOutcome =
        withContext(Dispatchers.IO) {
            val cleanQuery = query.trim()
            val curatedMatches = if (page == 0) {
                CuratedAuthorizedCatalog.featuredTracks.filter { candidate ->
                    cleanQuery.isEmpty() || matchesAllQueryTokens(candidate, cleanQuery)
                }
            } else {
                emptyList()
            }

            if (!isNetworkConnected()) {
                return@withContext OnlineSearchOutcome(
                    tracks = emptyList(),
                    page = page,
                    hasMore = false,
                    errorMessage = "No internet connection. Connect to Wi-Fi or mobile data and tap Retry to browse and stream online music.",
                    isOffline = true,
                )
            }

            var audiusError: Throwable? = null
            var itunesError: Throwable? = null
            var archiveError: Throwable? = null
            var wikimediaError: Throwable? = null

            val reportedUrls = dao.getReportedStreamUrls().toSet()
            val audiusOffset = page * AUDIUS_PAGE_SIZE
            val itunesOffset = page * ITUNES_PAGE_SIZE

            val (audiusResult, itunesResult, archiveResult, wikimediaResult) = coroutineScope {
                val audiusDeferred = async {
                    runCatching {
                        var streamHost = "api.audius.co"
                        val res = try {
                            if (cleanQuery.isEmpty()) {
                                audiusApi.getTrendingTracks(limit = AUDIUS_PAGE_SIZE, offset = audiusOffset)
                            } else {
                                audiusApi.searchTracks(query = cleanQuery, limit = AUDIUS_PAGE_SIZE, offset = audiusOffset)
                            }
                        } catch (primaryErr: Throwable) {
                            val fallback = fallbackAudiusApi ?: throw primaryErr
                            streamHost = "discoveryprovider.audius.co"
                            if (cleanQuery.isEmpty()) {
                                fallback.getTrendingTracks(limit = AUDIUS_PAGE_SIZE, offset = audiusOffset)
                            } else {
                                fallback.searchTracks(query = cleanQuery, limit = AUDIUS_PAGE_SIZE, offset = audiusOffset)
                            }
                        }
                        val mapped = res.data.mapNotNull { dto ->
                            val trackId = dto.id?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                            val title = dto.title?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
                            if (dto.isStreamable == false || dto.streamConditions != null) {
                                return@mapNotNull null
                            }
                            val rawLicense = dto.ccLicense?.takeIf { it.isNotBlank() }
                                ?: dto.license?.takeIf { it.isNotBlank() }
                            if (rawLicense != null &&
                                (AuthorizedSourceValidator.isNonCommercialLicense(rawLicense) ||
                                    rawLicense.contains("all rights reserved", ignoreCase = true))
                            ) {
                                return@mapNotNull null
                            }
                            val durationSec = dto.duration
                            // Never treat <=30s snippets as full-length tracks
                            if (durationSec != null && durationSec in 1..30) {
                                return@mapNotNull null
                            }
                            val streamUrl = "https://$streamHost/v1/tracks/$trackId/stream?app_name=SUNOZA"
                            val licenseInput = rawLicense ?: "Audius API Stream (Artist Opt-In — Verify Track License)"
                            val artistName = dto.user?.name?.takeIf { it.isNotBlank() }
                                ?: dto.user?.handle
                                ?: "Audius Artist"
                            val permalinkUrl = dto.permalink?.takeIf { it.isNotBlank() }?.let { rawLink ->
                                if (rawLink.startsWith("http", ignoreCase = true)) {
                                    rawLink
                                } else {
                                    "https://audius.co${if (rawLink.startsWith("/")) rawLink else "/$rawLink"}"
                                }
                            }
                            when (val check = AuthorizedSourceValidator.validateUrl(streamUrl, licenseInput)) {
                                is SourceValidationResult.Authorized -> OnlineTrackCandidate(
                                    id = "audius-$trackId",
                                    title = title,
                                    artist = artistName,
                                    album = dto.genre?.takeIf { it.isNotBlank() }?.let { "Single · $it" }
                                        ?: "Audius Single",
                                    artworkUrl = dto.artwork?.bestUrl(),
                                    genre = dto.genre?.takeIf { it.isNotBlank() } ?: "Electronic",
                                    streamUrl = check.normalizedUrl,
                                    durationMs = durationSec?.takeIf { it > 30 }?.times(1_000L) ?: 0L,
                                    providerName = check.providerName,
                                    licenseName = check.licenseName,
                                    isPreviewOnly = false,
                                    licenseUrl = rawLicense?.takeIf { it.startsWith("http", ignoreCase = true) },
                                    sourcePageUrl = permalinkUrl,
                                    isLicenseVerified = check.isLicenseVerified,
                                    attributionText = "Streamed via Audius API · Artist: $artistName",
                                )
                                is SourceValidationResult.Rejected -> null
                            }
                        }
                        mapped to (res.data.size >= AUDIUS_PAGE_SIZE)
                    }.onFailure { audiusError = it }.getOrElse { emptyList<OnlineTrackCandidate>() to false }
                }

                val itunesDeferred = async {
                    runCatching {
                        val term = cleanQuery.ifEmpty { "electronic synthwave" }
                        val res = itunesApi.searchSongs(term = term, limit = ITUNES_PAGE_SIZE, offset = itunesOffset)
                        val mapped = res.results.mapNotNull { dto ->
                            val preview = dto.previewUrl?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                            val title = dto.trackName?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                            val storeUrl = dto.trackViewUrl?.takeIf { it.isNotBlank() }
                                ?: dto.collectionViewUrl?.takeIf { it.isNotBlank() }
                            when (val check = AuthorizedSourceValidator.validateUrl(preview, "Official 30s Preview")) {
                                is SourceValidationResult.Authorized -> OnlineTrackCandidate(
                                    id = "itunes-${dto.trackId ?: title.hashCode()}",
                                    title = title,
                                    artist = dto.artistName?.takeIf { it.isNotBlank() } ?: "Unknown Artist",
                                    album = dto.collectionName?.takeIf { it.isNotBlank() } ?: "Single",
                                    artworkUrl = dto.highResArtworkUrl(),
                                    genre = dto.primaryGenreName?.takeIf { it.isNotBlank() } ?: "Music",
                                    streamUrl = check.normalizedUrl,
                                    durationMs = 30_000L,
                                    fullTrackDurationMs = dto.trackTimeMillis?.takeIf { it > 0L },
                                    providerName = check.providerName,
                                    licenseName = "Apple iTunes 30s Preview (Promotional Only)",
                                    isPreviewOnly = true,
                                    sourcePageUrl = storeUrl,
                                    externalStoreUrl = storeUrl,
                                    isLicenseVerified = false,
                                    attributionText = "Provided courtesy of iTunes",
                                )
                                is SourceValidationResult.Rejected -> null
                            }
                        }
                        mapped to (res.results.size >= ITUNES_PAGE_SIZE)
                    }.onFailure { itunesError = it }.getOrElse { emptyList<OnlineTrackCandidate>() to false }
                }

                val archiveDeferred = async {
                    runCatching {
                        val luceneQuery = buildArchiveLuceneQuery(cleanQuery)
                        val searchRes = archiveApi.searchAudio(
                            query = luceneQuery,
                            rows = ARCHIVE_PAGE_SIZE,
                            page = page + 1,
                        )
                        val docs = searchRes.response?.docs.orEmpty().take(ARCHIVE_PAGE_SIZE)
                        val resolved = coroutineScope {
                            docs.map { doc ->
                                async {
                                    val identifier = doc.identifier?.takeIf { it.isNotBlank() } ?: return@async null
                                    runCatching {
                                        val meta = archiveApi.getItemMetadata(identifier)
                                        if (meta.isDark == true) return@runCatching null

                                        val effectiveLicense = meta.metadata?.licenseUrl?.takeIf { it.isNotBlank() }
                                            ?: doc.licenseUrl?.takeIf { it.isNotBlank() }
                                            ?: return@runCatching null

                                        val playableFiles = meta.files.filter { file ->
                                            if (file.isPrivateFile()) return@filter false
                                            val name = file.name?.lowercase().orEmpty()
                                            val isAudioExt = name.endsWith(".mp3") || name.endsWith(".m4a") ||
                                                name.endsWith(".aac") || name.endsWith(".ogg") || name.endsWith(".flac")
                                            if (!isAudioExt) return@filter false
                                            val dur = file.parseDurationMs()
                                            // Exclude 1-30s snippets from full-track Archive results
                                            dur == null || dur > 30_000L
                                        }
                                        val audioFile = selectBestArchiveAudioFile(playableFiles)
                                            ?: return@runCatching null

                                        val encodedName = URLEncoder.encode(audioFile.name, "UTF-8").replace("+", "%20")
                                        val streamUrl = "https://archive.org/download/$identifier/$encodedName"
                                        when (val validation = AuthorizedSourceValidator.validateUrl(streamUrl, effectiveLicense)) {
                                            is SourceValidationResult.Authorized -> {
                                                if (!validation.isLicenseVerified) return@runCatching null
                                                val parsedDuration = audioFile.parseDurationMs() ?: 0L
                                                val albumName = meta.metadata?.album?.takeIf { it.isNotBlank() }
                                                    ?: "Internet Archive"
                                                val artistName = doc.creatorText().take(60)
                                                OnlineTrackCandidate(
                                                    id = "ia-$identifier-${audioFile.name}",
                                                    title = (audioFile.title ?: doc.title ?: identifier).take(80),
                                                    artist = artistName,
                                                    album = albumName.take(60),
                                                    artworkUrl = "https://archive.org/services/img/$identifier",
                                                    genre = validation.licenseName,
                                                    streamUrl = validation.normalizedUrl,
                                                    durationMs = parsedDuration,
                                                    providerName = validation.providerName,
                                                    licenseName = validation.licenseName,
                                                    isPreviewOnly = false,
                                                    licenseUrl = effectiveLicense.takeIf { it.startsWith("http", ignoreCase = true) },
                                                    sourcePageUrl = "https://archive.org/details/$identifier",
                                                    isLicenseVerified = validation.isLicenseVerified,
                                                    attributionText = "Internet Archive · $artistName (${validation.licenseName})",
                                                )
                                            }
                                            is SourceValidationResult.Rejected -> null
                                        }
                                    }.getOrNull()
                                }
                            }.awaitAll().filterNotNull()
                        }
                        val numFound = searchRes.response?.numFound ?: 0
                        val hasMoreArchive = docs.isNotEmpty() && ((page + 1) * ARCHIVE_PAGE_SIZE < numFound || docs.size >= ARCHIVE_PAGE_SIZE)
                        resolved to hasMoreArchive
                    }.onFailure { archiveError = it }.getOrElse { emptyList<OnlineTrackCandidate>() to false }
                }

                val wikimediaDeferred = async {
                    val api = wikimediaApi ?: return@async (emptyList<OnlineTrackCandidate>() to false)
                    runCatching {
                        val term = cleanQuery.ifEmpty { "music instrumental" }
                        val bodyStr = api.searchAudioFiles(
                            gsrsearch = "$term filetype:audio",
                            gsrlimit = WIKIMEDIA_PAGE_SIZE,
                            gsroffset = page * WIKIMEDIA_PAGE_SIZE,
                        ).use { it.string() }
                        val mapped = parseWikimediaAudioResults(bodyStr)
                        mapped to (mapped.size >= WIKIMEDIA_PAGE_SIZE)
                    }.onFailure { wikimediaError = it }.getOrElse { emptyList<OnlineTrackCandidate>() to false }
                }

                listOf(
                    audiusDeferred.await(),
                    itunesDeferred.await(),
                    archiveDeferred.await(),
                    wikimediaDeferred.await(),
                )
            }.let { list ->
                @Suppress("UNCHECKED_CAST")
                Quadruple(list[0], list[1], list[2], list[3])
            }

            val remoteFullTracks = (audiusResult.first + archiveResult.first + wikimediaResult.first)
                .filterNot { it.streamUrl in reportedUrls }
            val filteredItunes = itunesResult.first.filterNot { it.streamUrl in reportedUrls }
            val filteredCurated = curatedMatches.filterNot { it.streamUrl in reportedUrls }
            val remoteCombined = remoteFullTracks + filteredItunes
            val allRanked = deduplicateAndRankCandidates(
                candidates = remoteCombined + filteredCurated,
                query = cleanQuery,
            )
            val hasMorePages = (page < MAX_ONLINE_PAGES) &&
                (audiusResult.second || archiveResult.second || wikimediaResult.second || itunesResult.second)

            if (remoteCombined.isEmpty() &&
                (audiusError != null || itunesError != null || archiveError != null || wikimediaError != null)
            ) {
                val primaryErr = audiusError ?: archiveError ?: wikimediaError ?: itunesError
                val reason = primaryErr?.localizedMessage?.take(120) ?: "Connection timed out"
                return@withContext OnlineSearchOutcome(
                    tracks = allRanked,
                    page = page,
                    hasMore = false,
                    errorMessage = "Online catalog servers unavailable ($reason). Tap Retry when connected.",
                    isOffline = false,
                )
            }

            if (audiusError != null && remoteFullTracks.isEmpty() && filteredItunes.isNotEmpty()) {
                val reason = audiusError?.localizedMessage?.take(90) ?: "Audius unavailable"
                return@withContext OnlineSearchOutcome(
                    tracks = allRanked,
                    page = page,
                    hasMore = hasMorePages,
                    errorMessage = "Full-track catalog error ($reason). The results below include 30-second iTunes previews only; previews will not substitute full tracks.",
                    isOffline = false,
                )
            }

            OnlineSearchOutcome(
                tracks = allRanked,
                page = page,
                hasMore = hasMorePages,
                errorMessage = null,
                isOffline = false,
            )
        }

    suspend fun verifyPlayableCandidate(candidate: OnlineTrackCandidate): Result<OnlineTrackCandidate> =
        withContext(Dispatchers.IO) {
            if (candidate.streamUrl in dao.getReportedStreamUrls()) {
                return@withContext Result.failure(
                    IllegalArgumentException("This stream was reported and blocked on this device.")
                )
            }
            val validation = AuthorizedSourceValidator.validateUrl(candidate.streamUrl, candidate.licenseName)
            if (validation is SourceValidationResult.Rejected) {
                return@withContext Result.failure(IllegalArgumentException(validation.reason))
            }
            val normalizedCandidate = if (candidate.streamUrl.contains("audio-ssl.itunes.apple.com", ignoreCase = true)) {
                candidate.copy(
                    isPreviewOnly = true,
                    durationMs = 30_000L,
                    licenseName = "Apple iTunes 30s Preview (Promotional Only)",
                    attributionText = candidate.attributionText.ifBlank { "Provided courtesy of iTunes" },
                    isLicenseVerified = false,
                )
            } else {
                candidate
            }

            val client = streamHttpClient
            if (client == null || normalizedCandidate.isPreviewOnly) {
                return@withContext Result.success(normalizedCandidate)
            }

            val urlsToTry = buildList {
                add(normalizedCandidate.streamUrl)
                if (normalizedCandidate.streamUrl.startsWith("https://api.audius.co/")) {
                    add(normalizedCandidate.streamUrl.replace("https://api.audius.co/", "https://discoveryprovider.audius.co/"))
                }
            }

            var lastFailure: String? = null
            for (candidateUrl in urlsToTry) {
                val probe = probeRemoteAudioStream(client, candidateUrl)
                if (probe.isPlayable) {
                    return@withContext Result.success(
                        normalizedCandidate.copy(streamUrl = candidateUrl)
                    )
                }
                lastFailure = probe.failureReason
            }

            Result.failure(
                IllegalStateException(
                    lastFailure ?: "Unable to verify playable full-length stream from ${normalizedCandidate.providerName}."
                )
            )
        }

    suspend fun addAuthorizedOnlineCandidate(candidate: OnlineTrackCandidate): Result<Song> =
        withContext(Dispatchers.IO) {
            if (candidate.streamUrl in dao.getReportedStreamUrls()) {
                return@withContext Result.failure(
                    IllegalArgumentException("This stream was reported and blocked on this device.")
                )
            }
            val enforcesPreview = candidate.isPreviewOnly ||
                candidate.streamUrl.contains("audio-ssl.itunes.apple.com", ignoreCase = true)
            val effectiveDurationMs = if (enforcesPreview) 30_000L else candidate.durationMs
            val effectiveLicense = if (enforcesPreview) {
                "Apple iTunes 30s Preview (Promotional Only)"
            } else {
                candidate.licenseName
            }
            val effectiveAttribution = if (enforcesPreview) {
                "Provided courtesy of iTunes"
            } else {
                candidate.attributionText
            }

            when (val validation = AuthorizedSourceValidator.validateUrl(candidate.streamUrl, effectiveLicense)) {
                is SourceValidationResult.Rejected -> {
                    Result.failure(IllegalArgumentException(validation.reason))
                }
                is SourceValidationResult.Authorized -> {
                    val resolvedAlbum = candidate.album.ifBlank { validation.providerName }
                    val resolvedGenre = candidate.genre.ifBlank {
                        if (validation.isLicenseVerified) validation.licenseName else "Open Stream"
                    }
                    val effectiveVerified = if (enforcesPreview) {
                        false
                    } else {
                        candidate.isLicenseVerified && validation.isLicenseVerified
                    }
                    val existing = dao.getSongByUri(validation.normalizedUrl)
                    if (existing != null) {
                        val nextArtwork = existing.artworkUri?.takeIf { it.isNotBlank() } ?: candidate.artworkUrl
                        val nextDuration = when {
                            enforcesPreview -> 30_000L
                            existing.durationMs <= 0L && effectiveDurationMs > 0L -> effectiveDurationMs
                            else -> existing.durationMs
                        }
                        if (nextArtwork != existing.artworkUri || nextDuration != existing.durationMs) {
                            dao.updateSongMetadataWithDuration(
                                songId = existing.id,
                                artworkUri = nextArtwork,
                                album = resolvedAlbum,
                                genre = resolvedGenre,
                                durationMs = nextDuration,
                            )
                            return@withContext Result.success(
                                existing.copy(
                                    artworkUri = nextArtwork,
                                    album = resolvedAlbum,
                                    genre = resolvedGenre,
                                    durationMs = nextDuration,
                                    licenseName = if (enforcesPreview) {
                                        "Apple iTunes 30s Preview (Promotional Only)"
                                    } else {
                                        existing.licenseName
                                    },
                                    mood = if (enforcesPreview) "Preview" else existing.mood,
                                    attributionText = if (enforcesPreview) {
                                        "Provided courtesy of iTunes"
                                    } else {
                                        existing.attributionText.ifBlank { effectiveAttribution }
                                    },
                                    externalStoreUrl = existing.externalStoreUrl ?: candidate.externalStoreUrl,
                                ).toDomain()
                            )
                        }
                        return@withContext Result.success(existing.toDomain())
                    }
                    val entity = SongEntity(
                        title = candidate.title.ifBlank { "Authorized Track" },
                        artist = candidate.artist.ifBlank { "Independent Artist" },
                        audioUri = validation.normalizedUrl,
                        durationMs = effectiveDurationMs,
                        backgroundColorArgb = SongColorGenerator.nextSolidColorArgb(),
                        sourceType = SourceType.AUTHORIZED_ONLINE.name,
                        sourceLabel = validation.providerName,
                        licenseName = effectiveLicense.ifBlank { validation.licenseName },
                        isFavorite = false,
                        lyricsRaw = candidate.lyricsRaw,
                        addedAtMs = System.currentTimeMillis(),
                        album = resolvedAlbum,
                        artworkUri = candidate.artworkUrl,
                        folderName = "Online Streams",
                        genre = resolvedGenre,
                        bpm = 112,
                        energyScore = 0.70f,
                        mood = if (enforcesPreview) "Preview" else "Streaming",
                        licenseUrl = candidate.licenseUrl,
                        sourcePageUrl = candidate.sourcePageUrl,
                        externalStoreUrl = candidate.externalStoreUrl,
                        isLicenseVerified = effectiveVerified,
                        attributionText = effectiveAttribution,
                    )
                    val id = dao.insertSong(entity)
                    Result.success(entity.copy(id = id).toDomain())
                }
            }
        }

    suspend fun addAuthorizedStreamByUrl(
        rawUrl: String,
        title: String,
        artist: String,
    ): Result<Song> = withContext(Dispatchers.IO) {
        when (val validation = AuthorizedSourceValidator.validateUrl(rawUrl)) {
            is SourceValidationResult.Rejected -> {
                Result.failure(IllegalArgumentException(validation.reason))
            }
            is SourceValidationResult.Authorized -> {
                if (validation.normalizedUrl in dao.getReportedStreamUrls()) {
                    return@withContext Result.failure(
                        IllegalArgumentException("This stream was reported and blocked on this device.")
                    )
                }
                val existing = dao.getSongByUri(validation.normalizedUrl)
                if (existing != null) {
                    return@withContext Result.success(existing.toDomain())
                }
                val fallbackTitle = Uri.parse(validation.normalizedUrl)
                    .lastPathSegment
                    ?.substringBeforeLast('.')
                    ?.replace('_', ' ')
                    ?.replace('-', ' ')
                    ?.ifBlank { "Authorized Stream" }
                    ?: "Authorized Stream"

                val entity = SongEntity(
                    title = title.trim().ifBlank { fallbackTitle },
                    artist = artist.trim().ifBlank { validation.providerName },
                    audioUri = validation.normalizedUrl,
                    durationMs = 180_000L,
                    backgroundColorArgb = SongColorGenerator.nextSolidColorArgb(),
                    sourceType = SourceType.AUTHORIZED_ONLINE.name,
                    sourceLabel = validation.providerName,
                    licenseName = validation.licenseName,
                    isFavorite = false,
                    lyricsRaw = "",
                    addedAtMs = System.currentTimeMillis(),
                    album = validation.providerName,
                    folderName = "Online Streams",
                    genre = "External Stream",
                    bpm = 108,
                    energyScore = 0.65f,
                    mood = "Discovery",
                    isLicenseVerified = validation.isLicenseVerified,
                    attributionText = "External stream via ${validation.providerName} — verify track license before commercial reuse",
                )
                val id = dao.insertSong(entity)
                Result.success(entity.copy(id = id).toDomain())
            }
        }
    }

    suspend fun reportTrack(
        streamUrl: String,
        title: String,
        artist: String,
        providerName: String,
        reason: String,
        reporterEmail: String,
        details: String,
    ): Long = withContext(Dispatchers.IO) {
        val cleanUrl = streamUrl.trim()
        val id = dao.insertReportedTrack(
            ReportedTrackEntity(
                streamUrl = cleanUrl,
                title = title.trim().ifBlank { "General Report" },
                artist = artist.trim(),
                providerName = providerName.trim(),
                reason = reason.trim(),
                reporterEmail = reporterEmail.trim(),
                details = details.trim(),
            )
        )
        if (cleanUrl.isNotEmpty()) {
            dao.deleteSongByUri(cleanUrl)
        }
        id
    }

    suspend fun recordSongPlayed(song: Song) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        dao.recordSongPlay(song.id, now)
        dao.insertListeningEvent(
            ListeningEventEntity(
                songId = song.id,
                playedAtMs = now,
                sourceType = song.sourceType.name,
            )
        )
    }

    suspend fun updateSongAnalysis(songId: Long, bpm: Int, energyScore: Float) =
        withContext(Dispatchers.IO) {
            dao.updateAudioAnalysis(songId, bpm, energyScore)
        }

    suspend fun toggleFavorite(songId: Long, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        dao.setFavorite(songId, isFavorite)
    }

    suspend fun updateLyrics(songId: Long, lyricsRaw: String) = withContext(Dispatchers.IO) {
        dao.updateLyrics(songId, lyricsRaw.trim())
    }

    suspend fun randomizeSongColor(songId: Long, currentColorArgb: Long) = withContext(Dispatchers.IO) {
        val next = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = currentColorArgb)
        dao.updateBackgroundColor(songId, next)
    }

    suspend fun deleteSong(songId: Long) = withContext(Dispatchers.IO) {
        dao.deleteSongById(songId)
    }

    suspend fun createPlaylist(name: String): Long = withContext(Dispatchers.IO) {
        dao.insertPlaylist(PlaylistEntity(name = name.trim()))
    }

    suspend fun renamePlaylist(playlistId: Long, name: String) = withContext(Dispatchers.IO) {
        dao.renamePlaylist(playlistId, name.trim())
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        dao.deletePlaylist(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        val nextPos = dao.getMaxPlaylistPosition(playlistId) + 1
        dao.addSongToPlaylist(
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = songId,
                position = nextPos,
            )
        )
    }

    suspend fun reorderPlaylistSongs(playlistId: Long, orderedSongIds: List<Long>) =
        withContext(Dispatchers.IO) {
            dao.updatePlaylistOrder(playlistId, orderedSongIds)
        }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        dao.removeSongFromPlaylist(playlistId, songId)
    }

    suspend fun saveMixPreset(
        name: String,
        deckASongId: Long,
        deckBSongId: Long,
        crossfader: Float,
        transitionDurationSec: Int,
        filterType: TransitionFilterType,
        echoAmount: Float,
        autoMixEnabled: Boolean,
    ): Long = withContext(Dispatchers.IO) {
        dao.insertSavedMix(
            SavedMixEntity(
                name = name.trim().ifBlank { "Sunoza Mix" },
                deckASongId = deckASongId,
                deckBSongId = deckBSongId,
                crossfader = crossfader,
                transitionDurationSec = transitionDurationSec,
                filterType = filterType.name,
                echoAmount = echoAmount,
                autoMixEnabled = autoMixEnabled,
            )
        )
    }

    suspend fun deleteSavedMix(mixId: Long) = withContext(Dispatchers.IO) {
        dao.deleteSavedMix(mixId)
    }

    private data class ExtractedAudioMeta(
        val title: String,
        val artist: String,
        val album: String,
        val genre: String,
        val durationMs: Long,
        val lyrics: String,
    )

    private fun extractAudioMetadata(resolver: ContentResolver, uri: Uri): ExtractedAudioMeta {
        val displayName = queryDisplayName(resolver, uri)
            ?.substringBeforeLast('.')
            ?.trim()
            .orEmpty()

        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val embeddedTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim()
            val embeddedArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim()
            val embeddedAlbum = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.trim()
            val embeddedGenre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)?.trim()
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?.coerceAtLeast(1_000L)
                ?: 180_000L

            val (parsedArtist, parsedTitle) = if (displayName.contains(" - ")) {
                val parts = displayName.split(" - ", limit = 2)
                parts[0].trim() to parts[1].trim()
            } else {
                "" to displayName
            }

            ExtractedAudioMeta(
                title = embeddedTitle?.takeIf { it.isNotEmpty() }
                    ?: parsedTitle.ifEmpty { "Local Audio Track" },
                artist = embeddedArtist?.takeIf { it.isNotEmpty() }
                    ?: parsedArtist.ifEmpty { "Offline Artist" },
                album = embeddedAlbum?.takeIf { it.isNotEmpty() } ?: "Single",
                genre = embeddedGenre?.takeIf { it.isNotEmpty() } ?: "Local Audio",
                durationMs = durationMs,
                lyrics = "",
            )
        } catch (_: Exception) {
            ExtractedAudioMeta(
                title = displayName.ifEmpty { "Local Audio Track" },
                artist = "Offline Artist",
                album = "Single",
                genre = "Local Audio",
                durationMs = 180_000L,
                lyrics = "",
            )
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        return resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else {
                null
            }
        }
    }

    private data class StreamProbeResult(
        val isPlayable: Boolean,
        val failureReason: String? = null,
    )

    private fun probeRemoteAudioStream(client: OkHttpClient, url: String): StreamProbeResult {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("Range", "bytes=0-2047")
                .build()
            client.newCall(req).execute().use { res ->
                if (res.code !in 200..299 && res.code != 416) {
                    return StreamProbeResult(
                        isPlayable = false,
                        failureReason = "Stream returned HTTP ${res.code}",
                    )
                }
                val contentType = res.header("Content-Type").orEmpty().lowercase()
                val looksLikeAudio = contentType.isBlank() ||
                    contentType.startsWith("audio/") ||
                    contentType.contains("ogg") ||
                    contentType.contains("octet-stream") ||
                    contentType.contains("mp4") ||
                    contentType.contains("mpeg")
                if (!looksLikeAudio) {
                    return StreamProbeResult(
                        isPlayable = false,
                        failureReason = "Provider returned non-audio response ($contentType)",
                    )
                }
                val contentRange = res.header("Content-Range").orEmpty()
                val totalFromRange = contentRange.substringAfter('/', "").toLongOrNull()
                val totalBytes = totalFromRange ?: res.header("Content-Length")?.toLongOrNull()
                if (totalBytes != null && totalBytes in 1L..16_383L) {
                    return StreamProbeResult(
                        isPlayable = false,
                        failureReason = "Audio stream was empty or incomplete ($totalBytes bytes)",
                    )
                }
                StreamProbeResult(isPlayable = true)
            }
        } catch (e: Exception) {
            StreamProbeResult(
                isPlayable = false,
                failureReason = e.localizedMessage ?: "Failed to connect to audio stream",
            )
        }
    }

    private data class Quadruple<A, B, C, D>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D,
    )

    companion object {
        const val AUDIUS_PAGE_SIZE = 15
        const val ITUNES_PAGE_SIZE = 12
        const val ARCHIVE_PAGE_SIZE = 8
        const val WIKIMEDIA_PAGE_SIZE = 6
        const val MAX_ONLINE_PAGES = 8

        internal fun buildArchiveLuceneQuery(cleanQuery: String): String {
            val baseFilter = "mediatype:audio AND NOT mediatype:collection AND " +
                "(licenseurl:*creativecommons* OR licenseurl:*publicdomain*) AND " +
                "NOT licenseurl:(*by-nc* OR *nc-sa* OR *nc-nd* OR */nc/* OR *noncommercial*) AND " +
                "format:(\"VBR MP3\" OR \"MP3\" OR \"Ogg Vorbis\" OR \"Flac\")"
            if (cleanQuery.isEmpty()) {
                return "$baseFilter AND (collection:netlabels OR collection:freemusicarchive OR subject:music)"
            }
            val escaped = cleanQuery
                .replace(Regex("""[+\-&|!(){}\[\]^"~*?:\\/]"""), " ")
                .trim()
                .replace(Regex("""\s+"""), " ")
            if (escaped.isEmpty()) {
                return "$baseFilter AND (collection:netlabels OR subject:music)"
            }
            val terms = escaped.split(' ').filter { it.isNotBlank() }
            val termClause = if (terms.size > 1) {
                terms.joinToString(" AND ") { "\"$it\"" }
            } else {
                "\"$escaped\""
            }
            return "$baseFilter AND (title:($termClause) OR creator:($termClause) OR album:($termClause) OR subject:($termClause) OR ($termClause))"
        }

        internal fun selectBestArchiveAudioFile(files: List<com.example.data.remote.ArchiveFileDto>): com.example.data.remote.ArchiveFileDto? {
            return files.minByOrNull { file ->
                val name = file.name?.lowercase().orEmpty()
                val lowQualityPenalty = if (name.contains("_64kb") || name.contains("sample") || name.contains("preview")) 100 else 0
                val extRank = when {
                    name.endsWith(".mp3") -> 0
                    name.endsWith(".m4a") -> 1
                    name.endsWith(".aac") -> 2
                    name.endsWith(".ogg") -> 3
                    name.endsWith(".flac") -> 4
                    else -> 5
                }
                lowQualityPenalty + extRank
            }
        }

        internal fun parseWikimediaAudioResults(rawJson: String): List<OnlineTrackCandidate> {
            val moshi = Moshi.Builder().build()
            val root = runCatching { moshi.adapter(Map::class.java).fromJson(rawJson) }.getOrNull()
                ?: return emptyList()
            val queryObj = root["query"] as? Map<*, *> ?: return emptyList()
            val pages = queryObj["pages"] as? Map<*, *> ?: return emptyList()

            return pages.values.mapNotNull { value ->
                val pageMap = value as? Map<*, *> ?: return@mapNotNull null
                val rawPageTitle = pageMap["title"]?.toString() ?: return@mapNotNull null
                if (rawPageTitle.contains("Pronunciation", ignoreCase = true) ||
                    Regex("""File:(En|De|Fr|Es|It|Ru|Zh)-""", RegexOption.IGNORE_CASE).containsMatchIn(rawPageTitle)
                ) {
                    return@mapNotNull null
                }
                val infoList = pageMap["imageinfo"] as? List<*> ?: return@mapNotNull null
                val info = infoList.firstOrNull() as? Map<*, *> ?: return@mapNotNull null
                val rawUrl = info["url"]?.toString()?.substringBefore("?") ?: return@mapNotNull null
                val sizeBytes = (info["size"] as? Number)?.toLong() ?: 0L
                // Filter out tiny <350KB sound effects or 5-second clips
                if (sizeBytes in 1L..349_999L) return@mapNotNull null

                val durationSec = (info["duration"] as? Number)?.toDouble() ?: 0.0
                val parsedDurationMs = if (durationSec > 0.0) (durationSec * 1_000.0).toLong() else 0L
                if (parsedDurationMs in 1L..30_000L) return@mapNotNull null

                val extMeta = info["extmetadata"] as? Map<*, *>
                val artistHtml = (extMeta?.get("Artist") as? Map<*, *>)?.get("value")?.toString()
                val licenseShort = (extMeta?.get("LicenseShortName") as? Map<*, *>)
                    ?.get("value")?.toString()?.trim()?.takeIf { it.isNotBlank() }
                val licenseUrlVal = (extMeta?.get("LicenseUrl") as? Map<*, *>)
                    ?.get("value")?.toString()?.trim()?.takeIf { it.isNotBlank() }

                val rawLicense = licenseShort ?: licenseUrlVal ?: return@mapNotNull null
                if (licenseUrlVal != null && AuthorizedSourceValidator.isNonCommercialLicense(licenseUrlVal)) {
                    return@mapNotNull null
                }

                when (val validation = AuthorizedSourceValidator.validateUrl(rawUrl, rawLicense)) {
                    is SourceValidationResult.Authorized -> {
                        if (!validation.isLicenseVerified) return@mapNotNull null
                        val cleanTitle = rawPageTitle
                            .removePrefix("File:")
                            .substringBeforeLast('.')
                            .replace('_', ' ')
                            .trim()
                        val cleanArtist = artistHtml
                            ?.replace(Regex("<[^>]*>"), " ")
                            ?.replace(Regex("\\s+"), " ")
                            ?.trim()
                            ?.takeIf { it.isNotBlank() }
                            ?.take(50)
                            ?: "Wikimedia Commons Contributor"
                        val encodedTitle = URLEncoder.encode(rawPageTitle.replace(' ', '_'), "UTF-8")
                            .replace("%3A", ":")
                        OnlineTrackCandidate(
                            id = "wm-${rawPageTitle.hashCode()}",
                            title = cleanTitle.take(80),
                            artist = cleanArtist,
                            album = "Wikimedia Commons Audio",
                            genre = validation.licenseName,
                            streamUrl = validation.normalizedUrl,
                            durationMs = parsedDurationMs,
                            providerName = validation.providerName,
                            licenseName = validation.licenseName,
                            isPreviewOnly = false,
                            licenseUrl = licenseUrlVal?.takeIf { it.startsWith("http", ignoreCase = true) },
                            sourcePageUrl = "https://commons.wikimedia.org/wiki/$encodedTitle",
                            isLicenseVerified = validation.isLicenseVerified,
                            attributionText = "$cleanArtist via Wikimedia Commons (${validation.licenseName}). Attribution required; Wikimedia Foundation does not endorse Sunoza.",
                        )
                    }
                    is SourceValidationResult.Rejected -> null
                }
            }
        }

        internal fun matchesAllQueryTokens(candidate: OnlineTrackCandidate, query: String): Boolean {
            val tokens = query.trim().lowercase().split(Regex("""\s+""")).filter { it.isNotBlank() }
            if (tokens.isEmpty()) return true
            val haystack = listOf(
                candidate.title,
                candidate.artist,
                candidate.album,
                candidate.genre,
                candidate.providerName,
            ).joinToString(" ").lowercase()
            return tokens.all { haystack.contains(it) }
        }

        internal fun scoreQueryRelevance(candidate: OnlineTrackCandidate, query: String): Int {
            val q = query.trim().lowercase()
            if (q.isEmpty()) return 100

            val title = candidate.title.lowercase()
            val artist = candidate.artist.lowercase()
            val album = candidate.album.lowercase()
            val genre = candidate.genre.lowercase()
            val tokens = q.split(Regex("""\s+""")).filter { it.isNotBlank() }

            var score = 0
            if (title == q) score += 200
            else if (title.startsWith(q)) score += 130
            else if (title.contains(q)) score += 90

            if (artist == q) score += 170
            else if (artist.startsWith(q)) score += 110
            else if (artist.contains(q)) score += 75

            if (album == q) score += 120
            else if (album.contains(q)) score += 60

            if (genre.contains(q)) score += 30

            val combined = "$title $artist $album $genre"
            val matchedTokens = tokens.count { combined.contains(it) }
            score += matchedTokens * 25
            if (tokens.isNotEmpty() && matchedTokens == tokens.size) {
                score += 65
            }
            return score
        }

        private fun providerPriority(candidate: OnlineTrackCandidate): Int {
            return when {
                !candidate.isPreviewOnly && candidate.providerName.contains("Audius", ignoreCase = true) -> 4
                !candidate.isPreviewOnly && candidate.providerName.contains("Archive", ignoreCase = true) -> 3
                !candidate.isPreviewOnly && candidate.providerName.contains("SoundHelix", ignoreCase = true) -> 2
                !candidate.isPreviewOnly -> 1
                else -> 0
            }
        }

        fun deduplicateAndRankCandidates(
            candidates: List<OnlineTrackCandidate>,
            query: String,
        ): List<OnlineTrackCandidate> {
            val seenStreamUrls = HashSet<String>()
            val seenIds = HashSet<String>()
            val seenIdentity = HashSet<String>()
            val unique = mutableListOf<OnlineTrackCandidate>()

            for (item in candidates) {
                val identityKey = "${item.title.trim().lowercase()}|${item.artist.trim().lowercase()}|${item.isPreviewOnly}"
                if (seenStreamUrls.add(item.streamUrl) &&
                    seenIds.add(item.id) &&
                    seenIdentity.add(identityKey)
                ) {
                    unique.add(item)
                }
            }

            return unique.sortedWith(
                compareBy<OnlineTrackCandidate> { it.isPreviewOnly }
                    .thenByDescending { scoreQueryRelevance(it, query) }
                    .thenByDescending { providerPriority(it) }
                    .thenByDescending { if (it.durationMs > 30_000L) 1 else 0 }
            )
        }

        fun mergeAndDeduplicateCandidates(
            existing: List<OnlineTrackCandidate>,
            incoming: List<OnlineTrackCandidate>,
        ): List<OnlineTrackCandidate> {
            val seenStreamUrls = existing.map { it.streamUrl }.toHashSet()
            val seenIds = existing.map { it.id }.toHashSet()
            val seenIdentity = existing.map {
                "${it.title.trim().lowercase()}|${it.artist.trim().lowercase()}|${it.isPreviewOnly}"
            }.toHashSet()

            val appended = mutableListOf<OnlineTrackCandidate>()
            for (item in incoming) {
                val identityKey = "${item.title.trim().lowercase()}|${item.artist.trim().lowercase()}|${item.isPreviewOnly}"
                if (seenStreamUrls.add(item.streamUrl) &&
                    seenIds.add(item.id) &&
                    seenIdentity.add(identityKey)
                ) {
                    appended.add(item)
                }
            }
            // Keep Full Tracks grouped before Preview-Only tracks across pages
            return (existing + appended).sortedBy { it.isPreviewOnly }
        }
    }
}
