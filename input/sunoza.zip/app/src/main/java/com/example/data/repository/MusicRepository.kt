package com.example.data.repository

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.local.ListeningEventEntity
import com.example.data.local.MediaStoreAudioScanner
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.SavedMixEntity
import com.example.data.local.SeedCatalog
import com.example.data.local.SongEntity
import com.example.data.local.SunozaDao
import com.example.data.remote.ArchiveOrgApi
import com.example.data.remote.AudiusApi
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.CuratedAuthorizedCatalog
import com.example.data.remote.ItunesSearchApi
import com.example.data.remote.OnlineHttpClientProvider
import com.example.data.remote.OnlineTrackCandidate
import com.example.data.remote.SourceValidationResult
import com.example.model.PlaylistWithSongs
import com.example.model.SavedMix
import com.example.model.Song
import com.example.model.SongColorGenerator
import com.example.model.SourceType
import com.example.model.TransitionFilterType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.net.URLEncoder

data class OnlineSearchOutcome(
    val tracks: List<OnlineTrackCandidate>,
    val errorMessage: String? = null,
    val isOffline: Boolean = false,
)

class MusicRepository(
    private val context: Context,
    private val dao: SunozaDao,
    private val archiveApi: ArchiveOrgApi,
    private val audiusApi: AudiusApi = AudiusApi.create(OnlineHttpClientProvider.sharedClient),
    private val itunesApi: ItunesSearchApi = ItunesSearchApi.create(OnlineHttpClientProvider.sharedClient),
) {
    private val mediaStoreScanner = MediaStoreAudioScanner(context, dao)

    val allSongs: Flow<List<Song>> = dao.observeAllSongs().map { list ->
        list.map { it.toDomain() }
    }

    val favoriteSongs: Flow<List<Song>> = dao.observeFavoriteSongs().map { list ->
        list.map { it.toDomain() }
    }

    val recentlyPlayedSongs: Flow<List<Song>> = dao.observeRecentlyPlayedSongs().map { list ->
        list.map { it.toDomain() }
    }

    val recentListeningEvents: Flow<List<ListeningEventEntity>> = dao.observeRecentListeningEvents()

    val savedMixes: Flow<List<SavedMix>> = dao.observeSavedMixes().map { list ->
        list.map { it.toDomain() }
    }

    val playlists: Flow<List<PlaylistWithSongs>> = combine(
        dao.observePlaylists(),
        dao.observePlaylistCrossRefs(),
        allSongs,
    ) { playlistEntities, crossRefs, songs ->
        val songById = songs.associateBy { it.id }
        val refsByPlaylist = crossRefs.groupBy { it.playlistId }
        playlistEntities.map { pl ->
            val orderedSongs = refsByPlaylist[pl.id]
                .orEmpty()
                .sortedWith(compareBy<PlaylistSongCrossRef> { it.position }.thenBy { it.addedAtMs })
                .mapNotNull { songById[it.songId] }
            PlaylistWithSongs(
                id = pl.id,
                name = pl.name,
                createdAtMs = pl.createdAtMs,
                songs = orderedSongs,
            )
        }
    }

    fun hasAudioPermission(): Boolean = mediaStoreScanner.hasAudioPermission()

    fun registerMediaStoreObserver(onLibraryChanged: () -> Unit) {
        mediaStoreScanner.registerObserver(onLibraryChanged)
    }

    fun unregisterMediaStoreObserver() {
        mediaStoreScanner.unregisterObserver()
    }

    suspend fun scanDeviceAudio(): Int = mediaStoreScanner.scanAndSync()

    fun isNetworkConnected(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        if (dao.getSongCount() == 0) {
            val seedSongs = SeedCatalog.buildSeedSongs(context)
            val insertedIds = dao.insertSongs(seedSongs)
            if (insertedIds.isNotEmpty()) {
                val chillId = dao.insertPlaylist(PlaylistEntity(name = "Midnight Chill"))
                val focusId = dao.insertPlaylist(PlaylistEntity(name = "Focus & Drift"))
                insertedIds.take(2).forEachIndexed { idx, songId ->
                    dao.addSongToPlaylist(
                        PlaylistSongCrossRef(playlistId = chillId, songId = songId, position = idx)
                    )
                }
                insertedIds.drop(2).forEachIndexed { idx, songId ->
                    dao.addSongToPlaylist(
                        PlaylistSongCrossRef(playlistId = focusId, songId = songId, position = idx)
                    )
                }
            }
        }
    }

    suspend fun importOfflineAudioFiles(uris: List<Uri>): List<Long> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val importedIds = mutableListOf<Long>()
        var lastColor: Long? = null

        for (uri in uris) {
            runCatching {
                resolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }

            val uriStr = uri.toString()
            val existing = dao.getSongByUri(uriStr)
            if (existing != null) {
                importedIds.add(existing.id)
                continue
            }

            val meta = extractAudioMetadata(resolver, uri)
            val color = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = lastColor)
            lastColor = color

            val insertedId = dao.insertSong(
                SongEntity(
                    title = meta.title,
                    artist = meta.artist,
                    audioUri = uriStr,
                    durationMs = meta.durationMs,
                    backgroundColorArgb = color,
                    sourceType = SourceType.OFFLINE_LOCAL.name,
                    sourceLabel = "Offline Device File",
                    licenseName = "Local Storage",
                    isFavorite = false,
                    lyricsRaw = meta.lyrics,
                    addedAtMs = System.currentTimeMillis(),
                    album = meta.album,
                    folderName = "Imported Files",
                    genre = meta.genre,
                    bpm = 104,
                    energyScore = 0.62f,
                    mood = "Balanced",
                )
            )
            importedIds.add(insertedId)
        }
        importedIds
    }

    suspend fun searchAuthorizedOnlineTracks(query: String): OnlineSearchOutcome =
        withContext(Dispatchers.IO) {
            val cleanQuery = query.trim()
            val curatedMatches = CuratedAuthorizedCatalog.featuredTracks.filter { candidate ->
                cleanQuery.isEmpty() ||
                    candidate.title.contains(cleanQuery, ignoreCase = true) ||
                    candidate.artist.contains(cleanQuery, ignoreCase = true) ||
                    candidate.album.contains(cleanQuery, ignoreCase = true) ||
                    candidate.genre.contains(cleanQuery, ignoreCase = true) ||
                    candidate.providerName.contains(cleanQuery, ignoreCase = true)
            }

            if (!isNetworkConnected()) {
                return@withContext OnlineSearchOutcome(
                    tracks = emptyList(),
                    errorMessage = "No internet connection. Connect to Wi-Fi or mobile data and tap Retry to browse and stream online music.",
                    isOffline = true,
                )
            }

            var audiusError: Throwable? = null
            var itunesError: Throwable? = null
            var archiveError: Throwable? = null

            val (audiusTracks, itunesTracks, archiveTracks) = coroutineScope {
                val audiusDeferred = async {
                    runCatching {
                        val res = if (cleanQuery.isEmpty()) {
                            audiusApi.getTrendingTracks(limit = 16)
                        } else {
                            audiusApi.searchTracks(query = cleanQuery, limit = 16)
                        }
                        res.data.mapNotNull { dto ->
                            val trackId = dto.id?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                            val title = dto.title?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
                            if (dto.isStreamable == false || dto.streamConditions != null) {
                                return@mapNotNull null
                            }
                            val streamUrl = "https://api.audius.co/v1/tracks/$trackId/stream?app_name=SUNOZA"
                            when (val check = AuthorizedSourceValidator.validateUrl(streamUrl, "Artist Authorized Stream")) {
                                is SourceValidationResult.Authorized -> OnlineTrackCandidate(
                                    id = "audius-$trackId",
                                    title = title,
                                    artist = dto.user?.name?.takeIf { it.isNotBlank() }
                                        ?: dto.user?.handle
                                        ?: "Audius Artist",
                                    album = dto.genre?.takeIf { it.isNotBlank() } ?: "Audius Trending",
                                    artworkUrl = dto.artwork?.bestUrl(),
                                    genre = dto.genre?.takeIf { it.isNotBlank() } ?: "Electronic",
                                    streamUrl = check.normalizedUrl,
                                    durationMs = ((dto.duration ?: 180) * 1_000L).coerceAtLeast(10_000L),
                                    providerName = check.providerName,
                                    licenseName = check.licenseName,
                                    isPreviewOnly = false,
                                )
                                is SourceValidationResult.Rejected -> null
                            }
                        }
                    }.onFailure { audiusError = it }.getOrElse { emptyList() }
                }

                val itunesDeferred = async {
                    runCatching {
                        val term = cleanQuery.ifEmpty { "electronic synthwave" }
                        val res = itunesApi.searchSongs(term = term, limit = 16)
                        res.results.mapNotNull { dto ->
                            val preview = dto.previewUrl?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                            val title = dto.trackName?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                            when (val check = AuthorizedSourceValidator.validateUrl(preview, "Official 30s Preview")) {
                                is SourceValidationResult.Authorized -> OnlineTrackCandidate(
                                    id = "itunes-${dto.trackId ?: title.hashCode()}",
                                    title = title,
                                    artist = dto.artistName?.takeIf { it.isNotBlank() } ?: "Unknown Artist",
                                    album = dto.collectionName?.takeIf { it.isNotBlank() } ?: "Single",
                                    artworkUrl = dto.highResArtworkUrl(),
                                    genre = dto.primaryGenreName?.takeIf { it.isNotBlank() } ?: "Music",
                                    streamUrl = check.normalizedUrl,
                                    durationMs = 30_000L,
                                    providerName = check.providerName,
                                    licenseName = "Official 30s Preview",
                                    isPreviewOnly = true,
                                )
                                is SourceValidationResult.Rejected -> null
                            }
                        }
                    }.onFailure { itunesError = it }.getOrElse { emptyList() }
                }

                val archiveDeferred = async {
                    if (cleanQuery.isEmpty()) {
                        emptyList()
                    } else {
                        runCatching {
                            val luceneQuery =
                                "mediatype:audio AND (licenseurl:*creativecommons* OR licenseurl:*publicdomain*) AND ($cleanQuery)"
                            val searchRes = archiveApi.searchAudio(query = luceneQuery, rows = 5)
                            val docs = searchRes.response?.docs.orEmpty().take(3)
                            docs.mapNotNull { doc ->
                                val identifier = doc.identifier?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                                runCatching {
                                    val meta = archiveApi.getItemMetadata(identifier)
                                    val mp3File = meta.files.firstOrNull { file ->
                                        val name = file.name?.lowercase().orEmpty()
                                        (name.endsWith(".mp3") || name.endsWith(".ogg") || name.endsWith(".m4a")) &&
                                            !name.contains("_64kb")
                                    } ?: return@runCatching null

                                    val encodedName = URLEncoder.encode(mp3File.name, "UTF-8").replace("+", "%20")
                                    val streamUrl = "https://archive.org/download/$identifier/$encodedName"
                                    when (val validation = AuthorizedSourceValidator.validateUrl(streamUrl, doc.licenseUrl)) {
                                        is SourceValidationResult.Authorized -> {
                                            val durationSec = mp3File.length?.toDoubleOrNull() ?: 180.0
                                            OnlineTrackCandidate(
                                                id = "ia-$identifier-${mp3File.name}",
                                                title = (mp3File.title ?: doc.title ?: identifier).take(80),
                                                artist = doc.creatorText().take(60),
                                                album = "Internet Archive CC",
                                                artworkUrl = "https://archive.org/services/img/$identifier",
                                                genre = "Creative Commons",
                                                streamUrl = validation.normalizedUrl,
                                                durationMs = (durationSec * 1_000L).toLong().coerceAtLeast(15_000L),
                                                providerName = validation.providerName,
                                                licenseName = validation.licenseName,
                                                isPreviewOnly = false,
                                            )
                                        }
                                        is SourceValidationResult.Rejected -> null
                                    }
                                }.getOrNull()
                            }
                        }.onFailure { archiveError = it }.getOrElse { emptyList() }
                    }
                }

                Triple(audiusDeferred.await(), itunesDeferred.await(), archiveDeferred.await())
            }

            val remoteCombined = (audiusTracks + itunesTracks + archiveTracks).distinctBy { it.streamUrl }
            val allCombined = (remoteCombined + curatedMatches).distinctBy { it.streamUrl }

            if (remoteCombined.isEmpty() && (audiusError != null || itunesError != null || archiveError != null)) {
                val primaryErr = audiusError ?: itunesError ?: archiveError
                val reason = primaryErr?.localizedMessage?.take(120) ?: "Connection timed out"
                return@withContext OnlineSearchOutcome(
                    tracks = curatedMatches,
                    errorMessage = "Online catalog servers unavailable ($reason). Tap Retry when connected.",
                    isOffline = false,
                )
            }

            OnlineSearchOutcome(
                tracks = allCombined,
                errorMessage = null,
                isOffline = false,
            )
        }

    suspend fun addAuthorizedOnlineCandidate(candidate: OnlineTrackCandidate): Result<Song> =
        withContext(Dispatchers.IO) {
            when (val validation = AuthorizedSourceValidator.validateUrl(candidate.streamUrl, candidate.licenseName)) {
                is SourceValidationResult.Rejected -> {
                    Result.failure(IllegalArgumentException(validation.reason))
                }
                is SourceValidationResult.Authorized -> {
                    val resolvedAlbum = candidate.album.ifBlank { validation.providerName }
                    val resolvedGenre = candidate.genre.ifBlank { "Creative Commons" }
                    val existing = dao.getSongByUri(validation.normalizedUrl)
                    if (existing != null) {
                        if (existing.artworkUri.isNullOrBlank() && !candidate.artworkUrl.isNullOrBlank()) {
                            dao.updateSongMetadata(
                                songId = existing.id,
                                artworkUri = candidate.artworkUrl,
                                album = resolvedAlbum,
                                genre = resolvedGenre,
                            )
                            return@withContext Result.success(
                                existing.copy(
                                    artworkUri = candidate.artworkUrl,
                                    album = resolvedAlbum,
                                    genre = resolvedGenre,
                                ).toDomain()
                            )
                        }
                        return@withContext Result.success(existing.toDomain())
                    }
                    val entity = SongEntity(
                        title = candidate.title.ifBlank { "Authorized Track" },
                        artist = candidate.artist.ifBlank { "Creative Commons Artist" },
                        audioUri = validation.normalizedUrl,
                        durationMs = candidate.durationMs,
                        backgroundColorArgb = SongColorGenerator.nextSolidColorArgb(),
                        sourceType = SourceType.AUTHORIZED_ONLINE.name,
                        sourceLabel = validation.providerName,
                        licenseName = candidate.licenseName.ifBlank { validation.licenseName },
                        isFavorite = false,
                        lyricsRaw = candidate.lyricsRaw,
                        addedAtMs = System.currentTimeMillis(),
                        album = resolvedAlbum,
                        artworkUri = candidate.artworkUrl,
                        folderName = "Online Streams",
                        genre = resolvedGenre,
                        bpm = 112,
                        energyScore = 0.70f,
                        mood = if (candidate.isPreviewOnly) "Preview" else "Streaming",
                    )
                    val id = dao.insertSong(entity)
                    Result.success(entity.copy(id = id).toDomain())
                }
            }
        }

    suspend fun addAuthorizedStreamByUrl(
        rawUrl: String,
        title: String,
        artist: String,
    ): Result<Song> = withContext(Dispatchers.IO) {
        when (val validation = AuthorizedSourceValidator.validateUrl(rawUrl)) {
            is SourceValidationResult.Rejected -> {
                Result.failure(IllegalArgumentException(validation.reason))
            }
            is SourceValidationResult.Authorized -> {
                val existing = dao.getSongByUri(validation.normalizedUrl)
                if (existing != null) {
                    return@withContext Result.success(existing.toDomain())
                }
                val fallbackTitle = Uri.parse(validation.normalizedUrl)
                    .lastPathSegment
                    ?.substringBeforeLast('.')
                    ?.replace('_', ' ')
                    ?.replace('-', ' ')
                    ?.ifBlank { "Authorized Stream" }
                    ?: "Authorized Stream"

                val entity = SongEntity(
                    title = title.trim().ifBlank { fallbackTitle },
                    artist = artist.trim().ifBlank { validation.providerName },
                    audioUri = validation.normalizedUrl,
                    durationMs = 180_000L,
                    backgroundColorArgb = SongColorGenerator.nextSolidColorArgb(),
                    sourceType = SourceType.AUTHORIZED_ONLINE.name,
                    sourceLabel = validation.providerName,
                    licenseName = validation.licenseName,
                    isFavorite = false,
                    lyricsRaw = "",
                    addedAtMs = System.currentTimeMillis(),
                    album = validation.providerName,
                    folderName = "Online Streams",
                    genre = "Creative Commons",
                    bpm = 108,
                    energyScore = 0.65f,
                    mood = "Discovery",
                )
                val id = dao.insertSong(entity)
                Result.success(entity.copy(id = id).toDomain())
            }
        }
    }

    suspend fun recordSongPlayed(song: Song) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        dao.recordSongPlay(song.id, now)
        dao.insertListeningEvent(
            ListeningEventEntity(
                songId = song.id,
                playedAtMs = now,
                sourceType = song.sourceType.name,
            )
        )
    }

    suspend fun updateSongAnalysis(songId: Long, bpm: Int, energyScore: Float) =
        withContext(Dispatchers.IO) {
            dao.updateAudioAnalysis(songId, bpm, energyScore)
        }

    suspend fun toggleFavorite(songId: Long, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        dao.setFavorite(songId, isFavorite)
    }

    suspend fun updateLyrics(songId: Long, lyricsRaw: String) = withContext(Dispatchers.IO) {
        dao.updateLyrics(songId, lyricsRaw.trim())
    }

    suspend fun randomizeSongColor(songId: Long, currentColorArgb: Long) = withContext(Dispatchers.IO) {
        val next = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = currentColorArgb)
        dao.updateBackgroundColor(songId, next)
    }

    suspend fun deleteSong(songId: Long) = withContext(Dispatchers.IO) {
        dao.deleteSongById(songId)
    }

    suspend fun createPlaylist(name: String): Long = withContext(Dispatchers.IO) {
        dao.insertPlaylist(PlaylistEntity(name = name.trim()))
    }

    suspend fun renamePlaylist(playlistId: Long, name: String) = withContext(Dispatchers.IO) {
        dao.renamePlaylist(playlistId, name.trim())
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        dao.deletePlaylist(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        val nextPos = dao.getMaxPlaylistPosition(playlistId) + 1
        dao.addSongToPlaylist(
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = songId,
                position = nextPos,
            )
        )
    }

    suspend fun reorderPlaylistSongs(playlistId: Long, orderedSongIds: List<Long>) =
        withContext(Dispatchers.IO) {
            dao.updatePlaylistOrder(playlistId, orderedSongIds)
        }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        dao.removeSongFromPlaylist(playlistId, songId)
    }

    suspend fun saveMixPreset(
        name: String,
        deckASongId: Long,
        deckBSongId: Long,
        crossfader: Float,
        transitionDurationSec: Int,
        filterType: TransitionFilterType,
        echoAmount: Float,
        autoMixEnabled: Boolean,
    ): Long = withContext(Dispatchers.IO) {
        dao.insertSavedMix(
            SavedMixEntity(
                name = name.trim().ifBlank { "Sunoza Mix" },
                deckASongId = deckASongId,
                deckBSongId = deckBSongId,
                crossfader = crossfader,
                transitionDurationSec = transitionDurationSec,
                filterType = filterType.name,
                echoAmount = echoAmount,
                autoMixEnabled = autoMixEnabled,
            )
        )
    }

    suspend fun deleteSavedMix(mixId: Long) = withContext(Dispatchers.IO) {
        dao.deleteSavedMix(mixId)
    }

    private data class ExtractedAudioMeta(
        val title: String,
        val artist: String,
        val album: String,
        val genre: String,
        val durationMs: Long,
        val lyrics: String,
    )

    private fun extractAudioMetadata(resolver: ContentResolver, uri: Uri): ExtractedAudioMeta {
        val displayName = queryDisplayName(resolver, uri)
            ?.substringBeforeLast('.')
            ?.trim()
            .orEmpty()

        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val embeddedTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim()
            val embeddedArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim()
            val embeddedAlbum = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.trim()
            val embeddedGenre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)?.trim()
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?.coerceAtLeast(1_000L)
                ?: 180_000L

            val (parsedArtist, parsedTitle) = if (displayName.contains(" - ")) {
                val parts = displayName.split(" - ", limit = 2)
                parts[0].trim() to parts[1].trim()
            } else {
                "" to displayName
            }

            ExtractedAudioMeta(
                title = embeddedTitle?.takeIf { it.isNotEmpty() }
                    ?: parsedTitle.ifEmpty { "Local Audio Track" },
                artist = embeddedArtist?.takeIf { it.isNotEmpty() }
                    ?: parsedArtist.ifEmpty { "Offline Artist" },
                album = embeddedAlbum?.takeIf { it.isNotEmpty() } ?: "Single",
                genre = embeddedGenre?.takeIf { it.isNotEmpty() } ?: "Local Audio",
                durationMs = durationMs,
                lyrics = "",
            )
        } catch (_: Exception) {
            ExtractedAudioMeta(
                title = displayName.ifEmpty { "Local Audio Track" },
                artist = "Offline Artist",
                album = "Single",
                genre = "Local Audio",
                durationMs = 180_000L,
                lyrics = "",
            )
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        return resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else {
                null
            }
        }
    }
}
