package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SunozaObsidian = Color(0xFF0A0A0F)
val SunozaSurface = Color(0xFF12121A)
val SunozaSurfaceElevated = Color(0xFF1B1B26)
val SunozaCardHighlight = Color(0xFF232332)
val SunozaPurple = Color(0xFF8B5CF6)
val SunozaPink = Color(0xFFEC4899)
val SunozaOrange = Color(0xFFFF6B35)
val SunozaCoral = Color(0xFFFF6B4A)
val SunozaOnCoral = Color(0xFF1A0905)
val SunozaIvory = Color(0xFFF6F6FA)
val SunozaMutedText = Color(0xFFA0A0B8)
val SunozaSubtleBorder = Color(0xFF2A2A3B)
val SunozaErrorRed = Color(0xFFFF6E6E)
val SunozaMint = Color(0xFF34D399)

val SunozaBrandColors = listOf(SunozaPurple, SunozaPink, SunozaOrange)
