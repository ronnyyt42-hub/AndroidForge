package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class ArchiveSearchResponse(
    val response: ArchiveSearchInner? = null,
)

@JsonClass(generateAdapter = true)
data class ArchiveSearchInner(
    val numFound: Int = 0,
    val docs: List<ArchiveDocDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ArchiveDocDto(
    val identifier: String? = null,
    val title: String? = null,
    val creator: Any? = null,
    @Json(name = "licenseurl") val licenseUrl: String? = null,
) {
    fun creatorText(): String = when (creator) {
        is String -> creator
        is List<*> -> creator.filterIsInstance<String>().joinToString(", ")
        else -> "Creative Commons Artist"
    }.ifBlank { "Creative Commons Artist" }
}

@JsonClass(generateAdapter = true)
data class ArchiveMetadataResponse(
    @Json(name = "is_dark") val isDark: Boolean? = null,
    val metadata: ArchiveItemMetadataDto? = null,
    val files: List<ArchiveFileDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ArchiveItemMetadataDto(
    val title: String? = null,
    val album: String? = null,
    val creator: Any? = null,
    val artist: String? = null,
    @Json(name = "licenseurl") val licenseUrl: String? = null,
)

@JsonClass(generateAdapter = true)
data class ArchiveFileDto(
    val name: String? = null,
    val format: String? = null,
    val title: String? = null,
    val length: String? = null,
    val private: Any? = null,
) {
    fun isPrivateFile(): Boolean = private == true || private?.toString()?.equals("true", ignoreCase = true) == true

    fun parseDurationMs(): Long? {
        val raw = length?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        raw.toDoubleOrNull()?.let { sec ->
            return if (sec > 0.0) (sec * 1_000.0).toLong() else null
        }
        val parts = raw.split(':').mapNotNull { it.toDoubleOrNull() }
        val totalSeconds = when (parts.size) {
            2 -> parts[0] * 60.0 + parts[1]
            3 -> parts[0] * 3600.0 + parts[1] * 60.0 + parts[2]
            else -> return null
        }
        return if (totalSeconds > 0.0) (totalSeconds * 1_000.0).toLong() else null
    }
}

interface ArchiveOrgApi {
    @GET("advancedsearch.php")
    suspend fun searchAudio(
        @Query("q") query: String,
        @Query("fl[]") fields: List<String> = listOf("identifier", "title", "creator", "licenseurl"),
        @Query("rows") rows: Int = 8,
        @Query("page") page: Int = 1,
        @Query("output") output: String = "json",
    ): ArchiveSearchResponse

    @GET("metadata/{identifier}")
    suspend fun getItemMetadata(
        @Path("identifier") identifier: String,
    ): ArchiveMetadataResponse

    companion object {
        fun create(client: OkHttpClient = OnlineHttpClientProvider.sharedClient): ArchiveOrgApi {
            return Retrofit.Builder()
                .baseUrl("https://archive.org/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(ArchiveOrgApi::class.java)
        }
    }
}
