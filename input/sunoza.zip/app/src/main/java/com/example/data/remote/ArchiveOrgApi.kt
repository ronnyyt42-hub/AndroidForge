package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class ArchiveSearchResponse(
    val response: ArchiveSearchInner? = null,
)

@JsonClass(generateAdapter = true)
data class ArchiveSearchInner(
    val docs: List<ArchiveDocDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ArchiveDocDto(
    val identifier: String? = null,
    val title: String? = null,
    val creator: Any? = null,
    @Json(name = "licenseurl") val licenseUrl: String? = null,
) {
    fun creatorText(): String = when (creator) {
        is String -> creator
        is List<*> -> creator.filterIsInstance<String>().joinToString(", ")
        else -> "Creative Commons Artist"
    }.ifBlank { "Creative Commons Artist" }
}

@JsonClass(generateAdapter = true)
data class ArchiveMetadataResponse(
    val files: List<ArchiveFileDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ArchiveFileDto(
    val name: String? = null,
    val format: String? = null,
    val title: String? = null,
    val length: String? = null,
)

interface ArchiveOrgApi {
    @GET("advancedsearch.php")
    suspend fun searchAudio(
        @Query("q") query: String,
        @Query("fl[]") fields: List<String> = listOf("identifier", "title", "creator", "licenseurl"),
        @Query("rows") rows: Int = 12,
        @Query("page") page: Int = 1,
        @Query("output") output: String = "json",
    ): ArchiveSearchResponse

    @GET("metadata/{identifier}")
    suspend fun getItemMetadata(
        @Path("identifier") identifier: String,
    ): ArchiveMetadataResponse

    companion object {
        fun create(): ArchiveOrgApi {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()

            return Retrofit.Builder()
                .baseUrl("https://archive.org/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(ArchiveOrgApi::class.java)
        }
    }
}
