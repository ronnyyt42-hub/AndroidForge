package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.PartyEnergyMode
import com.example.model.Song
import com.example.model.TransitionFilterType
import com.example.player.DeckState
import com.example.ui.SunozaUiState
import com.example.ui.SunozaViewModel
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated
import kotlin.math.roundToInt

enum class DjStudioMode(val label: String) {
    MIXFLOW("MixFlow Decks"),
    PARTYFLOW("PartyFlow Auto DJ"),
}

@Composable
fun MixAndPartyScreen(
    uiState: SunozaUiState,
    viewModel: SunozaViewModel,
    initialMode: DjStudioMode = DjStudioMode.MIXFLOW,
    modifier: Modifier = Modifier,
) {
    var mode by remember(initialMode) { mutableStateOf(initialMode) }
    var pickingDeck by remember { mutableIntStateOf(0) } // 1 = Deck A, 2 = Deck B, 3 = Party Starting, 4 = Party Add Queue
    var showSaveMixDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SunozaObsidian)
            .testTag("mix_party_screen"),
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            SunozaBrandHeader(
                title = if (mode == DjStudioMode.MIXFLOW) "Sunoza MixFlow" else "Sunoza PartyFlow",
                subtitle = if (mode == DjStudioMode.MIXFLOW) {
                    "Dual virtual decks · Beat sync & crossfade studio"
                } else {
                    "Smart Auto DJ · Continuous energy transitions"
                },
            )
        }

        // Mode Switcher
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SunozaSurfaceElevated)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                DjStudioMode.entries.forEach { tab ->
                    val selected = mode == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) SunozaPurple else Color.Transparent)
                            .clickable { mode = tab }
                            .padding(vertical = 11.dp)
                            .testTag("dj_mode_${tab.name.lowercase()}"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) SunozaIvory else SunozaMutedText,
                        )
                    }
                }
            }
        }

        if (mode == DjStudioMode.MIXFLOW) {
            val mix = uiState.mixFlow

            // Deck A
            item {
                DeckControlCard(
                    deckLabel = "DECK A",
                    accentColor = SunozaPurple,
                    deck = mix.deckA,
                    onPickSong = { pickingDeck = 1 },
                    onTogglePlayPause = viewModel::toggleDeckAPlayPause,
                    onSeek = viewModel::seekDeckA,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .testTag("mix_deck_a"),
                )
            }

            // Crossfader + Live Transition Controls
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(20.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "Crossfader",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SunozaIvory,
                        )
                        val aPct = ((1f - mix.crossfader) * 100).roundToInt()
                        val bPct = (mix.crossfader * 100).roundToInt()
                        Text(
                            text = "A $aPct%  ·  B $bPct%",
                            style = MaterialTheme.typography.labelLarge,
                            color = SunozaOrange,
                        )
                    }

                    Slider(
                        value = mix.crossfader,
                        onValueChange = viewModel::setMixCrossfader,
                        colors = SliderDefaults.colors(
                            thumbColor = SunozaIvory,
                            activeTrackColor = SunozaPink,
                            inactiveTrackColor = SunozaPurple.copy(alpha = 0.4f),
                        ),
                        modifier = Modifier.testTag("mix_crossfader_slider"),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = viewModel::startMixPreview,
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaSurface),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mix_preview_button"),
                        ) {
                            Icon(Icons.Filled.GraphicEq, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Preview 50/50")
                        }

                        Button(
                            onClick = viewModel::triggerMixTransition,
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaPink),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mix_transition_now_button"),
                        ) {
                            Icon(Icons.Filled.FastForward, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (mix.isTransitioning) "Mixing…" else "Transition")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilledTonalButton(
                            onClick = viewModel::toggleBeatSync,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (mix.beatSyncEnabled) SunozaMint.copy(alpha = 0.2f) else SunozaSurface,
                                contentColor = if (mix.beatSyncEnabled) SunozaMint else SunozaIvory,
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mix_beat_sync_button"),
                        ) {
                            Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (mix.beatSyncEnabled) "Beat Sync ON" else "Beat Sync")
                        }

                        FilledTonalButton(
                            onClick = viewModel::blendCurrentAndNextInMixFlow,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = SunozaSurface,
                                contentColor = SunozaIvory,
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mix_blend_current_next_button"),
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Load Now+Next")
                        }
                    }

                    if (!mix.statusNote.isNullOrBlank()) {
                        Text(
                            text = mix.statusNote,
                            style = MaterialTheme.typography.labelMedium,
                            color = SunozaMint,
                        )
                    }
                }
            }

            // Deck B
            item {
                DeckControlCard(
                    deckLabel = "DECK B",
                    accentColor = SunozaOrange,
                    deck = mix.deckB,
                    onPickSong = { pickingDeck = 2 },
                    onTogglePlayPause = viewModel::toggleDeckBPlayPause,
                    onSeek = viewModel::seekDeckB,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .testTag("mix_deck_b"),
                )
            }

            // Filter, Echo, Transition Duration & Auto Mix Settings
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(20.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = "Transition DSP & Auto Mix",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(TransitionFilterType.entries, key = { it.name }) { filter ->
                            FilterChip(
                                selected = mix.filterType == filter,
                                onClick = { viewModel.setMixFilterType(filter) },
                                label = { Text(filter.label) },
                            )
                        }
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text("Transition Duration", color = SunozaIvory, style = MaterialTheme.typography.bodyMedium)
                            Text("${mix.transitionDurationSec}s", color = SunozaPink, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = mix.transitionDurationSec.toFloat(),
                            onValueChange = { viewModel.setMixTransitionDuration(it.roundToInt()) },
                            valueRange = 2f..16f,
                        )
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text("Echo Tail Blend", color = SunozaIvory, style = MaterialTheme.typography.bodyMedium)
                            Text("${(mix.echoAmount * 100).roundToInt()}%", color = SunozaOrange, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = mix.echoAmount,
                            onValueChange = viewModel::setMixEchoAmount,
                            valueRange = 0f..1f,
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Mix at Track Ending", color = SunozaIvory, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                text = "Automatically crossfade into the opposite deck near track outro",
                                color = SunozaMutedText,
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                        Switch(
                            checked = mix.autoMixEnabled,
                            onCheckedChange = viewModel::setAutoMixEnabled,
                            modifier = Modifier.testTag("mix_automix_switch"),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = { showSaveMixDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaPurple),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_mix_button"),
                        ) {
                            Icon(Icons.Filled.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Mix")
                        }
                        FilledTonalButton(
                            onClick = {
                                val title = listOfNotNull(mix.deckA.song?.title, mix.deckB.song?.title)
                                    .joinToString(" × ")
                                    .ifBlank { "MixFlow Set" }
                                viewModel.saveMixAsPlaylist(title)
                            },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Filled.PlaylistAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("To Playlist")
                        }
                    }

                    Text(
                        text = "MixFlow plays real-time blends on authorized Creative Commons streams and your local library. No DRM circumvention or unauthorized audio export.",
                        style = MaterialTheme.typography.labelSmall,
                        color = SunozaMutedText,
                    )
                }
            }
        } else {
            // PARTYFLOW SMART AUTO DJ
            val party = uiState.partyFlow
            val currentSong = uiState.currentSong

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaOrange.copy(alpha = 0.45f), RoundedCornerShape(22.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (party.isActive) "PARTYFLOW LIVE" else "START PARTYFLOW",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (party.isActive) SunozaMint else SunozaOrange,
                            )
                            Text(
                                text = currentSong?.title ?: "Choose a starting song",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = SunozaIvory,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = if (currentSong != null) {
                                    "${currentSong.genre} · ${currentSong.mood} · ${currentSong.bpm} BPM"
                                } else {
                                    "Analyzes tempo, mood & energy"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = SunozaMutedText,
                            )
                        }

                        if (currentSong != null) {
                            SongArtwork(song = currentSong, size = 56.dp, cornerRadius = 14.dp)
                        }
                    }

                    Text(
                        text = party.smartSkipStatus,
                        style = MaterialTheme.typography.labelMedium,
                        color = SunozaMint,
                    )

                    // Energy Modes
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        PartyEnergyMode.entries.forEach { energy ->
                            val selected = party.energyMode == energy
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (selected) SunozaOrange else SunozaSurface)
                                    .clickable { viewModel.setPartyEnergyMode(energy) }
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .testTag("party_energy_${energy.name.lowercase()}"),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    text = energy.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected) SunozaObsidian else SunozaIvory,
                                )
                                Text(
                                    text = "${energy.minBpm}-${energy.maxBpm}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) SunozaObsidian.copy(alpha = 0.8f) else SunozaMutedText,
                                )
                            }
                        }
                    }

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = { pickingDeck = 3 },
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaPurple),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("party_pick_start_button"),
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (party.isActive) "New Starter" else "Select & Start")
                        }

                        Button(
                            onClick = viewModel::keepVibeAlive,
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaPink),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("party_keep_vibe_alive_button"),
                        ) {
                            Icon(Icons.Filled.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Keep Vibe Alive")
                        }
                    }

                    if (party.isActive) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            FilledTonalButton(
                                onClick = viewModel::togglePlayPause,
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(
                                    imageVector = if (uiState.playback.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (uiState.playback.isPlaying) "Pause" else "Resume")
                            }
                            FilledTonalButton(
                                onClick = viewModel::nextSong,
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(Icons.Filled.SkipNext, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Skip")
                            }
                            FilledTonalButton(
                                onClick = viewModel::stopPartyFlow,
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Stop")
                            }
                        }
                    }
                }
            }

            // PartyFlow Toggles & Crossfade
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(20.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto DJ Transitions", color = SunozaIvory, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text("Blend songs automatically before track ends", color = SunozaMutedText, style = MaterialTheme.typography.labelMedium)
                        }
                        Switch(
                            checked = party.autoDjEnabled,
                            onCheckedChange = { viewModel.togglePartyAutoDj() },
                            modifier = Modifier.testTag("party_autodj_switch"),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Smart Skip (Intro / Outro)", color = SunozaIvory, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Skips quiet intros/outros only when local energy analysis is reliable",
                                color = SunozaMutedText,
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                        Switch(
                            checked = party.smartSkipEnabled,
                            onCheckedChange = { viewModel.togglePartySmartSkip() },
                            modifier = Modifier.testTag("party_smartskip_switch"),
                        )
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text("Party Crossfade", color = SunozaIvory, style = MaterialTheme.typography.bodyMedium)
                            Text("${party.crossfadeSec}s", color = SunozaOrange, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = party.crossfadeSec.toFloat(),
                            onValueChange = { viewModel.setPartyCrossfade(it.roundToInt()) },
                            valueRange = 2f..12f,
                        )
                    }
                }
            }

            // Upcoming Queue Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(
                            text = "Upcoming Party Queue",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = SunozaIvory,
                        )
                        Text(
                            text = "${party.queue.size} curated tracks",
                            style = MaterialTheme.typography.labelMedium,
                            color = SunozaMutedText,
                        )
                    }
                    FilledTonalButton(
                        onClick = { pickingDeck = 4 },
                        modifier = Modifier.testTag("party_add_song_button"),
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Song")
                    }
                }
            }

            if (party.queue.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SunozaSurfaceElevated)
                            .padding(20.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "Tap Select & Start above to generate a tempo & energy matched party queue.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SunozaMutedText,
                        )
                    }
                }
            } else {
                items(party.queue, key = { "party_q_${it.id}" }) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SunozaSurfaceElevated)
                            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(14.dp))
                            .clickable { viewModel.playSongInCurrentOrAllQueue(song) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SongArtwork(song = song, size = 40.dp, cornerRadius = 10.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, color = SunozaIvory, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${song.artist} · ${song.bpm} BPM · ${song.genre}", style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
                        }
                        IconButton(
                            onClick = { viewModel.removeSongFromPartyQueue(song) },
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "Remove from queue", tint = SunozaMutedText)
                        }
                    }
                }
            }
        }
    }

    if (pickingDeck > 0) {
        SelectSongForDeckDialog(
            title = when (pickingDeck) {
                1 -> "Select Song for Deck A"
                2 -> "Select Song for Deck B"
                3 -> "Select Starting Track for PartyFlow"
                else -> "Add Song to Party Queue"
            },
            songs = uiState.allSongs,
            onDismiss = { pickingDeck = 0 },
            onSelectSong = { song ->
                when (pickingDeck) {
                    1 -> viewModel.loadMixDeckA(song)
                    2 -> viewModel.loadMixDeckB(song)
                    3 -> viewModel.startPartyFlow(song)
                    else -> viewModel.addSongToPartyQueue(song)
                }
                pickingDeck = 0
            },
        )
    }

    if (showSaveMixDialog) {
        SaveMixDialog(
            defaultName = listOfNotNull(uiState.mixFlow.deckA.song?.title, uiState.mixFlow.deckB.song?.title)
                .joinToString(" × ")
                .ifBlank { "Sunoza Blend" },
            onDismiss = { showSaveMixDialog = false },
            onSave = { name ->
                viewModel.saveCurrentMix(name)
                showSaveMixDialog = false
            },
        )
    }
}

@Composable
private fun DeckControlCard(
    deckLabel: String,
    accentColor: Color,
    deck: DeckState,
    onPickSong: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val song = deck.song
    val waveform = deck.analysis?.waveform?.takeIf { it.isNotEmpty() }
        ?: remember(song?.id) {
            List(48) { idx -> 0.25f + 0.65f * kotlin.math.abs(kotlin.math.sin((idx + (song?.id ?: 1L)) * 0.45f)) }
        }
    val safeDuration = deck.durationMs.takeIf { it > 0L } ?: song?.durationMs ?: 1_000L
    val progress = (deck.positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val bpm = deck.analysis?.bpm ?: song?.bpm ?: 100

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(SunozaSurfaceElevated)
            .border(1.dp, accentColor.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                ) {
                    Text(deckLabel, color = accentColor, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$bpm BPM" + if (deck.playbackSpeed != 1f) " (${String.format("%.2fx", deck.playbackSpeed)})" else "",
                    style = MaterialTheme.typography.labelMedium,
                    color = SunozaMint,
                )
            }

            FilledTonalButton(
                onClick = onPickSong,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = SunozaSurface,
                    contentColor = SunozaIvory,
                ),
            ) {
                Text(if (song == null) "Load Song" else "Change")
            }
        }

        if (song != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SongArtwork(song = song, size = 46.dp, cornerRadius = 12.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(song.title, color = SunozaIvory, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = SunozaMutedText, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(
                    onClick = onTogglePlayPause,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(accentColor),
                ) {
                    Icon(
                        imageVector = if (deck.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (deck.isPlaying) "Pause $deckLabel" else "Play $deckLabel",
                        tint = SunozaObsidian,
                    )
                }
            }

            // Interactive Waveform Visualization
            WaveformCanvas(
                bars = waveform,
                progress = progress,
                activeColor = accentColor,
                inactiveColor = SunozaSubtleBorder,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
            )

            Slider(
                value = progress,
                onValueChange = { frac -> onSeek((frac * safeDuration).toLong()) },
                colors = SliderDefaults.colors(
                    thumbColor = accentColor,
                    activeTrackColor = accentColor,
                    inactiveTrackColor = SunozaSurface,
                ),
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(formatDuration(deck.positionMs), style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
                Text(formatDuration(safeDuration), style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
            }
        } else {
            Text(
                text = "Tap Load Song to assign a track to $deckLabel.",
                style = MaterialTheme.typography.bodyMedium,
                color = SunozaMutedText,
            )
        }
    }
}

@Composable
private fun WaveformCanvas(
    bars: List<Float>,
    progress: Float,
    activeColor: Color,
    inactiveColor: Color,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        if (bars.isEmpty()) return@Canvas
        val count = bars.size
        val stepX = size.width / count.toFloat()
        val barWidth = (stepX * 0.62f).coerceAtLeast(2f)
        val centerY = size.height / 2f

        bars.forEachIndexed { index, amp ->
            val fraction = index.toFloat() / count.toFloat()
            val barColor = if (fraction <= progress) activeColor else inactiveColor
            val barH = (amp.coerceIn(0.12f, 1f) * size.height * 0.9f)
            val left = index * stepX + (stepX - barWidth) / 2f
            drawRoundRect(
                color = barColor,
                topLeft = Offset(left, centerY - barH / 2f),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}
