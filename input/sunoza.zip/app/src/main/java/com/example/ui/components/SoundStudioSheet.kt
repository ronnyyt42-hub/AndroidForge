package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.EqPreset
import com.example.model.ReverbOption
import com.example.model.SoundStudioState
import com.example.model.TenBandLabels
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundStudioSheet(
    state: SoundStudioState,
    onDismiss: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectPreset: (EqPreset) -> Unit,
    onUpdateBand: (Int, Float) -> Unit,
    onUpdateBassBoost: (Int) -> Unit,
    onUpdateTreble: (Float) -> Unit,
    onUpdateVirtualizer: (Int) -> Unit,
    onUpdateReverb: (ReverbOption) -> Unit,
    onUpdateLoudness: (Int) -> Unit,
    onReset: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SunozaSurface,
        contentColor = SunozaIvory,
        modifier = Modifier.testTag("sound_studio_sheet"),
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.90f)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Sunoza Sound Studio",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = SunozaIvory,
                        )
                        Text(
                            text = if (state.effectsAttached) {
                                "Live DSP active · ${state.hardwareBandCount}-band hardware mapping"
                            } else {
                                "Start playback to engage live audio DSP session"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (state.effectsAttached) SunozaMint else SunozaMutedText,
                        )
                    }
                    TextButton(
                        onClick = onReset,
                        modifier = Modifier.testTag("sound_studio_reset_button"),
                    ) {
                        Icon(Icons.Filled.RestartAlt, contentDescription = null, tint = SunozaOrange)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset", color = SunozaOrange)
                    }
                    Switch(
                        checked = state.isEnabled,
                        onCheckedChange = onToggleEnabled,
                        modifier = Modifier.testTag("sound_studio_enable_switch"),
                    )
                }
            }

            // Presets
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "EQ Presets",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(EqPreset.entries, key = { it.name }) { preset ->
                            FilterChip(
                                selected = state.activePresetName == preset.label,
                                onClick = { onSelectPreset(preset) },
                                label = { Text(preset.label) },
                                modifier = Modifier.testTag("eq_preset_${preset.name.lowercase()}"),
                            )
                        }
                    }
                }
            }

            // 10-Band Equalizer
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = "10-Band Equalizer (-12 to +12 dB)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    TenBandLabels.forEachIndexed { index, label ->
                        val db = state.bandsDb.getOrElse(index) { 0f }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "${label}Hz",
                                style = MaterialTheme.typography.labelSmall,
                                color = SunozaMutedText,
                                modifier = Modifier.width(44.dp),
                            )
                            Slider(
                                value = db,
                                onValueChange = { onUpdateBand(index, it) },
                                valueRange = -12f..12f,
                                enabled = state.isEnabled,
                                colors = SliderDefaults.colors(
                                    thumbColor = SunozaPurple,
                                    activeTrackColor = SunozaPink,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("eq_band_slider_$index"),
                            )
                            Text(
                                text = String.format("%+.1f", db),
                                style = MaterialTheme.typography.labelSmall,
                                color = SunozaIvory,
                                modifier = Modifier.width(42.dp),
                            )
                        }
                    }
                }
            }

            // Bass Boost, Treble, Virtualizer, Loudness Enhancer
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = "Dynamics & Enhancement",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )

                    StudioSliderRow(
                        label = "Bass Boost",
                        valueLabel = "${state.bassBoost / 10}%",
                        value = state.bassBoost.toFloat(),
                        range = 0f..1000f,
                        enabled = state.isEnabled,
                        onValueChange = { onUpdateBassBoost(it.roundToInt()) },
                    )

                    StudioSliderRow(
                        label = "Treble Control",
                        valueLabel = String.format("%+.1f dB", state.trebleBoost),
                        value = state.trebleBoost,
                        range = -6f..12f,
                        enabled = state.isEnabled,
                        onValueChange = onUpdateTreble,
                    )

                    StudioSliderRow(
                        label = "3D Virtualizer",
                        valueLabel = "${state.virtualizer / 10}%",
                        value = state.virtualizer.toFloat(),
                        range = 0f..1000f,
                        enabled = state.isEnabled,
                        onValueChange = { onUpdateVirtualizer(it.roundToInt()) },
                    )

                    StudioSliderRow(
                        label = "Sound Enhancement",
                        valueLabel = "+${state.loudnessGainMb} mB",
                        value = state.loudnessGainMb.toFloat(),
                        range = 0f..900f,
                        enabled = state.isEnabled,
                        onValueChange = { onUpdateLoudness(it.roundToInt()) },
                    )
                }
            }

            // Reverb Selector
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = "Spatial Reverb",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ReverbOption.entries, key = { it.name }) { option ->
                            FilterChip(
                                selected = state.reverb == option,
                                onClick = { onUpdateReverb(option) },
                                label = { Text(option.label) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioSliderRow(
    label: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    onValueChange: (Float) -> Unit,
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = SunozaIvory)
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = SunozaOrange, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = SunozaIvory,
                activeTrackColor = SunozaOrange,
            ),
        )
    }
}
