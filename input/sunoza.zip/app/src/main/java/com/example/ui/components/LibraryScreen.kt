package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.PlaylistWithSongs
import com.example.model.Song
import com.example.model.SourceType
import com.example.ui.SunozaUiState
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated

enum class LibraryCategory(val label: String) {
    ALL("All Songs"),
    RECENT("Recent"),
    FAVORITES("Favorites"),
    ALBUMS("Albums"),
    ARTISTS("Artists"),
    FOLDERS("Folders"),
    PLAYLISTS("Playlists"),
}

@Composable
fun LibraryScreen(
    uiState: SunozaUiState,
    onSearchQueryChange: (String) -> Unit,
    onRequestAudioPermission: () -> Unit,
    onRescanMediaStore: () -> Unit,
    onImportOfflineAudio: () -> Unit,
    onPlaySong: (Song) -> Unit,
    onPlayCustomQueue: (List<Song>, Song?) -> Unit,
    onPlayFavorites: () -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onDeleteSong: (Song) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onPlayPlaylist: (PlaylistWithSongs, Song?, Boolean) -> Unit,
    onRemoveSongFromPlaylist: (PlaylistWithSongs, Long) -> Unit,
    onMovePlaylistSong: (PlaylistWithSongs, Int, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var selectedCategory by remember { mutableStateOf(LibraryCategory.ALL) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var playlistToRename by remember { mutableStateOf<PlaylistWithSongs?>(null) }

    val filteredSongs = uiState.searchResults
    val albums = remember(filteredSongs) {
        filteredSongs.groupBy { it.album.ifBlank { "Single / Unknown Album" } }.toList()
            .sortedByDescending { it.second.size }
    }
    val artists = remember(filteredSongs) {
        filteredSongs.groupBy { it.artist.ifBlank { "Unknown Artist" } }.toList()
            .sortedByDescending { it.second.size }
    }
    val folders = remember(filteredSongs) {
        filteredSongs.groupBy { it.folderName.ifBlank { "Sunoza Collection" } }.toList()
            .sortedByDescending { it.second.size }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SunozaObsidian)
            .testTag("library_screen"),
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SunozaBrandHeader(
                title = "Your Library",
                subtitle = "${uiState.allSongs.size} songs · ${uiState.playlists.size} playlists",
                trailingContent = {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = onRescanMediaStore,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("library_rescan_button"),
                        ) {
                            if (uiState.isScanningLibrary) {
                                CircularProgressIndicator(
                                    color = SunozaPurple,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(20.dp),
                                )
                            } else {
                                Icon(Icons.Filled.Refresh, contentDescription = "Scan device audio", tint = SunozaIvory)
                            }
                        }
                        IconButton(
                            onClick = onImportOfflineAudio,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("library_import_button"),
                        ) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = "Import audio files", tint = SunozaIvory)
                        }
                    }
                },
            )
        }

        // Automatic MediaStore permission card if not yet granted
        if (!uiState.hasAudioPermission) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(SunozaSurfaceElevated)
                        .border(1.dp, SunozaOrange.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                        .padding(16.dp),
                ) {
                    Text(
                        text = "Scan Device Offline Music Automatically",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Allow audio storage access to automatically load songs from internal storage & SD cards.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SunozaMutedText,
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onRequestAudioPermission,
                        colors = ButtonDefaults.buttonColors(containerColor = SunozaOrange, contentColor = SunozaObsidian),
                        modifier = Modifier.testTag("grant_audio_permission_button"),
                    ) {
                        Text("Allow Audio Scan", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Search box
        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search songs, artists, albums, lyrics…") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .testTag("library_search_input"),
            )
        }

        // Category pills
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(LibraryCategory.entries, key = { it.name }) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.label) },
                        modifier = Modifier.testTag("library_cat_${cat.name.lowercase()}"),
                    )
                }
            }
        }

        when (selectedCategory) {
            LibraryCategory.ALL -> {
                items(filteredSongs, key = { it.id }) { song ->
                    TrackRowItem(
                        song = song,
                        isCurrent = song.id == uiState.currentSong?.id,
                        onClick = { onPlaySong(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onAddToPlaylist = { onAddToPlaylist(song) },
                        onDelete = if (song.sourceType != SourceType.BUNDLED) { { onDeleteSong(song) } } else null,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            }

            LibraryCategory.RECENT -> {
                if (uiState.recentlyPlayedSongs.isEmpty()) {
                    item {
                        EmptySectionCard("No recently played tracks yet", "Play any song to start tracking history.")
                    }
                } else {
                    items(uiState.recentlyPlayedSongs, key = { "recent_${it.id}" }) { song ->
                        TrackRowItem(
                            song = song,
                            isCurrent = song.id == uiState.currentSong?.id,
                            onClick = { onPlaySong(song) },
                            onToggleFavorite = { onToggleFavorite(song) },
                            onAddToPlaylist = { onAddToPlaylist(song) },
                            subtitleOverride = "${song.artist} · Played ${song.playCount}×",
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                    }
                }
            }

            LibraryCategory.FAVORITES -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "${uiState.favoriteSongs.size} favourite tracks",
                            style = MaterialTheme.typography.titleMedium,
                            color = SunozaMutedText,
                        )
                        if (uiState.favoriteSongs.isNotEmpty()) {
                            Button(
                                onClick = onPlayFavorites,
                                colors = ButtonDefaults.buttonColors(containerColor = SunozaPink),
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Play All")
                            }
                        }
                    }
                }
                items(uiState.favoriteSongs, key = { "fav_${it.id}" }) { song ->
                    TrackRowItem(
                        song = song,
                        isCurrent = song.id == uiState.currentSong?.id,
                        onClick = { onPlaySong(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onAddToPlaylist = { onAddToPlaylist(song) },
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            }

            LibraryCategory.ALBUMS -> {
                items(albums, key = { "album_${it.first}" }) { (album, songs) ->
                    BucketCard(
                        icon = Icons.Filled.Album,
                        title = album,
                        subtitle = "${songs.size} track${if (songs.size == 1) "" else "s"} · ${songs.first().artist}",
                        songs = songs,
                        onPlayBucket = { onPlayCustomQueue(songs, songs.firstOrNull()) },
                        onPlaySong = onPlaySong,
                    )
                }
            }

            LibraryCategory.ARTISTS -> {
                items(artists, key = { "artist_${it.first}" }) { (artist, songs) ->
                    BucketCard(
                        icon = Icons.Filled.Person,
                        title = artist,
                        subtitle = "${songs.size} track${if (songs.size == 1) "" else "s"}",
                        songs = songs,
                        onPlayBucket = { onPlayCustomQueue(songs, songs.firstOrNull()) },
                        onPlaySong = onPlaySong,
                    )
                }
            }

            LibraryCategory.FOLDERS -> {
                items(folders, key = { "folder_${it.first}" }) { (folder, songs) ->
                    BucketCard(
                        icon = Icons.Filled.Folder,
                        title = folder,
                        subtitle = "${songs.size} track${if (songs.size == 1) "" else "s"}",
                        songs = songs,
                        onPlayBucket = { onPlayCustomQueue(songs, songs.firstOrNull()) },
                        onPlaySong = onPlaySong,
                    )
                }
            }

            LibraryCategory.PLAYLISTS -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "${uiState.playlists.size} custom playlists",
                            style = MaterialTheme.typography.titleMedium,
                            color = SunozaMutedText,
                        )
                        Button(
                            onClick = { showCreatePlaylist = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SunozaPurple),
                            modifier = Modifier.testTag("library_create_playlist_button"),
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("New Playlist")
                        }
                    }
                }

                if (uiState.playlists.isEmpty()) {
                    item {
                        EmptySectionCard(
                            title = "No playlists yet",
                            subtitle = "Create a playlist to organize and reorder your favourite tracks.",
                        )
                    }
                } else {
                    items(uiState.playlists, key = { "pl_${it.id}" }) { playlist ->
                        PlaylistExpandableCard(
                            playlist = playlist,
                            onPlay = { shuffle -> onPlayPlaylist(playlist, null, shuffle) },
                            onRename = { playlistToRename = playlist },
                            onDelete = { onDeletePlaylist(playlist.id) },
                            onPlaySong = { song -> onPlayPlaylist(playlist, song, false) },
                            onMoveSong = { from, to -> onMovePlaylistSong(playlist, from, to) },
                            onRemoveSong = { songId -> onRemoveSongFromPlaylist(playlist, songId) },
                        )
                    }
                }
            }
        }
    }

    if (showCreatePlaylist) {
        CreateOrRenamePlaylistDialog(
            title = "New Playlist",
            confirmLabel = "Create",
            onDismiss = { showCreatePlaylist = false },
            onConfirm = onCreatePlaylist,
        )
    }

    playlistToRename?.let { target ->
        CreateOrRenamePlaylistDialog(
            title = "Rename Playlist",
            initialName = target.name,
            confirmLabel = "Save",
            onDismiss = { playlistToRename = null },
            onConfirm = { newName -> onRenamePlaylist(target.id, newName) },
        )
    }
}

@Composable
private fun BucketCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    songs: List<Song>,
    onPlayBucket: () -> Unit,
    onPlaySong: (Song) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SunozaSurfaceElevated)
            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(16.dp))
            .clickable { expanded = !expanded }
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = SunozaPurple)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = SunozaIvory,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = SunozaMutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onPlayBucket) {
                Icon(Icons.Filled.PlayArrow, contentDescription = "Play $title", tint = SunozaIvory)
            }
        }

        AnimatedVisibility(visible = expanded) {
            Column(
                modifier = Modifier.padding(top = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                songs.forEach { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(SunozaSurface)
                            .clickable { onPlaySong(song) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SongArtwork(song = song, size = 34.dp, cornerRadius = 8.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, color = SunozaIvory, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = "${song.artist} · ${formatDuration(song.durationMs)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SunozaMutedText,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistExpandableCard(
    playlist: PlaylistWithSongs,
    onPlay: (shuffle: Boolean) -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onPlaySong: (Song) -> Unit,
    onMoveSong: (Int, Int) -> Unit,
    onRemoveSong: (Long) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(SunozaSurfaceElevated)
            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
            .clickable { expanded = !expanded }
            .padding(14.dp)
            .testTag("playlist_card_${playlist.id}"),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = null, tint = SunozaPink)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = playlist.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "${playlist.songs.size} song${if (playlist.songs.size == 1) "" else "s"}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SunozaMutedText,
                )
            }
            IconButton(onClick = { onPlay(false) }, modifier = Modifier.testTag("play_playlist_${playlist.id}")) {
                Icon(Icons.Filled.PlayArrow, contentDescription = "Play playlist", tint = SunozaIvory)
            }
            IconButton(onClick = { onPlay(true) }, modifier = Modifier.testTag("shuffle_playlist_${playlist.id}")) {
                Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle playlist", tint = SunozaMint)
            }
            IconButton(onClick = onRename) {
                Icon(Icons.Filled.Edit, contentDescription = "Rename playlist", tint = SunozaMutedText)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete playlist", tint = SunozaMutedText)
            }
        }

        AnimatedVisibility(visible = expanded) {
            Column(
                modifier = Modifier.padding(top = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (playlist.songs.isEmpty()) {
                    Text(
                        text = "No songs yet — add any local or authorized stream track via the playlist icon.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SunozaMutedText,
                    )
                } else {
                    playlist.songs.forEachIndexed { index, song ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SunozaSurface)
                                .clickable { onPlaySong(song) }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            SongArtwork(song = song, size = 34.dp, cornerRadius = 8.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, color = SunozaIvory, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
                            }
                            if (index > 0) {
                                IconButton(onClick = { onMoveSong(index, index - 1) }) {
                                    Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move up", tint = SunozaMutedText)
                                }
                            }
                            if (index < playlist.songs.lastIndex) {
                                IconButton(onClick = { onMoveSong(index, index + 1) }) {
                                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move down", tint = SunozaMutedText)
                                }
                            }
                            IconButton(onClick = { onRemoveSong(song.id) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove from playlist", tint = SunozaMutedText)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptySectionCard(
    title: String,
    subtitle: String,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(SunozaSurfaceElevated)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = SunozaIvory)
        Spacer(modifier = Modifier.height(4.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = SunozaMutedText)
    }
}
