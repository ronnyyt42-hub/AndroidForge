package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.remote.OnlineTrackCandidate
import com.example.model.PlaylistWithSongs
import com.example.model.Song
import com.example.ui.theme.SunozaCoral
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated

@Composable
fun LyricsEditorDialog(
    song: Song,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var lyricsInput by remember(song.id) { mutableStateOf(song.lyricsRaw) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text(
                text = "Lyrics · ${song.title}",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column {
                Text(
                    text = "Paste [mm:ss.xx] LRC lines for exact sync, or plain lines to auto-space across the track.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = lyricsInput,
                    onValueChange = { lyricsInput = it },
                    label = { Text("Synchronized or plain lyrics") },
                    placeholder = { Text("[00:00.00] First line\n[00:05.50] Second line") },
                    minLines = 6,
                    maxLines = 10,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("lyrics_editor_input"),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(lyricsInput)
                    onDismiss()
                },
                modifier = Modifier.testTag("save_lyrics_button"),
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun AddToPlaylistDialog(
    song: Song,
    playlists: List<PlaylistWithSongs>,
    onDismiss: () -> Unit,
    onToggleSongInPlaylist: (PlaylistWithSongs, Long) -> Unit,
    onCreatePlaylistWithSong: (String, Long) -> Unit,
) {
    var newPlaylistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text(
                text = "Add to Playlist",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${song.title} · ${song.artist}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items(playlists, key = { it.id }) { playlist ->
                        val isInPlaylist = playlist.songs.any { it.id == song.id }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleSongInPlaylist(playlist, song.id) }
                                .padding(vertical = 10.dp, horizontal = 4.dp)
                                .testTag("playlist_pick_${playlist.id}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = playlist.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                )
                                Text(
                                    text = "${playlist.songs.size} songs",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SunozaMutedText,
                                )
                            }
                            Icon(
                                imageVector = if (isInPlaylist) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                                contentDescription = if (isInPlaylist) "In playlist" else "Add to playlist",
                                tint = if (isInPlaylist) SunozaCoral else SunozaMutedText,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("New playlist name") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("new_playlist_inline_input"),
                    )
                    TextButton(
                        onClick = {
                            if (newPlaylistName.isNotBlank()) {
                                onCreatePlaylistWithSong(newPlaylistName, song.id)
                                newPlaylistName = ""
                            }
                        },
                        modifier = Modifier.testTag("create_playlist_inline_button"),
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Text("Create")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        },
    )
}

@Composable
fun AddOnlineCandidateToPlaylistDialog(
    candidate: OnlineTrackCandidate,
    playlists: List<PlaylistWithSongs>,
    onDismiss: () -> Unit,
    onSelectPlaylist: (Long) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Add Online Track to Playlist") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("${candidate.title} · ${candidate.artist}", color = SunozaMutedText)
                Spacer(modifier = Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text("Create a playlist in Library first.", color = SunozaMutedText)
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 220.dp)) {
                        items(playlists, key = { it.id }) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSelectPlaylist(pl.id)
                                        onDismiss()
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(pl.name, color = SunozaIvory, style = MaterialTheme.typography.bodyLarge)
                                Text("${pl.songs.size} tracks", color = SunozaMutedText, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        },
    )
}

@Composable
fun CreateOrRenamePlaylistDialog(
    title: String,
    initialName: String = "",
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var name by remember(initialName) { mutableStateOf(initialName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Playlist name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("playlist_name_input"),
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(name.trim())
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("confirm_playlist_name_button"),
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun AuthorizedStreamUrlDialog(
    onDismiss: () -> Unit,
    onAddUrl: (url: String, title: String, artist: String) -> Unit,
) {
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Add Authorized Stream", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Only HTTPS audio links from authorized Creative Commons & Public Domain providers (archive.org, wikimedia.org, freemusicarchive.org, incompetech.com, opengameart.org, ccmixter.org, soundhelix.com) are accepted.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("HTTPS Audio URL") },
                    placeholder = { Text("https://archive.org/download/...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("authorized_url_input"),
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Song title (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Singer / Artist (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onAddUrl(url, title, artist) },
                modifier = Modifier.testTag("submit_authorized_url_button"),
            ) {
                Text("Verify & Play")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun SelectSongForDeckDialog(
    title: String,
    songs: List<Song>,
    onDismiss: () -> Unit,
    onSelectSong: (Song) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(songs, query) {
        val q = query.trim()
        if (q.isEmpty()) songs else songs.filter {
            it.title.contains(q, ignoreCase = true) || it.artist.contains(q, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Filter tracks…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                LazyColumn(
                    modifier = Modifier.heightIn(max = 280.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(filtered, key = { it.id }) { song ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SunozaSurfaceElevated)
                                .clickable { onSelectSong(song) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            SongArtwork(song = song, size = 36.dp, cornerRadius = 8.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, color = SunozaIvory, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${song.artist} · ${song.bpm} BPM", style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
fun SaveMixDialog(
    defaultName: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var name by remember(defaultName) { mutableStateOf(defaultName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Save MixFlow Preset") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Mix name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank()) onSave(name.trim()) }) {
                Text("Save Mix")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueBottomSheet(
    queueTitle: String,
    queue: List<Song>,
    currentSongId: Long?,
    onSelectSong: (Song) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SunozaSurface,
        contentColor = SunozaIvory,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
        ) {
            Text(
                text = "Up Next · $queueTitle",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = SunozaIvory,
            )
            Spacer(modifier = Modifier.height(12.dp))
            LazyColumn(
                modifier = Modifier.heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(queue, key = { index, s -> "${s.id}_$index" }) { _, song ->
                    val active = song.id == currentSongId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SunozaSurfaceElevated)
                            .clickable {
                                onSelectSong(song)
                                onDismiss()
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SongArtwork(song = song, size = 38.dp, cornerRadius = 8.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                color = if (active) SunozaPink else SunozaIvory,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(song.artist, style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
                        }
                        if (active) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Currently playing", tint = SunozaPink)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
