package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.remote.OnlineTrackCandidate
import com.example.model.PlaylistWithSongs
import com.example.model.Song
import com.example.ui.theme.SunozaCoral
import com.example.ui.theme.SunozaErrorRed
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated

@Composable
fun LyricsEditorDialog(
    song: Song,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var lyricsInput by remember(song.id) { mutableStateOf(song.lyricsRaw) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text(
                text = "Lyrics · ${song.title}",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column {
                Text(
                    text = "Paste [mm:ss.xx] LRC lines for exact sync, or plain lines to auto-space across the track.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = lyricsInput,
                    onValueChange = { lyricsInput = it },
                    label = { Text("Synchronized or plain lyrics") },
                    placeholder = { Text("[00:00.00] First line\n[00:05.50] Second line") },
                    minLines = 6,
                    maxLines = 10,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("lyrics_editor_input"),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(lyricsInput)
                    onDismiss()
                },
                modifier = Modifier.testTag("save_lyrics_button"),
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun AddToPlaylistDialog(
    song: Song,
    playlists: List<PlaylistWithSongs>,
    onDismiss: () -> Unit,
    onToggleSongInPlaylist: (PlaylistWithSongs, Long) -> Unit,
    onCreatePlaylistWithSong: (String, Long) -> Unit,
) {
    var newPlaylistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text(
                text = "Add to Playlist",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${song.title} · ${song.artist}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items(playlists, key = { it.id }) { playlist ->
                        val isInPlaylist = playlist.songs.any { it.id == song.id }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleSongInPlaylist(playlist, song.id) }
                                .padding(vertical = 10.dp, horizontal = 4.dp)
                                .testTag("playlist_pick_${playlist.id}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = playlist.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                )
                                Text(
                                    text = "${playlist.songs.size} songs",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SunozaMutedText,
                                )
                            }
                            Icon(
                                imageVector = if (isInPlaylist) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                                contentDescription = if (isInPlaylist) "In playlist" else "Add to playlist",
                                tint = if (isInPlaylist) SunozaCoral else SunozaMutedText,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("New playlist name") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("new_playlist_inline_input"),
                    )
                    TextButton(
                        onClick = {
                            if (newPlaylistName.isNotBlank()) {
                                onCreatePlaylistWithSong(newPlaylistName, song.id)
                                newPlaylistName = ""
                            }
                        },
                        modifier = Modifier.testTag("create_playlist_inline_button"),
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Text("Create")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        },
    )
}

@Composable
fun AddOnlineCandidateToPlaylistDialog(
    candidate: OnlineTrackCandidate,
    playlists: List<PlaylistWithSongs>,
    onDismiss: () -> Unit,
    onSelectPlaylist: (Long) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Add Online Track to Playlist") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("${candidate.title} · ${candidate.artist}", color = SunozaMutedText)
                Spacer(modifier = Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text("Create a playlist in Library first.", color = SunozaMutedText)
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 220.dp)) {
                        items(playlists, key = { it.id }) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSelectPlaylist(pl.id)
                                        onDismiss()
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(pl.name, color = SunozaIvory, style = MaterialTheme.typography.bodyLarge)
                                Text("${pl.songs.size} tracks", color = SunozaMutedText, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        },
    )
}

@Composable
fun CreateOrRenamePlaylistDialog(
    title: String,
    initialName: String = "",
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var name by remember(initialName) { mutableStateOf(initialName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Playlist name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("playlist_name_input"),
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(name.trim())
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("confirm_playlist_name_button"),
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun AuthorizedStreamUrlDialog(
    onDismiss: () -> Unit,
    onAddUrl: (url: String, title: String, artist: String) -> Unit,
) {
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var confirmRights by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Add Authorized Stream", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = "Only HTTPS audio links from supported domains (archive.org, wikimedia.org, freemusicarchive.org, incompetech.com, opengameart.org, ccmixter.org, soundhelix.com) are accepted. Pasted URLs without embedded catalog metadata are marked license-unverified.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("HTTPS Audio URL") },
                    placeholder = { Text("https://archive.org/download/...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("authorized_url_input"),
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Song title (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Singer / Artist (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { confirmRights = !confirmRights },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(
                        checked = confirmRights,
                        onCheckedChange = { confirmRights = it },
                        modifier = Modifier.testTag("authorized_url_rights_checkbox"),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "I confirm I hold permission or license rights to stream this external URL.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SunozaIvory,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onAddUrl(url, title, artist) },
                enabled = confirmRights && url.isNotBlank(),
                modifier = Modifier.testTag("submit_authorized_url_button"),
            ) {
                Text("Verify & Play")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun SelectSongForDeckDialog(
    title: String,
    songs: List<Song>,
    onDismiss: () -> Unit,
    onSelectSong: (Song) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(songs, query) {
        val q = query.trim()
        if (q.isEmpty()) songs else songs.filter {
            it.title.contains(q, ignoreCase = true) || it.artist.contains(q, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Filter tracks…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                LazyColumn(
                    modifier = Modifier.heightIn(max = 280.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(filtered, key = { it.id }) { song ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SunozaSurfaceElevated)
                                .clickable { onSelectSong(song) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            SongArtwork(song = song, size = 36.dp, cornerRadius = 8.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, color = SunozaIvory, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${song.artist} · ${song.bpm} BPM", style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
fun SaveMixDialog(
    defaultName: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var name by remember(defaultName) { mutableStateOf(defaultName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Save MixFlow Preset") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Mix name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank()) onSave(name.trim()) }) {
                Text("Save Mix")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueBottomSheet(
    queueTitle: String,
    queue: List<Song>,
    currentSongId: Long?,
    onSelectSong: (Song) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SunozaSurface,
        contentColor = SunozaIvory,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
        ) {
            Text(
                text = "Up Next · $queueTitle",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = SunozaIvory,
            )
            Spacer(modifier = Modifier.height(12.dp))
            LazyColumn(
                modifier = Modifier.heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(queue, key = { index, s -> "${s.id}_$index" }) { _, song ->
                    val active = song.id == currentSongId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SunozaSurfaceElevated)
                            .clickable {
                                onSelectSong(song)
                                onDismiss()
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SongArtwork(song = song, size = 38.dp, cornerRadius = 8.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                color = if (active) SunozaPink else SunozaIvory,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(song.artist, style = MaterialTheme.typography.labelSmall, color = SunozaMutedText)
                        }
                        if (active) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Currently playing", tint = SunozaPink)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

data class TrackAttributionInfo(
    val title: String,
    val artist: String,
    val providerName: String,
    val licenseName: String,
    val isLicenseVerified: Boolean,
    val isPreviewOnly: Boolean,
    val streamUrl: String,
    val licenseUrl: String? = null,
    val sourcePageUrl: String? = null,
    val externalStoreUrl: String? = null,
    val attributionText: String = "",
)

fun Song.toAttributionInfo(): TrackAttributionInfo = TrackAttributionInfo(
    title = title,
    artist = artist,
    providerName = sourceLabel,
    licenseName = licenseName,
    isLicenseVerified = isLicenseVerified,
    isPreviewOnly = isPreviewOnly,
    streamUrl = audioUri,
    licenseUrl = licenseUrl,
    sourcePageUrl = sourcePageUrl,
    externalStoreUrl = externalStoreUrl,
    attributionText = attributionText,
)

fun OnlineTrackCandidate.toAttributionInfo(): TrackAttributionInfo = TrackAttributionInfo(
    title = title,
    artist = artist,
    providerName = providerName,
    licenseName = licenseName,
    isLicenseVerified = isLicenseVerified,
    isPreviewOnly = isPreviewOnly,
    streamUrl = streamUrl,
    licenseUrl = licenseUrl,
    sourcePageUrl = sourcePageUrl,
    externalStoreUrl = externalStoreUrl,
    attributionText = attributionText,
)

@Composable
fun TrackAttributionDialog(
    info: TrackAttributionInfo,
    onDismiss: () -> Unit,
    onReportContent: (TrackAttributionInfo) -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val isItunes = info.isPreviewOnly ||
        info.streamUrl.contains("audio-ssl.itunes.apple.com", ignoreCase = true)
    val storeLink = info.externalStoreUrl ?: if (isItunes) info.sourcePageUrl else null

    val (badgeLabel, badgeColor) = when {
        info.isLicenseVerified -> "Verified Open License / Bundled" to SunozaMint
        isItunes -> "Promotional 30s Preview Only" to SunozaOrange
        else -> "License Unverified — Confirm Rights" to SunozaOrange
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = badgeColor)
                Text("License & Attribution", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(info.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SunozaIvory)
                Text("${info.artist} · Provider: ${info.providerName}", style = MaterialTheme.typography.bodyMedium, color = SunozaMutedText)

                Text(
                    text = badgeLabel,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = SunozaObsidian,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(badgeColor)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("attribution_verification_badge"),
                )

                Text(
                    text = "License: ${info.licenseName}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaIvory,
                )

                if (info.attributionText.isNotBlank()) {
                    Text(
                        text = info.attributionText,
                        style = MaterialTheme.typography.bodySmall,
                        color = SunozaMutedText,
                    )
                }

                if (isItunes) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SunozaSurfaceElevated)
                            .border(1.dp, SunozaOrange.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = "Provided courtesy of iTunes",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = SunozaOrange,
                        )
                        Text(
                            text = "30-second promotional preview for streaming only (not cached offline).",
                            style = MaterialTheme.typography.bodySmall,
                            color = SunozaMutedText,
                        )
                        if (!storeLink.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = { runCatching { uriHandler.openUri(storeLink) } },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Icon(Icons.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Listen on Apple Music / iTunes")
                            }
                        }
                    }
                }

                if (info.providerName.contains("Wikimedia", ignoreCase = true)) {
                    Text(
                        text = "Wikimedia Foundation hosts this contributor file under its stated open license and does not endorse Sunoza.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SunozaMutedText,
                    )
                }

                val licenseLink = info.licenseUrl?.takeIf { it.startsWith("http", ignoreCase = true) }
                if (licenseLink != null) {
                    OutlinedButton(
                        onClick = { runCatching { uriHandler.openUri(licenseLink) } },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open License Deed")
                    }
                }

                val sourceLink = info.sourcePageUrl?.takeIf {
                    it.startsWith("http", ignoreCase = true) && it != storeLink
                }
                if (sourceLink != null) {
                    OutlinedButton(
                        onClick = { runCatching { uriHandler.openUri(sourceLink) } },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Source Page")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onDismiss()
                    onReportContent(info)
                },
                modifier = Modifier.testTag("attribution_report_button"),
            ) {
                Icon(Icons.Filled.Flag, contentDescription = null, tint = SunozaErrorRed, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Report / DMCA", color = SunozaErrorRed)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        },
    )
}

@Composable
fun PrivacyPolicyDialog(
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = SunozaMint)
                Text("Privacy Policy & Data Notice", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = "1. On-Device Storage",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                )
                Text(
                    text = "Sunoza stores your library index, playlists, saved mixes, listening history, Sound Studio equalizer settings, and local content reports strictly on your device using Android Room and DataStore.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SunozaMutedText,
                )
                Text(
                    text = "2. Cloud Backup & Transfer Exclusion",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                )
                Text(
                    text = "Local databases, preferences, and preference files are excluded from Android cloud backup and device-to-device transfer to prevent device storage URI leaks.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SunozaMutedText,
                )
                Text(
                    text = "3. App Permissions",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                )
                Text(
                    text = "Audio storage access is requested only to scan your device music when you opt in. Network access and media playback foreground service notifications are used for online streaming and lock-screen controls.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SunozaMutedText,
                )
                Text(
                    text = "4. Third-Party Streaming APIs",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                )
                Text(
                    text = "When searching or playing online streams, requests are sent directly to Audius, Internet Archive, Wikimedia Commons, and Apple iTunes Search APIs, each governed by its own privacy policy.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SunozaMutedText,
                )
                Text(
                    text = "5. Public Launch Setup Required",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SunozaOrange,
                )
                Text(
                    text = "Before publishing on Google Play, publish this Privacy Policy on an external HTTPS webpage and link that URL in your Google Play Console Data Safety & Store Listing forms.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SunozaIvory,
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Done")
            }
        },
    )
}

@Composable
fun ContentReportDialog(
    initialTrack: TrackAttributionInfo? = null,
    onDismiss: () -> Unit,
    onSubmitReport: (
        streamUrl: String,
        title: String,
        artist: String,
        providerName: String,
        reason: String,
        reporterEmail: String,
        details: String,
    ) -> Unit,
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val reasons = remember {
        listOf(
            "Copyright / DMCA Takedown",
            "Non-Commercial or Unlicensed Track",
            "Missing / Incorrect Attribution",
            "Inappropriate Content",
        )
    }

    var title by remember(initialTrack) { mutableStateOf(initialTrack?.title.orEmpty()) }
    var artist by remember(initialTrack) { mutableStateOf(initialTrack?.artist.orEmpty()) }
    var providerName by remember(initialTrack) { mutableStateOf(initialTrack?.providerName.orEmpty()) }
    var streamUrl by remember(initialTrack) { mutableStateOf(initialTrack?.streamUrl.orEmpty()) }
    var selectedReason by remember { mutableStateOf(reasons.first()) }
    var reporterEmail by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var submittedReportText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Flag, contentDescription = null, tint = SunozaErrorRed)
                Text(
                    text = if (submittedReportText == null) "Report Copyright / Content" else "Saved & Blocked Locally",
                    style = MaterialTheme.typography.titleLarge,
                )
            }
        },
        text = {
            val savedSummary = submittedReportText
            if (savedSummary == null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = "Submitting blocks the stream locally on this device and generates a takedown summary you can forward to the upstream catalog or your compliance inbox.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SunozaMutedText,
                    )
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Track title") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_title_input"),
                    )
                    OutlinedTextField(
                        value = artist,
                        onValueChange = { artist = it },
                        label = { Text("Artist (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = streamUrl,
                        onValueChange = { streamUrl = it },
                        label = { Text("Stream / Source URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text("Reason", style = MaterialTheme.typography.labelLarge, color = SunozaIvory)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        reasons.forEach { reason ->
                            FilterChip(
                                selected = selectedReason == reason,
                                onClick = { selectedReason = reason },
                                label = { Text(reason) },
                            )
                        }
                    }
                    OutlinedTextField(
                        value = reporterEmail,
                        onValueChange = { reporterEmail = it },
                        label = { Text("Your contact email (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = details,
                        onValueChange = { details = it },
                        label = { Text("Rights / copyright details") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_details_input"),
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Report saved on-device & stream blocked locally. No central takedown server is configured in this build — share or copy this report to forward it to your compliance email or the upstream provider.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SunozaOrange,
                    )
                    OutlinedButton(
                        onClick = {
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Sunoza Copyright / Content Report: ${title.ifBlank { "Track" }}")
                                putExtra(Intent.EXTRA_TEXT, savedSummary)
                            }
                            runCatching {
                                context.startActivity(Intent.createChooser(sendIntent, "Send Content Report"))
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("share_content_report_button"),
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share / Email Report")
                    }
                    OutlinedButton(
                        onClick = { clipboard.setText(AnnotatedString(savedSummary)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("copy_content_report_button"),
                    ) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Report Text")
                    }
                }
            }
        },
        confirmButton = {
            if (submittedReportText == null) {
                Button(
                    onClick = {
                        onSubmitReport(streamUrl, title, artist, providerName, selectedReason, reporterEmail, details)
                        submittedReportText = buildString {
                            appendLine("Sunoza Copyright / Content Report")
                            appendLine("Reason: $selectedReason")
                            appendLine("Track: ${title.ifBlank { "Unspecified" }}")
                            if (artist.isNotBlank()) appendLine("Artist: $artist")
                            if (providerName.isNotBlank()) appendLine("Provider: $providerName")
                            if (streamUrl.isNotBlank()) appendLine("Stream URL: $streamUrl")
                            if (reporterEmail.isNotBlank()) appendLine("Reporter Email: $reporterEmail")
                            if (details.isNotBlank()) appendLine("Details: $details")
                        }
                    },
                    enabled = title.isNotBlank() || streamUrl.isNotBlank() || details.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = SunozaErrorRed),
                    modifier = Modifier.testTag("submit_content_report_button"),
                ) {
                    Text("Save & Block Locally")
                }
            } else {
                Button(onClick = onDismiss) {
                    Text("Done")
                }
            }
        },
        dismissButton = {
            if (submittedReportText == null) {
                TextButton(onClick = onDismiss) {
                    Text("Cancel")
                }
            }
        },
    )
}
