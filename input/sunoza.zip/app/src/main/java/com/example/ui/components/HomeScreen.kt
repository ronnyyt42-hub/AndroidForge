package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.Song
import com.example.ui.SunozaUiState
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurfaceElevated

@Composable
fun HomeScreen(
    uiState: SunozaUiState,
    onPlaySong: (Song) -> Unit,
    onPlayCustomQueue: (List<Song>, Song?) -> Unit,
    onOpenNowPlaying: () -> Unit,
    onOpenSoundStudio: () -> Unit,
    onOpenMixFlow: () -> Unit,
    onStartPartyFlow: (Song?) -> Unit,
    onOpenLibrary: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val activeSong = uiState.currentSong ?: uiState.allSongs.firstOrNull()
    val recs = uiState.recommendations

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SunozaObsidian)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        item {
            SunozaBrandHeader(
                title = "SUNOZA",
                subtitle = "${uiState.allSongs.size} tracks ready · ${uiState.soundStudio.activePresetName} EQ",
            )
        }

        // Hero Continue Listening / Full Player launch card
        if (activeSong != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    SunozaPurple.copy(alpha = 0.28f),
                                    SunozaPink.copy(alpha = 0.20f),
                                    SunozaSurfaceElevated,
                                )
                            )
                        )
                        .border(1.dp, SunozaPurple.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
                        .clickable { onOpenNowPlaying() }
                        .padding(18.dp)
                        .testTag("home_hero_card"),
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SongArtwork(song = activeSong, size = 72.dp, cornerRadius = 16.dp)
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (uiState.playback.isPlaying) "NOW PLAYING" else "CONTINUE LISTENING",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SunozaOrange,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = activeSong.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = SunozaIvory,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = "${activeSong.artist} · ${activeSong.bpm} BPM",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SunozaMutedText,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Button(
                                onClick = { onOpenNowPlaying() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SunozaPurple,
                                    contentColor = SunozaIvory,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_open_player_button"),
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Full Player")
                            }

                            Button(
                                onClick = { onStartPartyFlow(activeSong) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SunozaSurfaceElevated,
                                    contentColor = SunozaIvory,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_partyflow_button"),
                            ) {
                                Icon(Icons.Filled.Bolt, contentDescription = null, tint = SunozaOrange, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("PartyFlow")
                            }
                        }
                    }
                }
            }
        }

        // Studio Quick Actions
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                QuickStudioTile(
                    icon = Icons.Filled.Equalizer,
                    title = "Sound Studio",
                    subtitle = if (uiState.soundStudio.isEnabled) uiState.soundStudio.activePresetName else "Bypassed",
                    accent = SunozaPurple,
                    onClick = onOpenSoundStudio,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_sound_studio_tile"),
                )
                QuickStudioTile(
                    icon = Icons.Filled.GraphicEq,
                    title = "MixFlow DJ",
                    subtitle = "Dual decks & BPM sync",
                    accent = SunozaPink,
                    onClick = onOpenMixFlow,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_mixflow_tile"),
                )
                QuickStudioTile(
                    icon = Icons.Filled.Tune,
                    title = "PartyFlow",
                    subtitle = uiState.partyFlow.energyMode.label,
                    accent = SunozaOrange,
                    onClick = { onStartPartyFlow(activeSong) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_party_tile"),
                )
            }
        }

        // Recommended For You
        if (recs.recommendedForYou.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeading(
                        title = "Recommended for You",
                        subtitle = "Ranked from listening history, BPM & energy",
                        actionLabel = "Play All",
                        onActionClick = { onPlayCustomQueue(recs.recommendedForYou, recs.recommendedForYou.first()) },
                    )
                    SongCarouselRow(
                        songs = recs.recommendedForYou,
                        onPlaySong = onPlaySong,
                    )
                }
            }
        }

        // Discover Weekly
        if (recs.discoverWeekly.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeading(
                        title = "Discover Weekly",
                        subtitle = "Fresh picks aligned with your taste",
                        actionLabel = "Play All",
                        onActionClick = { onPlayCustomQueue(recs.discoverWeekly, recs.discoverWeekly.first()) },
                    )
                    SongCarouselRow(
                        songs = recs.discoverWeekly,
                        onPlaySong = onPlaySong,
                    )
                }
            }
        }

        // Recently Played
        if (uiState.recentlyPlayedSongs.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeading(
                        title = "Recently Played",
                        subtitle = "Jump right back in",
                        actionLabel = "Library",
                        onActionClick = onOpenLibrary,
                    )
                    SongCarouselRow(
                        songs = uiState.recentlyPlayedSongs,
                        onPlaySong = onPlaySong,
                    )
                }
            }
        }

        // Genre & Mood Picks
        if (recs.genreBuckets.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeading(
                        title = "Genre Mixes",
                        subtitle = "Tap any genre to play its collection",
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(recs.genreBuckets, key = { it.first }) { (genre, tracks) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(SunozaSurfaceElevated)
                                    .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(16.dp))
                                    .clickable { onPlayCustomQueue(tracks, tracks.firstOrNull()) }
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                            ) {
                                Column {
                                    Text(
                                        text = genre,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = SunozaIvory,
                                    )
                                    Text(
                                        text = "${tracks.size} track${if (tracks.size == 1) "" else "s"}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = SunozaMint,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Favorite Artists
        if (recs.favoriteArtists.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeading(
                        title = "Favourite Artists",
                        subtitle = "Artists you replay the most",
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(recs.favoriteArtists, key = { it.first }) { (artist, tracks) ->
                            Column(
                                modifier = Modifier
                                    .width(150.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(SunozaSurfaceElevated)
                                    .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(16.dp))
                                    .clickable { onPlayCustomQueue(tracks, tracks.firstOrNull()) }
                                    .padding(14.dp),
                            ) {
                                Text(
                                    text = artist,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SunozaIvory,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${tracks.size} song${if (tracks.size == 1) "" else "s"}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SunozaMutedText,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickStudioTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(SunozaSurfaceElevated)
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = accent,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = SunozaIvory,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = SunozaMutedText,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun SongCarouselRow(
    songs: List<Song>,
    onPlaySong: (Song) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(songs, key = { it.id }) { song ->
            Column(
                modifier = Modifier
                    .width(148.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SunozaSurfaceElevated)
                    .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
                    .clickable { onPlaySong(song) }
                    .padding(10.dp),
            ) {
                SongArtwork(
                    song = song,
                    size = 128.dp,
                    cornerRadius = 14.dp,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = SunozaIvory,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = song.artist,
                    style = MaterialTheme.typography.labelMedium,
                    color = SunozaMutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
