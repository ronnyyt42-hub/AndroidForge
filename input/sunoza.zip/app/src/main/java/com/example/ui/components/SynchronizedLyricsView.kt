package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lyrics
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.LyricLine
import com.example.model.LyricsParser
import com.example.ui.theme.SunozaIvory

@Composable
fun SynchronizedLyricsView(
    lyrics: List<LyricLine>,
    positionMs: Long,
    isActivePage: Boolean,
    onSeekToLine: (Long) -> Unit,
    onEditLyrics: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (lyrics.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.Black.copy(alpha = 0.18f))
                .padding(24.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(
                    imageVector = Icons.Outlined.Lyrics,
                    contentDescription = null,
                    tint = SunozaIvory.copy(alpha = 0.65f),
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = stringResource(R.string.no_lyrics_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = SunozaIvory,
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.no_lyrics_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaIvory.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(14.dp))
                FilledTonalButton(
                    onClick = onEditLyrics,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color.White.copy(alpha = 0.16f),
                        contentColor = SunozaIvory,
                    ),
                    modifier = Modifier.testTag("add_lyrics_button"),
                ) {
                    Text(stringResource(R.string.add_lyrics))
                }
            }
        }
        return
    }

    val activeIndex = remember(lyrics, positionMs, isActivePage) {
        if (isActivePage) LyricsParser.activeLineIndex(lyrics, positionMs) else 0
    }
    val listState = rememberLazyListState()

    LaunchedEffect(activeIndex, isActivePage) {
        if (isActivePage && activeIndex >= 0 && activeIndex < lyrics.size) {
            val targetScroll = (activeIndex - 1).coerceAtLeast(0)
            listState.animateScrollToItem(targetScroll)
        }
    }

    // userScrollEnabled = false preserves crisp vertical swipe-up/swipe-down song switching anywhere on screen
    LazyColumn(
        state = listState,
        userScrollEnabled = false,
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("synchronized_lyrics_list"),
    ) {
        itemsIndexed(lyrics) { index, line ->
            val isCurrent = isActivePage && index == activeIndex
            val textColor by animateColorAsState(
                targetValue = if (isCurrent) {
                    SunozaIvory
                } else {
                    SunozaIvory.copy(alpha = 0.42f)
                },
                animationSpec = tween(durationMillis = 220),
                label = "lyricColor",
            )
            val textScale by animateFloatAsState(
                targetValue = if (isCurrent) 1.03f else 0.96f,
                animationSpec = tween(durationMillis = 220),
                label = "lyricScale",
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (isCurrent) Color.Black.copy(alpha = 0.22f) else Color.Transparent
                    )
                    .clickable { onSeekToLine(line.timestampMs) }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .testTag(if (isCurrent) "active_lyric_line" else "lyric_line_$index"),
            ) {
                Text(
                    text = line.text,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontSize = if (isCurrent) 22.sp else 18.sp,
                        lineHeight = if (isCurrent) 30.sp else 25.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                    ),
                    color = textColor,
                    modifier = Modifier.graphicsLayer {
                        scaleX = textScale
                        scaleY = textScale
                    },
                )
            }
        }
    }
}
