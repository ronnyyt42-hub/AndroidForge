package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.Song
import com.example.model.SourceType
import com.example.player.PlaybackState
import com.example.ui.theme.SunozaBrandColors
import com.example.ui.theme.SunozaCardHighlight
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated

val SunozaBrandBrush: Brush
    get() = Brush.linearGradient(SunozaBrandColors)

@Composable
fun SunozaBrandMark(
    size: Dp = 36.dp,
    modifier: Modifier = Modifier,
) {
    Image(
        painter = painterResource(id = R.drawable.ic_sunoza_logo),
        contentDescription = "Sunoza logo",
        contentScale = ContentScale.Fit,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .testTag("sunoza_brand_mark"),
    )
}

@Composable
fun SunozaBrandHeader(
    title: String,
    subtitle: String? = null,
    trailingContent: @Composable (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
        ) {
            SunozaBrandMark(size = 38.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = SunozaMutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (trailingContent != null) {
            Spacer(modifier = Modifier.width(8.dp))
            trailingContent()
        }
    }
}

@Composable
fun SongArtwork(
    song: Song?,
    size: Dp = 48.dp,
    cornerRadius: Dp = 12.dp,
    modifier: Modifier = Modifier,
) {
    val bgColor = if (song != null) Color(song.backgroundColorArgb) else SunozaCardHighlight
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(bgColor)
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(cornerRadius)),
        contentAlignment = Alignment.Center,
    ) {
        if (song?.artworkUri != null) {
            AsyncImage(
                model = song.artworkUri,
                contentDescription = "${song.title} album art",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            listOf(
                                bgColor,
                                bgColor.copy(alpha = 0.85f),
                                SunozaPurple.copy(alpha = 0.28f),
                            )
                        )
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = when (song?.sourceType) {
                        SourceType.OFFLINE_LOCAL -> Icons.Filled.AudioFile
                        SourceType.AUTHORIZED_ONLINE -> Icons.Filled.CloudQueue
                        else -> Icons.Filled.MusicNote
                    },
                    contentDescription = null,
                    tint = SunozaIvory.copy(alpha = 0.86f),
                    modifier = Modifier.size((size.value * 0.44f).dp.coerceIn(18.dp, 72.dp)),
                )
            }
        }
    }
}

@Composable
fun TrackRowItem(
    song: Song,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    subtitleOverride: String? = null,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isCurrent) SunozaCardHighlight else SunozaSurfaceElevated)
            .border(
                width = 1.dp,
                color = if (isCurrent) SunozaPurple.copy(alpha = 0.7f) else SunozaSubtleBorder,
                shape = RoundedCornerShape(16.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("track_row_${song.id}"),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SongArtwork(song = song, size = 46.dp, cornerRadius = 11.dp)

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isCurrent) SunozaPink else SunozaIvory,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(2.dp))
            val durationLabel = if (song.durationMs > 0L) formatDuration(song.durationMs) else "Stream"
            val previewSuffix = if (song.isPreviewOnly) " · PREVIEW ONLY" else ""
            Text(
                text = subtitleOverride ?: "${song.artist} · ${song.genre} · $durationLabel$previewSuffix",
                style = MaterialTheme.typography.labelMedium,
                color = if (song.isPreviewOnly) SunozaOrange else SunozaMutedText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("track_fav_${song.id}"),
        ) {
            Icon(
                imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Toggle favourite",
                tint = if (song.isFavorite) SunozaPink else SunozaMutedText,
            )
        }

        if (onAddToPlaylist != null) {
            IconButton(
                onClick = onAddToPlaylist,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("track_playlist_${song.id}"),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.PlaylistAdd,
                    contentDescription = "Add to playlist",
                    tint = SunozaMutedText,
                )
            }
        }

        if (onDelete != null) {
            IconButton(
                onClick = onDelete,
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Remove track",
                    tint = SunozaMutedText,
                )
            }
        }
    }
}

@Composable
fun MiniPlayerBar(
    song: Song,
    playback: PlaybackState,
    onExpand: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    nextSong: Song? = null,
    modifier: Modifier = Modifier,
) {
    val safeDuration = playback.durationMs.takeIf { it > 0L } ?: song.durationMs.coerceAtLeast(1L)
    val progress = (playback.positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onExpand)
            .testTag("mini_player_bar"),
        color = SunozaSurface,
        tonalElevation = 4.dp,
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SongArtwork(song = song, size = 44.dp, cornerRadius = 10.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = if (song.isPreviewOnly) "${song.artist} · 30s Preview Only" else song.artist,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (song.isPreviewOnly) SunozaOrange else SunozaMutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (nextSong != null) {
                        val modeLabel = if (playback.shuffleEnabled) "Shuffle" else "Next"
                        Text(
                            text = "$modeLabel: ${nextSong.title}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SunozaPink.copy(alpha = 0.88f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("mini_player_next_song"),
                        )
                    }
                }

                IconButton(
                    onClick = onTogglePlayPause,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(SunozaBrandBrush)
                        .testTag("mini_player_play_pause"),
                ) {
                    Icon(
                        imageVector = if (playback.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (playback.isPlaying) "Pause" else "Play",
                        tint = SunozaIvory,
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = onNext,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("mini_player_next"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.SkipNext,
                        contentDescription = "Next song",
                        tint = SunozaIvory,
                    )
                }
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp),
                color = SunozaOrange,
                trackColor = SunozaObsidian,
            )
        }
    }
}

@Composable
fun SectionHeading(
    title: String,
    subtitle: String? = null,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = SunozaIvory,
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = SunozaMutedText,
                )
            }
        }
        if (actionLabel != null && onActionClick != null) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = SunozaPink,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onActionClick)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}
