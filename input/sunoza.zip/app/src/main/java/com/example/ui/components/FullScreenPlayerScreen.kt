package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.Song
import com.example.ui.SunozaUiState
import com.example.ui.SunozaViewModel
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import com.example.ui.theme.SunozaSurface
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlin.math.roundToInt

@Composable
fun FullScreenPlayerScreen(
    uiState: SunozaUiState,
    viewModel: SunozaViewModel,
    onCollapse: () -> Unit,
    onOpenSoundStudio: () -> Unit,
    onOpenMixFlow: () -> Unit,
    onStartPartyFlow: (Song) -> Unit,
    onOpenAddToPlaylist: (Song) -> Unit,
    onOpenAttribution: (Song) -> Unit = {},
) {
    var showLyricsStage by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showSoundModesSheet by remember { mutableStateOf(false) }
    var songForLyricsEdit by remember { mutableStateOf<Song?>(null) }

    BackHandler {
        onCollapse()
    }

    val queue = uiState.activeQueue
    if (!uiState.isReady || queue.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SunozaObsidian),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(color = SunozaPurple)
        }
        return
    }

    val pagerState = rememberPagerState(
        initialPage = uiState.currentQueueIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0)),
        pageCount = { queue.size },
    )

    val latestQueue by rememberUpdatedState(queue)
    val latestCurrentIndex by rememberUpdatedState(uiState.currentQueueIndex)

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.settledPage }
            .distinctUntilChanged()
            .drop(1)
            .collect { page ->
                val currentQueue = latestQueue
                if (page in currentQueue.indices && page != latestCurrentIndex) {
                    viewModel.onSwipeToQueueIndex(page)
                }
            }
    }

    LaunchedEffect(uiState.currentQueueIndex, queue.size) {
        val target = uiState.currentQueueIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
        if (pagerState.currentPage != target && !pagerState.isScrollInProgress) {
            pagerState.animateScrollToPage(target)
        }
    }

    VerticalPager(
        state = pagerState,
        key = { index -> queue[index].id },
        modifier = Modifier
            .fillMaxSize()
            .testTag("song_vertical_pager"),
    ) { pageIndex ->
        val song = queue[pageIndex]
        val isCurrentPage = pageIndex == uiState.currentQueueIndex
        // Preserves Sunoza's signature per-song solid background color
        val pageBackground = Color(song.backgroundColorArgb)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(pageBackground)
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("song_page_${song.id}"),
            contentAlignment = Alignment.TopCenter,
        ) {
            val artworkSize = (maxHeight * 0.28f).coerceIn(152.dp, 232.dp)
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("player_collapse_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.KeyboardArrowDown,
                            contentDescription = "Minimize player",
                            tint = SunozaIvory,
                            modifier = Modifier.size(30.dp),
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showQueueSheet = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("queue_icon_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                                contentDescription = "Queue",
                                tint = SunozaIvory,
                            )
                        }
                        IconButton(
                            onClick = { showLyricsStage = !showLyricsStage },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("toggle_lyrics_artwork_button"),
                        ) {
                            Icon(
                                imageVector = if (showLyricsStage) Icons.Filled.Album else Icons.Filled.Lyrics,
                                contentDescription = if (showLyricsStage) "Show artwork" else "Show lyrics",
                                tint = SunozaIvory,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Main Stage: Large Album Artwork (swipeable left/right for next/previous) OR Synchronized Lyrics
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center,
                ) {
                    if (showLyricsStage) {
                        SynchronizedLyricsView(
                            lyrics = song.parsedLyrics,
                            positionMs = if (isCurrentPage) uiState.playback.positionMs else 0L,
                            isActivePage = isCurrentPage,
                            onSeekToLine = { ts -> if (isCurrentPage) viewModel.seekTo(ts) },
                            onEditLyrics = { songForLyricsEdit = song },
                        )
                    } else {
                        var artDragX by remember(song.id) { mutableFloatStateOf(0f) }
                        val animatedArtOffsetX by animateFloatAsState(
                            targetValue = artDragX,
                            animationSpec = spring(stiffness = 600f),
                            label = "artwork_horizontal_swipe",
                        )
                        val swipeThresholdPx = with(LocalDensity.current) { 56.dp.toPx() }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Box(
                                modifier = Modifier
                                    .pointerInput(song.id, swipeThresholdPx) {
                                        detectHorizontalDragGestures(
                                            onDragStart = { artDragX = 0f },
                                            onHorizontalDrag = { change, dragAmount ->
                                                change.consume()
                                                artDragX = (artDragX + dragAmount).coerceIn(-220f, 220f)
                                            },
                                            onDragCancel = { artDragX = 0f },
                                            onDragEnd = {
                                                val totalDrag = artDragX
                                                artDragX = 0f
                                                if (totalDrag <= -swipeThresholdPx) {
                                                    viewModel.nextSong()
                                                } else if (totalDrag >= swipeThresholdPx) {
                                                    viewModel.previousSong()
                                                }
                                            },
                                        )
                                    }
                                    .testTag("player_artwork_swipe_area"),
                            ) {
                                SongArtwork(
                                    song = song,
                                    size = artworkSize,
                                    cornerRadius = 28.dp,
                                    modifier = Modifier
                                        .offset { IntOffset(animatedArtOffsetX.roundToInt().coerceIn(-120, 120), 0) }
                                        .testTag("player_large_artwork"),
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            val modeTag = if (song.isPreviewOnly) " · 30s Preview Only" else ""
                            Text(
                                text = "${song.album} · ${song.genre} · ${song.bpm} BPM$modeTag",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (song.isPreviewOnly) SunozaOrange else SunozaIvory.copy(alpha = 0.78f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (song.isPreviewOnly) {
                                val uriHandler = LocalUriHandler.current
                                val storeLink = song.externalStoreUrl ?: song.sourcePageUrl
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(Color.Black.copy(alpha = 0.30f))
                                        .then(
                                            if (!storeLink.isNullOrBlank()) {
                                                Modifier.clickable { runCatching { uriHandler.openUri(storeLink) } }
                                            } else {
                                                Modifier
                                            }
                                        )
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                        .testTag("player_itunes_courtesy_badge"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Text(
                                        text = if (!storeLink.isNullOrBlank()) {
                                            "Provided courtesy of iTunes · Open Apple Music / iTunes"
                                        } else {
                                            "Provided courtesy of iTunes"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SunozaOrange,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Title, Artist & Favorite
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = SunozaIvory,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("player_song_title"),
                        )
                        Text(
                            text = song.artist,
                            style = MaterialTheme.typography.titleMedium,
                            color = SunozaIvory.copy(alpha = 0.8f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("player_song_artist"),
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleFavorite(song) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("player_favorite_button"),
                    ) {
                        Icon(
                            imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = stringResource(R.string.toggle_favourite),
                            tint = if (song.isFavorite) SunozaPink else SunozaIvory,
                            modifier = Modifier.size(28.dp),
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Single Sound Modes button + Playlist, Lyrics, Color, License
                val isAnySoundModeActive = uiState.soundStudio.isEnabled ||
                    uiState.mixFlow.deckA.isPlaying ||
                    uiState.mixFlow.deckB.isPlaying ||
                    uiState.mixFlow.isTransitioning ||
                    uiState.partyFlow.isActive
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp),
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (isAnySoundModeActive) {
                                        SunozaPurple.copy(alpha = 0.36f)
                                    } else {
                                        SunozaSurface.copy(alpha = 0.72f)
                                    },
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isAnySoundModeActive) SunozaPurple else SunozaPurple.copy(alpha = 0.45f),
                                    shape = RoundedCornerShape(50),
                                )
                                .clickable { showSoundModesSheet = true }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("player_sound_modes_button"),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tune,
                                contentDescription = "Sound Modes",
                                tint = SunozaIvory,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Sound Modes",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = SunozaIvory,
                            )
                        }
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.AutoMirrored.Filled.PlaylistAdd,
                            label = "Playlist",
                            onClick = { onOpenAddToPlaylist(song) },
                            tag = "player_add_to_playlist_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Filled.Lyrics,
                            label = "Edit Lyrics",
                            onClick = { songForLyricsEdit = song },
                            tag = "player_edit_lyrics_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Filled.ColorLens,
                            label = "Color",
                            onClick = { viewModel.randomizeSongColor(song) },
                            tag = "player_new_color_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Outlined.Info,
                            label = "License",
                            onClick = { onOpenAttribution(song) },
                            tag = "player_license_chip",
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Playback Controls Panel (Next, Previous, Play/Pause, Shuffle, Repeat always visible without scrolling)
                PlayerControlsPanel(
                    isPlaying = if (isCurrentPage) uiState.playback.isPlaying else false,
                    isBuffering = if (isCurrentPage) uiState.playback.isBuffering else false,
                    positionMs = if (isCurrentPage) uiState.playback.positionMs else 0L,
                    durationMs = if (isCurrentPage && uiState.playback.durationMs > 0L) {
                        uiState.playback.durationMs
                    } else {
                        song.durationMs
                    },
                    shuffleEnabled = uiState.playback.shuffleEnabled,
                    repeatMode = uiState.playback.repeatMode,
                    onPlayPause = { viewModel.togglePlayPause() },
                    onPrevious = { viewModel.previousSong() },
                    onNext = { viewModel.nextSong() },
                    onSeekTo = { viewModel.seekTo(it) },
                    onToggleShuffle = { viewModel.toggleShuffle() },
                    onCycleRepeat = { viewModel.cycleRepeatMode() },
                )

                Spacer(modifier = Modifier.height(6.dp))
            }
        }
    }

    if (showSoundModesSheet) {
        val activeSong = uiState.currentSong ?: queue.getOrNull(uiState.currentQueueIndex) ?: queue.first()
        SoundModesBottomSheet(
            activeStudioPreset = uiState.soundStudio.activePresetName,
            isStudioEnabled = uiState.soundStudio.isEnabled,
            isMixFlowActive = uiState.mixFlow.deckA.isPlaying ||
                uiState.mixFlow.deckB.isPlaying ||
                uiState.mixFlow.isTransitioning,
            isPartyFlowActive = uiState.partyFlow.isActive,
            partyEnergyLabel = uiState.partyFlow.energyMode.label,
            onOpenStudio = onOpenSoundStudio,
            onOpenMixFlow = {
                viewModel.blendCurrentAndNextInMixFlow()
                onOpenMixFlow()
            },
            onStartPartyFlow = { onStartPartyFlow(activeSong) },
            onDismiss = { showSoundModesSheet = false },
        )
    }

    if (showQueueSheet) {
        QueueBottomSheet(
            queueTitle = uiState.activeQueueFilter.label,
            queue = queue,
            currentSongId = uiState.currentSong?.id,
            onSelectSong = { viewModel.playSongInCurrentOrAllQueue(it) },
            onDismiss = { showQueueSheet = false },
        )
    }

    songForLyricsEdit?.let { target ->
        LyricsEditorDialog(
            song = target,
            onDismiss = { songForLyricsEdit = null },
            onSave = { updated -> viewModel.updateLyrics(target.id, updated) },
        )
    }
}

@Composable
private fun NowPlayingActionChip(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    tag: String,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.Black.copy(alpha = 0.25f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = label, tint = SunozaIvory, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = SunozaIvory)
    }
}
