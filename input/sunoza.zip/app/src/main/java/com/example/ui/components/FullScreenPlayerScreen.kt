package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.Song
import com.example.ui.SunozaUiState
import com.example.ui.SunozaViewModel
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaOrange
import com.example.ui.theme.SunozaPink
import com.example.ui.theme.SunozaPurple
import kotlinx.coroutines.flow.distinctUntilChanged

@Composable
fun FullScreenPlayerScreen(
    uiState: SunozaUiState,
    viewModel: SunozaViewModel,
    onCollapse: () -> Unit,
    onOpenSoundStudio: () -> Unit,
    onOpenMixFlow: () -> Unit,
    onStartPartyFlow: (Song) -> Unit,
    onOpenAddToPlaylist: (Song) -> Unit,
    onOpenAttribution: (Song) -> Unit = {},
) {
    var showLyricsStage by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var songForLyricsEdit by remember { mutableStateOf<Song?>(null) }

    BackHandler {
        onCollapse()
    }

    val queue = uiState.activeQueue
    if (!uiState.isReady || queue.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SunozaObsidian),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(color = SunozaPurple)
        }
        return
    }

    val pagerState = rememberPagerState(
        initialPage = uiState.currentQueueIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0)),
        pageCount = { queue.size },
    )

    LaunchedEffect(pagerState, queue) {
        snapshotFlow { pagerState.settledPage }
            .distinctUntilChanged()
            .collect { page ->
                if (page in queue.indices) {
                    viewModel.onSwipeToQueueIndex(page)
                }
            }
    }

    LaunchedEffect(uiState.currentQueueIndex, queue.size) {
        val target = uiState.currentQueueIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
        if (pagerState.currentPage != target && !pagerState.isScrollInProgress) {
            pagerState.animateScrollToPage(target)
        }
    }

    VerticalPager(
        state = pagerState,
        key = { index -> queue[index].id },
        modifier = Modifier
            .fillMaxSize()
            .testTag("song_vertical_pager"),
    ) { pageIndex ->
        val song = queue[pageIndex]
        val isCurrentPage = pageIndex == uiState.currentQueueIndex
        // Preserves Sunoza's signature per-song solid background color
        val pageBackground = Color(song.backgroundColorArgb)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(pageBackground)
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("song_page_${song.id}"),
            contentAlignment = Alignment.TopCenter,
        ) {
            val artworkSize = (maxHeight * 0.28f).coerceIn(152.dp, 232.dp)
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("player_collapse_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.KeyboardArrowDown,
                            contentDescription = "Minimize player",
                            tint = SunozaIvory,
                            modifier = Modifier.size(30.dp),
                        )
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.24f))
                            .clickable { showQueueSheet = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("queue_pill_button"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                            contentDescription = "Queue",
                            tint = SunozaIvory,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${uiState.activeQueueFilter.label} · ${pageIndex + 1}/${queue.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = SunozaIvory,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    IconButton(
                        onClick = { showLyricsStage = !showLyricsStage },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("toggle_lyrics_artwork_button"),
                    ) {
                        Icon(
                            imageVector = if (showLyricsStage) Icons.Filled.Album else Icons.Filled.Lyrics,
                            contentDescription = if (showLyricsStage) "Show artwork" else "Show lyrics",
                            tint = SunozaIvory,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Main Stage: Large Album Artwork OR Synchronized Lyrics
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center,
                ) {
                    if (showLyricsStage) {
                        SynchronizedLyricsView(
                            lyrics = song.parsedLyrics,
                            positionMs = if (isCurrentPage) uiState.playback.positionMs else 0L,
                            isActivePage = isCurrentPage,
                            onSeekToLine = { ts -> if (isCurrentPage) viewModel.seekTo(ts) },
                            onEditLyrics = { songForLyricsEdit = song },
                        )
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            SongArtwork(
                                song = song,
                                size = artworkSize,
                                cornerRadius = 28.dp,
                                modifier = Modifier.testTag("player_large_artwork"),
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            val modeTag = if (song.isPreviewOnly) " · 30s Preview Only" else ""
                            Text(
                                text = "${song.album} · ${song.genre} · ${song.bpm} BPM$modeTag",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (song.isPreviewOnly) SunozaOrange else SunozaIvory.copy(alpha = 0.78f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (song.isPreviewOnly) {
                                val uriHandler = LocalUriHandler.current
                                val storeLink = song.externalStoreUrl ?: song.sourcePageUrl
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(Color.Black.copy(alpha = 0.30f))
                                        .then(
                                            if (!storeLink.isNullOrBlank()) {
                                                Modifier.clickable { runCatching { uriHandler.openUri(storeLink) } }
                                            } else {
                                                Modifier
                                            }
                                        )
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                        .testTag("player_itunes_courtesy_badge"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Text(
                                        text = if (!storeLink.isNullOrBlank()) {
                                            "Provided courtesy of iTunes · Open Apple Music / iTunes"
                                        } else {
                                            "Provided courtesy of iTunes"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SunozaOrange,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Title, Artist & Favorite
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = SunozaIvory,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("player_song_title"),
                        )
                        Text(
                            text = song.artist,
                            style = MaterialTheme.typography.titleMedium,
                            color = SunozaIvory.copy(alpha = 0.8f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("player_song_artist"),
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleFavorite(song) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("player_favorite_button"),
                    ) {
                        Icon(
                            imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = stringResource(R.string.toggle_favourite),
                            tint = if (song.isFavorite) SunozaPink else SunozaIvory,
                            modifier = Modifier.size(28.dp),
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Shortcuts: Sound Studio, Blend Current+Next (MixFlow), PartyFlow, Playlist, Lyrics, Solid Color
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp),
                ) {
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Filled.Equalizer,
                            label = "Studio (${uiState.soundStudio.activePresetName})",
                            onClick = onOpenSoundStudio,
                            tag = "player_sound_studio_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Filled.GraphicEq,
                            label = "Mix Next",
                            onClick = {
                                viewModel.blendCurrentAndNextInMixFlow()
                                onOpenMixFlow()
                            },
                            tag = "player_mixflow_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Filled.Bolt,
                            label = "PartyFlow",
                            onClick = { onStartPartyFlow(song) },
                            tag = "player_partyflow_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.AutoMirrored.Filled.PlaylistAdd,
                            label = "Playlist",
                            onClick = { onOpenAddToPlaylist(song) },
                            tag = "player_add_to_playlist_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Filled.Lyrics,
                            label = "Edit Lyrics",
                            onClick = { songForLyricsEdit = song },
                            tag = "player_edit_lyrics_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Filled.ColorLens,
                            label = "Color",
                            onClick = { viewModel.randomizeSongColor(song) },
                            tag = "player_new_color_chip",
                        )
                    }
                    item {
                        NowPlayingActionChip(
                            icon = Icons.Outlined.Info,
                            label = "License",
                            onClick = { onOpenAttribution(song) },
                            tag = "player_license_chip",
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Playback Controls Panel
                PlayerControlsPanel(
                    isPlaying = if (isCurrentPage) uiState.playback.isPlaying else false,
                    isBuffering = if (isCurrentPage) uiState.playback.isBuffering else false,
                    positionMs = if (isCurrentPage) uiState.playback.positionMs else 0L,
                    durationMs = if (isCurrentPage && uiState.playback.durationMs > 0L) {
                        uiState.playback.durationMs
                    } else {
                        song.durationMs
                    },
                    shuffleEnabled = uiState.playback.shuffleEnabled,
                    repeatMode = uiState.playback.repeatMode,
                    onPlayPause = { viewModel.togglePlayPause() },
                    onPrevious = { viewModel.previousSong() },
                    onNext = { viewModel.nextSong() },
                    onSeekTo = { viewModel.seekTo(it) },
                    onToggleShuffle = { viewModel.toggleShuffle() },
                    onCycleRepeat = { viewModel.cycleRepeatMode() },
                    onStopPlayback = { viewModel.stopPlayback() },
                    isExplicitlyStopped = uiState.playback.isExplicitlyStopped,
                )

                // Actual Up Next indicator (reflects real shuffle/queue selection)
                Spacer(modifier = Modifier.height(8.dp))
                val actualNext = uiState.nextSong
                val upNextHeading = when {
                    uiState.playback.isExplicitlyStopped -> "Stopped · Auto-Next Paused"
                    uiState.playback.repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE ->
                        "Up Next · Repeating Current"
                    uiState.playback.shuffleEnabled -> "Up Next · Shuffle Random"
                    else -> "Up Next · Queue Order"
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(alpha = 0.26f))
                        .then(
                            if (actualNext != null) {
                                Modifier.clickable { viewModel.playSongInCurrentOrAllQueue(actualNext) }
                            } else {
                                Modifier
                            }
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("actual_next_song_card"),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SongArtwork(song = actualNext, size = 32.dp, cornerRadius = 8.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = upNextHeading,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SunozaOrange,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("actual_next_mode_label"),
                        )
                        Text(
                            text = if (actualNext != null) {
                                "${actualNext.title} · ${actualNext.artist}"
                            } else {
                                "No eligible full track up next"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = SunozaIvory,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("actual_next_song_title"),
                        )
                    }
                    if (actualNext != null && actualNext.durationMs > 0L) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = formatDuration(actualNext.durationMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = SunozaIvory.copy(alpha = 0.72f),
                        )
                    }
                }

                // Recommended Next Songs strip
                val smartNext = uiState.recommendations.smartPlayNext
                if (smartNext.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Recommended Picks",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SunozaIvory.copy(alpha = 0.78f),
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(smartNext, key = { "next_${it.id}" }) { nextTrack ->
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black.copy(alpha = 0.24f))
                                    .clickable { viewModel.playSongInCurrentOrAllQueue(nextTrack) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                SongArtwork(song = nextTrack, size = 28.dp, cornerRadius = 6.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = nextTrack.title,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = SunozaIvory,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = "${nextTrack.bpm} BPM",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SunozaOrange,
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Swipe hint
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (pageIndex < queue.lastIndex) {
                        Icon(Icons.Filled.KeyboardArrowUp, contentDescription = null, tint = SunozaIvory.copy(alpha = 0.55f), modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = stringResource(R.string.swipe_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = SunozaIvory.copy(alpha = 0.6f),
                    )
                    if (pageIndex > 0) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = SunozaIvory.copy(alpha = 0.55f), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }

    if (showQueueSheet) {
        QueueBottomSheet(
            queueTitle = uiState.activeQueueFilter.label,
            queue = queue,
            currentSongId = uiState.currentSong?.id,
            onSelectSong = { viewModel.playSongInCurrentOrAllQueue(it) },
            onDismiss = { showQueueSheet = false },
        )
    }

    songForLyricsEdit?.let { target ->
        LyricsEditorDialog(
            song = target,
            onDismiss = { songForLyricsEdit = null },
            onSave = { updated -> viewModel.updateLyrics(target.id, updated) },
        )
    }
}

@Composable
private fun NowPlayingActionChip(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    tag: String,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.Black.copy(alpha = 0.25f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = label, tint = SunozaIvory, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = SunozaIvory)
    }
}
