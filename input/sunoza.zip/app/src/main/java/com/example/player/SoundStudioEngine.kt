package com.example.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import com.example.model.EqPreset
import com.example.model.ReverbOption
import com.example.model.SoundStudioState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.abs

/**
 * Attaches real Android AudioEffect DSP instances (Equalizer, BassBoost, Virtualizer,
 * PresetReverb, LoudnessEnhancer) directly to ExoPlayer's audioSessionId.
 */
class SoundStudioEngine {
    private val uiBandCentersHz = listOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var presetReverb: PresetReverb? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var currentAudioSessionId: Int = 0

    private val _state = MutableStateFlow(SoundStudioState())
    val state: StateFlow<SoundStudioState> = _state.asStateFlow()

    fun attachToAudioSession(audioSessionId: Int) {
        if (audioSessionId <= 0 || audioSessionId == currentAudioSessionId) return
        releaseEffects()
        currentAudioSessionId = audioSessionId

        var attachedAny = false
        var hwBands = 0

        runCatching {
            Equalizer(0, audioSessionId).also { eq ->
                equalizer = eq
                hwBands = eq.numberOfBands.toInt()
                attachedAny = true
            }
        }
        runCatching {
            BassBoost(0, audioSessionId).also {
                bassBoost = it
                attachedAny = true
            }
        }
        runCatching {
            Virtualizer(0, audioSessionId).also {
                virtualizer = it
                attachedAny = true
            }
        }
        runCatching {
            PresetReverb(0, audioSessionId).also {
                presetReverb = it
                attachedAny = true
            }
        }
        runCatching {
            LoudnessEnhancer(audioSessionId).also {
                loudnessEnhancer = it
                attachedAny = true
            }
        }

        _state.update {
            it.copy(
                hardwareBandCount = hwBands,
                effectsAttached = attachedAny,
            )
        }
        applyCurrentParameters()
    }

    fun applyLoadedState(loaded: SoundStudioState) {
        _state.update {
            loaded.copy(
                hardwareBandCount = it.hardwareBandCount,
                effectsAttached = it.effectsAttached,
            )
        }
        applyCurrentParameters()
    }

    fun setEnabled(enabled: Boolean): SoundStudioState {
        _state.update { it.copy(isEnabled = enabled) }
        applyCurrentParameters()
        return _state.value
    }

    fun applyPreset(preset: EqPreset): SoundStudioState {
        _state.update {
            it.copy(
                isEnabled = true,
                activePresetName = preset.label,
                bandsDb = preset.bandsDb,
                bassBoost = preset.bassBoost,
                trebleBoost = preset.trebleBoost,
                virtualizer = preset.virtualizer,
                loudnessGainMb = preset.loudnessGainMb,
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    fun updateBand(bandIndex: Int, dbValue: Float): SoundStudioState {
        if (bandIndex !in 0..9) return _state.value
        val updated = _state.value.bandsDb.toMutableList()
        updated[bandIndex] = dbValue.coerceIn(-12f, 12f)
        _state.update {
            it.copy(
                isEnabled = true,
                activePresetName = "Custom",
                bandsDb = updated,
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    fun setBassBoost(strength: Int): SoundStudioState {
        _state.update {
            it.copy(
                isEnabled = true,
                activePresetName = "Custom",
                bassBoost = strength.coerceIn(0, 1000),
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    fun setTrebleBoost(trebleDb: Float): SoundStudioState {
        _state.update {
            it.copy(
                isEnabled = true,
                activePresetName = "Custom",
                trebleBoost = trebleDb.coerceIn(-6f, 12f),
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    fun setVirtualizer(strength: Int): SoundStudioState {
        _state.update {
            it.copy(
                isEnabled = true,
                activePresetName = "Custom",
                virtualizer = strength.coerceIn(0, 1000),
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    fun setReverb(reverbOption: ReverbOption): SoundStudioState {
        _state.update {
            it.copy(
                isEnabled = true,
                reverb = reverbOption,
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    fun setLoudnessGain(gainMb: Int): SoundStudioState {
        _state.update {
            it.copy(
                isEnabled = true,
                activePresetName = "Custom",
                loudnessGainMb = gainMb.coerceIn(0, 900),
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    fun reset(): SoundStudioState {
        _state.update {
            SoundStudioState(
                isEnabled = true,
                activePresetName = EqPreset.NORMAL.label,
                bandsDb = EqPreset.NORMAL.bandsDb,
                bassBoost = 0,
                trebleBoost = 0f,
                virtualizer = 0,
                reverb = ReverbOption.NONE,
                loudnessGainMb = 0,
                hardwareBandCount = it.hardwareBandCount,
                effectsAttached = it.effectsAttached,
            )
        }
        applyCurrentParameters()
        return _state.value
    }

    private fun applyCurrentParameters() {
        val s = _state.value
        val active = s.isEnabled

        // Map 10 UI bands + Treble high-shelf onto hardware Equalizer bands
        equalizer?.let { eq ->
            runCatching {
                eq.enabled = active
                if (active) {
                    val range = eq.bandLevelRange
                    val minMb = range[0].toInt()
                    val maxMb = range[1].toInt()
                    val numHwBands = eq.numberOfBands.toInt()
                    for (hwIdx in 0 until numHwBands) {
                        val centerHz = eq.getCenterFreq(hwIdx.toShort()) / 1000
                        val matchedUiBandIdx = uiBandCentersHz.indices.minByOrNull { uiIdx ->
                            abs(uiBandCentersHz[uiIdx] - centerHz)
                        } ?: 0
                        var targetDb = s.bandsDb.getOrElse(matchedUiBandIdx) { 0f }
                        // Apply treble shelf boost to upper bands (>= 3kHz)
                        if (centerHz >= 3000) {
                            targetDb += s.trebleBoost * 0.6f
                        }
                        val targetMb = (targetDb * 100f).toInt().coerceIn(minMb, maxMb)
                        eq.setBandLevel(hwIdx.toShort(), targetMb.toShort())
                    }
                }
            }
        }

        bassBoost?.let { bb ->
            runCatching {
                bb.enabled = active && s.bassBoost > 0
                if (bb.strengthSupported && active) {
                    bb.setStrength(s.bassBoost.coerceIn(0, 1000).toShort())
                }
            }
        }

        virtualizer?.let { virt ->
            runCatching {
                virt.enabled = active && s.virtualizer > 0
                if (virt.strengthSupported && active) {
                    virt.setStrength(s.virtualizer.coerceIn(0, 1000).toShort())
                }
            }
        }

        presetReverb?.let { rev ->
            runCatching {
                val useReverb = active && s.reverb != ReverbOption.NONE
                rev.enabled = useReverb
                if (useReverb) {
                    rev.preset = s.reverb.presetValue
                }
            }
        }

        loudnessEnhancer?.let { le ->
            runCatching {
                val useEnhancer = active && s.loudnessGainMb > 0
                le.enabled = useEnhancer
                if (useEnhancer) {
                    le.setTargetGain(s.loudnessGainMb.coerceIn(0, 900))
                }
            }
        }
    }

    fun releaseEffects() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { presetReverb?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        presetReverb = null
        loudnessEnhancer = null
        currentAudioSessionId = 0
    }
}
