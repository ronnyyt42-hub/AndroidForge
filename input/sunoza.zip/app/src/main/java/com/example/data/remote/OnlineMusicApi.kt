package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class AudiusTracksResponse(
    val data: List<AudiusTrackDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class AudiusTrackDto(
    val id: String? = null,
    val title: String? = null,
    val genre: String? = null,
    val mood: String? = null,
    val duration: Int? = null,
    @Json(name = "is_streamable") val isStreamable: Boolean? = true,
    @Json(name = "stream_conditions") val streamConditions: Any? = null,
    val artwork: AudiusArtworkDto? = null,
    val user: AudiusUserDto? = null,
)

@JsonClass(generateAdapter = true)
data class AudiusArtworkDto(
    @Json(name = "150x150") val small: String? = null,
    @Json(name = "480x480") val medium: String? = null,
    @Json(name = "1000x1000") val large: String? = null,
) {
    fun bestUrl(): String? = medium ?: large ?: small
}

@JsonClass(generateAdapter = true)
data class AudiusUserDto(
    val name: String? = null,
    val handle: String? = null,
)

@JsonClass(generateAdapter = true)
data class ItunesSearchResponse(
    val resultCount: Int = 0,
    val results: List<ItunesTrackDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ItunesTrackDto(
    val trackId: Long? = null,
    val trackName: String? = null,
    val artistName: String? = null,
    val collectionName: String? = null,
    val previewUrl: String? = null,
    val artworkUrl100: String? = null,
    val artworkUrl60: String? = null,
    val primaryGenreName: String? = null,
    val trackTimeMillis: Long? = null,
) {
    fun highResArtworkUrl(): String? {
        val raw = artworkUrl100 ?: artworkUrl60 ?: return null
        return raw.replace("100x100bb", "600x600bb")
            .replace("60x60bb", "600x600bb")
    }
}

interface AudiusApi {
    @GET("v1/tracks/trending")
    suspend fun getTrendingTracks(
        @Query("app_name") appName: String = "SUNOZA",
        @Query("limit") limit: Int = 18,
    ): AudiusTracksResponse

    @GET("v1/tracks/search")
    suspend fun searchTracks(
        @Query("query") query: String,
        @Query("app_name") appName: String = "SUNOZA",
        @Query("limit") limit: Int = 18,
    ): AudiusTracksResponse

    companion object {
        fun create(client: OkHttpClient): AudiusApi {
            return Retrofit.Builder()
                .baseUrl("https://api.audius.co/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(AudiusApi::class.java)
        }
    }
}

interface ItunesSearchApi {
    @GET("search")
    suspend fun searchSongs(
        @Query("term") term: String,
        @Query("media") media: String = "music",
        @Query("entity") entity: String = "song",
        @Query("limit") limit: Int = 18,
    ): ItunesSearchResponse

    companion object {
        fun create(client: OkHttpClient): ItunesSearchApi {
            return Retrofit.Builder()
                .baseUrl("https://itunes.apple.com/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(ItunesSearchApi::class.java)
        }
    }
}

object OnlineHttpClientProvider {
    val sharedClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .addInterceptor { chain ->
                val req = chain.request().newBuilder()
                    .header("User-Agent", "SunozaMusicPlayer/1.0 (Android)")
                    .header("Accept", "application/json")
                    .build()
                chain.proceed(req)
            }
            .addInterceptor(logging)
            .build()
    }
}
