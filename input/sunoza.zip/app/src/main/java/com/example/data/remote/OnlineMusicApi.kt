package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.FromJson
import com.squareup.moshi.Json
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.JsonClass
import com.squareup.moshi.JsonReader
import com.squareup.moshi.JsonWriter
import com.squareup.moshi.Moshi
import com.squareup.moshi.ToJson
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class AudiusTracksResponse(
    val data: List<AudiusTrackDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class AudiusTrackDto(
    val id: String? = null,
    val title: String? = null,
    val genre: String? = null,
    val mood: String? = null,
    val duration: Int? = null,
    val permalink: String? = null,
    val license: String? = null,
    @Json(name = "cc_license") val ccLicense: String? = null,
    @Json(name = "is_streamable") val isStreamable: Boolean? = true,
    @Json(name = "stream_conditions") val streamConditions: Any? = null,
    val artwork: AudiusArtworkDto? = null,
    val user: AudiusUserDto? = null,
)

@JsonClass(generateAdapter = true)
data class AudiusArtworkDto(
    @Json(name = "150x150") val small: String? = null,
    @Json(name = "480x480") val medium: String? = null,
    @Json(name = "1000x1000") val large: String? = null,
) {
    fun bestUrl(): String? = medium ?: large ?: small
}

@JsonClass(generateAdapter = true)
data class AudiusUserDto(
    val name: String? = null,
    val handle: String? = null,
)

/**
 * Resilient Moshi adapter for Audius `/v1/tracks/...` responses.
 * Live Audius discovery nodes occasionally return:
 * - `artwork` as a String URL or nested object with `mirrors` / `_150x150`
 * - `duration` as a floating-point number (e.g. `212.4`) or numeric string
 * - individual corrupt tracks inside `data`
 * Parsing each item defensively prevents one quirky track from dropping the entire catalog response.
 */
object AudiusResilientJsonParser {
    private val mapMoshi: Moshi = Moshi.Builder().build()

    fun parseTracksResponse(rawJson: String): AudiusTracksResponse {
        val adapter = mapMoshi.adapter(Map::class.java)
        val root = runCatching { adapter.fromJson(rawJson) }.getOrNull() ?: return AudiusTracksResponse()
        val dataList = root["data"] as? List<*> ?: return AudiusTracksResponse()
        val parsed = dataList.mapNotNull { entry ->
            (entry as? Map<*, *>)?.let(::mapToTrackDto)
        }
        return AudiusTracksResponse(data = parsed)
    }

    private fun mapToTrackDto(map: Map<*, *>): AudiusTrackDto? {
        val id = map["id"]?.toString()?.takeIf { it.isNotBlank() } ?: return null
        val title = map["title"]?.toString()?.trim()?.takeIf { it.isNotEmpty() } ?: return null

        val durationInt = when (val rawDur = map["duration"]) {
            is Number -> rawDur.toInt()
            is String -> rawDur.toDoubleOrNull()?.toInt()
            else -> null
        }

        val isStreamable = when (val rawStreamable = map["is_streamable"]) {
            is Boolean -> rawStreamable
            is String -> rawStreamable.toBooleanStrictOrNull() ?: true
            else -> true
        }

        val artwork = when (val rawArt = map["artwork"]) {
            is String -> rawArt.takeIf { it.isNotBlank() }?.let {
                AudiusArtworkDto(small = it, medium = it, large = it)
            }
            is Map<*, *> -> {
                val s = (rawArt["150x150"] ?: rawArt["_150x150"])?.toString()?.takeIf { it.isNotBlank() }
                val m = (rawArt["480x480"] ?: rawArt["_480x480"])?.toString()?.takeIf { it.isNotBlank() }
                val l = (rawArt["1000x1000"] ?: rawArt["_1000x1000"])?.toString()?.takeIf { it.isNotBlank() }
                if (s != null || m != null || l != null) {
                    AudiusArtworkDto(small = s, medium = m, large = l)
                } else {
                    null
                }
            }
            else -> null
        }

        val user = (map["user"] as? Map<*, *>)?.let { userMap ->
            AudiusUserDto(
                name = userMap["name"]?.toString()?.takeIf { it.isNotBlank() },
                handle = userMap["handle"]?.toString()?.takeIf { it.isNotBlank() },
            )
        }

        return AudiusTrackDto(
            id = id,
            title = title,
            genre = map["genre"]?.toString()?.takeIf { it.isNotBlank() },
            mood = map["mood"]?.toString()?.takeIf { it.isNotBlank() },
            duration = durationInt,
            permalink = map["permalink"]?.toString()?.takeIf { it.isNotBlank() },
            license = map["license"]?.toString()?.takeIf { it.isNotBlank() },
            ccLicense = map["cc_license"]?.toString()?.takeIf { it.isNotBlank() },
            isStreamable = isStreamable,
            streamConditions = map["stream_conditions"],
            artwork = artwork,
            user = user,
        )
    }
}

private class ResilientAudiusTracksResponseAdapter : JsonAdapter<AudiusTracksResponse>() {
    @FromJson
    override fun fromJson(reader: JsonReader): AudiusTracksResponse {
        val rawValue = reader.readJsonValue() as? Map<*, *> ?: return AudiusTracksResponse()
        val dataList = rawValue["data"] as? List<*> ?: return AudiusTracksResponse()
        val tracks = dataList.mapNotNull { item ->
            val map = item as? Map<*, *> ?: return@mapNotNull null
            val id = map["id"]?.toString()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val title = map["title"]?.toString()?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            val durationInt = when (val d = map["duration"]) {
                is Number -> d.toInt()
                is String -> d.toDoubleOrNull()?.toInt()
                else -> null
            }
            val streamable = when (val s = map["is_streamable"]) {
                is Boolean -> s
                is String -> s.toBooleanStrictOrNull() ?: true
                else -> true
            }
            val artwork = when (val rawArt = map["artwork"]) {
                is String -> rawArt.takeIf { it.isNotBlank() }?.let {
                    AudiusArtworkDto(small = it, medium = it, large = it)
                }
                is Map<*, *> -> AudiusArtworkDto(
                    small = (rawArt["150x150"] ?: rawArt["_150x150"])?.toString()?.takeIf { it.isNotBlank() },
                    medium = (rawArt["480x480"] ?: rawArt["_480x480"])?.toString()?.takeIf { it.isNotBlank() },
                    large = (rawArt["1000x1000"] ?: rawArt["_1000x1000"])?.toString()?.takeIf { it.isNotBlank() },
                )
                else -> null
            }
            val user = (map["user"] as? Map<*, *>)?.let { u ->
                AudiusUserDto(
                    name = u["name"]?.toString()?.takeIf { it.isNotBlank() },
                    handle = u["handle"]?.toString()?.takeIf { it.isNotBlank() },
                )
            }
            AudiusTrackDto(
                id = id,
                title = title,
                genre = map["genre"]?.toString()?.takeIf { it.isNotBlank() },
                mood = map["mood"]?.toString()?.takeIf { it.isNotBlank() },
                duration = durationInt,
                permalink = map["permalink"]?.toString()?.takeIf { it.isNotBlank() },
                license = map["license"]?.toString()?.takeIf { it.isNotBlank() },
                ccLicense = map["cc_license"]?.toString()?.takeIf { it.isNotBlank() },
                isStreamable = streamable,
                streamConditions = map["stream_conditions"],
                artwork = artwork,
                user = user,
            )
        }
        return AudiusTracksResponse(data = tracks)
    }

    @ToJson
    override fun toJson(writer: JsonWriter, value: AudiusTracksResponse?) {
        writer.beginObject()
        writer.name("data").beginArray()
        value?.data.orEmpty().forEach { t ->
            writer.beginObject()
            writer.name("id").value(t.id)
            writer.name("title").value(t.title)
            writer.name("genre").value(t.genre)
            writer.name("mood").value(t.mood)
            writer.name("duration").value(t.duration)
            writer.name("permalink").value(t.permalink)
            writer.name("license").value(t.license)
            writer.name("cc_license").value(t.ccLicense)
            writer.name("is_streamable").value(t.isStreamable)
            writer.endObject()
        }
        writer.endArray()
        writer.endObject()
    }
}

@JsonClass(generateAdapter = true)
data class ItunesSearchResponse(
    val resultCount: Int = 0,
    val results: List<ItunesTrackDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ItunesTrackDto(
    val trackId: Long? = null,
    val trackName: String? = null,
    val artistName: String? = null,
    val collectionName: String? = null,
    val previewUrl: String? = null,
    val trackViewUrl: String? = null,
    val collectionViewUrl: String? = null,
    val artworkUrl100: String? = null,
    val artworkUrl60: String? = null,
    val primaryGenreName: String? = null,
    val trackTimeMillis: Long? = null,
) {
    fun highResArtworkUrl(): String? {
        val raw = artworkUrl100 ?: artworkUrl60 ?: return null
        return raw.replace("100x100bb", "600x600bb")
            .replace("60x60bb", "600x600bb")
    }
}

interface AudiusApi {
    @GET("v1/tracks/trending")
    suspend fun getTrendingTracks(
        @Query("app_name") appName: String = "SUNOZA",
        @Query("limit") limit: Int = 18,
        @Query("offset") offset: Int = 0,
    ): AudiusTracksResponse

    @GET("v1/tracks/search")
    suspend fun searchTracks(
        @Query("query") query: String,
        @Query("app_name") appName: String = "SUNOZA",
        @Query("limit") limit: Int = 18,
        @Query("offset") offset: Int = 0,
    ): AudiusTracksResponse

    companion object {
        val resilientMoshi: Moshi by lazy {
            Moshi.Builder()
                .add(ResilientAudiusTracksResponseAdapter())
                .build()
        }

        fun create(
            client: OkHttpClient = OnlineHttpClientProvider.sharedClient,
            baseUrl: String = "https://api.audius.co/",
        ): AudiusApi {
            return Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create(resilientMoshi))
                .build()
                .create(AudiusApi::class.java)
        }
    }
}

interface ItunesSearchApi {
    @GET("search")
    suspend fun searchSongs(
        @Query("term") term: String,
        @Query("media") media: String = "music",
        @Query("entity") entity: String = "song",
        @Query("limit") limit: Int = 15,
        @Query("offset") offset: Int = 0,
    ): ItunesSearchResponse

    companion object {
        fun create(client: OkHttpClient = OnlineHttpClientProvider.sharedClient): ItunesSearchApi {
            return Retrofit.Builder()
                .baseUrl("https://itunes.apple.com/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(ItunesSearchApi::class.java)
        }
    }
}

interface WikimediaAudioApi {
    @GET("w/api.php")
    suspend fun searchAudioFiles(
        @Query("action") action: String = "query",
        @Query("format") format: String = "json",
        @Query("generator") generator: String = "search",
        @Query("gsrsearch") gsrsearch: String,
        @Query("gsrnamespace") gsrnamespace: Int = 6,
        @Query("gsrlimit") gsrlimit: Int = 6,
        @Query("gsroffset") gsroffset: Int = 0,
        @Query("prop") prop: String = "imageinfo",
        @Query("iiprop") iiprop: String = "url|mime|size|extmetadata",
    ): ResponseBody

    companion object {
        fun create(client: OkHttpClient = OnlineHttpClientProvider.sharedClient): WikimediaAudioApi {
            return Retrofit.Builder()
                .baseUrl("https://commons.wikimedia.org/")
                .client(client)
                .build()
                .create(WikimediaAudioApi::class.java)
        }
    }
}

object OnlineHttpClientProvider {
    val sharedClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BASIC
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .addInterceptor { chain ->
                val req = chain.request().newBuilder()
                    .header("User-Agent", "SunozaMusicPlayer/1.0 (Android)")
                    .header("Accept", "application/json")
                    .build()
                chain.proceed(req)
            }
            .addInterceptor(logging)
            .build()
    }
}
