package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.SunozaViewModel
import com.example.ui.components.SunozaAppRoot
import com.example.ui.theme.SunozaTheme

class MainActivity : ComponentActivity() {
    private val viewModel: SunozaViewModel by viewModels {
        val app = application as SunozaApplication
        SunozaViewModel.Factory(
            repository = app.musicRepository,
            playbackController = app.playbackController,
            soundStudioEngine = app.soundStudioEngine,
            soundStudioPreferences = app.soundStudioPreferences,
            audioBpmAnalyzer = app.audioBpmAnalyzer,
            mixFlowEngine = app.mixFlowEngine,
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        splashScreen.setKeepOnScreenCondition { !viewModel.uiState.value.isReady }

        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )

        val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            val offlineAudioPicker = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenMultipleDocuments(),
                onResult = { uris ->
                    if (uris.isNotEmpty()) {
                        viewModel.importOfflineFiles(uris)
                    }
                },
            )

            val audioPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission(),
                onResult = { granted ->
                    viewModel.onAudioPermissionResult(granted)
                },
            )

            val notificationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission(),
                onResult = { /* Playback notifications show when granted */ },
            )

            LaunchedEffect(Unit) {
                val hasAudio = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    audioPermission,
                ) == PackageManager.PERMISSION_GRANTED
                if (hasAudio) {
                    viewModel.onAudioPermissionResult(true)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val hasNotif = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS,
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!hasNotif) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            SunozaTheme {
                SunozaAppRoot(
                    uiState = uiState,
                    viewModel = viewModel,
                    onRequestAudioPermission = {
                        audioPermissionLauncher.launch(audioPermission)
                    },
                    onPickOfflineAudio = {
                        offlineAudioPicker.launch(arrayOf("audio/*"))
                    },
                )
            }
        }
    }
}
