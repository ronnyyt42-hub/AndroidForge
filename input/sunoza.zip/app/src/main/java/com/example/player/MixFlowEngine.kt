package com.example.player

import android.content.Context
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import com.example.model.AudioAnalysisResult
import com.example.model.Song
import com.example.model.SourceType
import com.example.model.TransitionFilterType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class DeckState(
    val song: Song? = null,
    val analysis: AudioAnalysisResult? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
)

data class MixFlowUiState(
    val deckA: DeckState = DeckState(),
    val deckB: DeckState = DeckState(),
    val crossfader: Float = 0.0f, // 0f = 100% Deck A, 1f = 100% Deck B
    val transitionDurationSec: Int = 6,
    val filterType: TransitionFilterType = TransitionFilterType.SMOOTH_FADE,
    val echoAmount: Float = 0.25f,
    val autoMixEnabled: Boolean = false,
    val beatSyncEnabled: Boolean = false,
    val isTransitioning: Boolean = false,
    val statusNote: String? = null,
)

/**
 * Real dual-deck ExoPlayer audio mixing engine for Sunoza MixFlow.
 * Supports independent Deck A / Deck B loading, equal-power cosine crossfading,
 * BPM beat synchronization, filter/echo transition DSP, Auto Mix, and Mix Preview.
 */
class MixFlowEngine(
    private val context: Context,
    private val bpmAnalyzer: AudioBpmAnalyzer,
    private val onPauseMainPlayer: () -> Unit,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var deckAPlayer: ExoPlayer? = null
    private var deckBPlayer: ExoPlayer? = null
    private var deckAEq: Equalizer? = null
    private var deckBEq: Equalizer? = null
    private var deckAReverb: PresetReverb? = null
    private var deckBReverb: PresetReverb? = null

    private var tickerJob: Job? = null
    private var transitionJob: Job? = null
    private var autoMixTriggeredForCurrentCycle = false

    private val _state = MutableStateFlow(MixFlowUiState())
    val state: StateFlow<MixFlowUiState> = _state.asStateFlow()

    @OptIn(UnstableApi::class)
    private fun ensurePlayers() {
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        if (deckAPlayer == null) {
            deckAPlayer = ExoPlayer.Builder(context)
                .setAudioAttributes(attrs, false)
                .build().apply {
                    addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) {
                            _state.update { it.copy(deckA = it.deckA.copy(isPlaying = isPlaying)) }
                            refreshTicker()
                        }

                        override fun onPlaybackStateChanged(playbackState: Int) {
                            val dur = duration.takeIf { d -> d > 0 } ?: _state.value.deckA.song?.durationMs ?: 0L
                            _state.update { it.copy(deckA = it.deckA.copy(durationMs = dur)) }
                        }
                    })
                    if (audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                        runCatching { deckAEq = Equalizer(0, audioSessionId) }
                        runCatching { deckAReverb = PresetReverb(0, audioSessionId) }
                    }
                }
        }
        if (deckBPlayer == null) {
            deckBPlayer = ExoPlayer.Builder(context)
                .setAudioAttributes(attrs, false)
                .build().apply {
                    addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) {
                            _state.update { it.copy(deckB = it.deckB.copy(isPlaying = isPlaying)) }
                            refreshTicker()
                        }

                        override fun onPlaybackStateChanged(playbackState: Int) {
                            val dur = duration.takeIf { d -> d > 0 } ?: _state.value.deckB.song?.durationMs ?: 0L
                            _state.update { it.copy(deckB = it.deckB.copy(durationMs = dur)) }
                        }
                    })
                    if (audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                        runCatching { deckBEq = Equalizer(0, audioSessionId) }
                        runCatching { deckBReverb = PresetReverb(0, audioSessionId) }
                    }
                }
        }
    }

    fun loadDeckA(song: Song) {
        if (!isMixPermitted(song)) return
        ensurePlayers()
        autoMixTriggeredForCurrentCycle = false
        val player = deckAPlayer ?: return
        player.setMediaItem(MediaItem.fromUri(song.audioUri))
        player.prepare()
        _state.update {
            it.copy(
                deckA = DeckState(song = song, durationMs = song.durationMs, playbackSpeed = 1f),
                statusNote = null,
            )
        }
        applyCrossfaderAndDsp(_state.value.crossfader)
        scope.launch {
            val analysis = bpmAnalyzer.analyzeSong(song)
            _state.update {
                it.copy(deckA = it.deckA.copy(analysis = analysis))
            }
            if (_state.value.beatSyncEnabled) applyBeatSync()
        }
    }

    fun loadDeckB(song: Song) {
        if (!isMixPermitted(song)) return
        ensurePlayers()
        autoMixTriggeredForCurrentCycle = false
        val player = deckBPlayer ?: return
        player.setMediaItem(MediaItem.fromUri(song.audioUri))
        player.prepare()
        _state.update {
            it.copy(
                deckB = DeckState(song = song, durationMs = song.durationMs, playbackSpeed = 1f),
                statusNote = null,
            )
        }
        applyCrossfaderAndDsp(_state.value.crossfader)
        scope.launch {
            val analysis = bpmAnalyzer.analyzeSong(song)
            _state.update {
                it.copy(deckB = it.deckB.copy(analysis = analysis))
            }
            if (_state.value.beatSyncEnabled) applyBeatSync()
        }
    }

    fun loadBlendPair(currentSong: Song, nextSong: Song) {
        setCrossfader(0.0f)
        loadDeckA(currentSong)
        loadDeckB(nextSong)
    }

    fun toggleDeckAPlayPause() {
        ensurePlayers()
        val p = deckAPlayer ?: return
        if (p.isPlaying) {
            p.pause()
        } else {
            onPauseMainPlayer()
            if (p.playbackState == Player.STATE_IDLE || p.playbackState == Player.STATE_ENDED) {
                p.seekTo(0L)
                p.prepare()
            }
            applyCrossfaderAndDsp(_state.value.crossfader)
            p.play()
        }
    }

    fun toggleDeckBPlayPause() {
        ensurePlayers()
        val p = deckBPlayer ?: return
        if (p.isPlaying) {
            p.pause()
        } else {
            onPauseMainPlayer()
            if (p.playbackState == Player.STATE_IDLE || p.playbackState == Player.STATE_ENDED) {
                p.seekTo(0L)
                p.prepare()
            }
            applyCrossfaderAndDsp(_state.value.crossfader)
            p.play()
        }
    }

    fun seekDeckA(posMs: Long) {
        deckAPlayer?.seekTo(posMs.coerceAtLeast(0L))
        _state.update { it.copy(deckA = it.deckA.copy(positionMs = posMs)) }
    }

    fun seekDeckB(posMs: Long) {
        deckBPlayer?.seekTo(posMs.coerceAtLeast(0L))
        _state.update { it.copy(deckB = it.deckB.copy(positionMs = posMs)) }
    }

    fun setCrossfader(value: Float) {
        val clamped = value.coerceIn(0f, 1f)
        _state.update { it.copy(crossfader = clamped) }
        applyCrossfaderAndDsp(clamped)
    }

    fun setTransitionDuration(seconds: Int) {
        _state.update { it.copy(transitionDurationSec = seconds.coerceIn(2, 16)) }
    }

    fun setFilterType(type: TransitionFilterType) {
        _state.update { it.copy(filterType = type) }
        applyCrossfaderAndDsp(_state.value.crossfader)
    }

    fun setEchoAmount(amount: Float) {
        _state.update { it.copy(echoAmount = amount.coerceIn(0f, 1f)) }
        applyCrossfaderAndDsp(_state.value.crossfader)
    }

    fun setAutoMix(enabled: Boolean) {
        autoMixTriggeredForCurrentCycle = false
        _state.update { it.copy(autoMixEnabled = enabled) }
    }

    fun toggleBeatSync() {
        val next = !_state.value.beatSyncEnabled
        _state.update { it.copy(beatSyncEnabled = next) }
        if (next) {
            applyBeatSync()
        } else {
            deckBPlayer?.playbackParameters = PlaybackParameters(1.0f)
            _state.update { it.copy(deckB = it.deckB.copy(playbackSpeed = 1.0f)) }
        }
    }

    fun startMixPreview() {
        ensurePlayers()
        val pA = deckAPlayer ?: return
        val pB = deckBPlayer ?: return
        if (_state.value.deckA.song == null || _state.value.deckB.song == null) {
            _state.update { it.copy(statusNote = "Load songs on both Deck A and Deck B to preview a mix.") }
            return
        }
        onPauseMainPlayer()
        if (pA.playbackState == Player.STATE_IDLE || pA.playbackState == Player.STATE_ENDED) {
            pA.seekTo(0L)
            pA.prepare()
        }
        if (pB.playbackState == Player.STATE_IDLE || pB.playbackState == Player.STATE_ENDED) {
            pB.seekTo(0L)
            pB.prepare()
        }
        setCrossfader(0.5f)
        pA.play()
        pB.play()
        _state.update { it.copy(statusNote = "Mix Preview active at 50/50 blend.") }
    }

    fun triggerSmoothCrossfadeTransition() {
        ensurePlayers()
        val pA = deckAPlayer ?: return
        val pB = deckBPlayer ?: return
        val s = _state.value
        if (s.deckA.song == null || s.deckB.song == null) {
            _state.update { it.copy(statusNote = "Select songs for both Deck A and Deck B first.") }
            return
        }
        onPauseMainPlayer()
        val goingToB = s.crossfader < 0.5f
        val startX = s.crossfader
        val endX = if (goingToB) 1.0f else 0.0f

        if (goingToB && !pB.isPlaying) {
            if (pB.playbackState == Player.STATE_IDLE || pB.playbackState == Player.STATE_ENDED) {
                pB.seekTo(0L)
                pB.prepare()
            }
            pB.play()
        } else if (!goingToB && !pA.isPlaying) {
            if (pA.playbackState == Player.STATE_IDLE || pA.playbackState == Player.STATE_ENDED) {
                pA.seekTo(0L)
                pA.prepare()
            }
            pA.play()
        }

        transitionJob?.cancel()
        transitionJob = scope.launch {
            _state.update { it.copy(isTransitioning = true, statusNote = "Transitioning (${s.transitionDurationSec}s ${s.filterType.label})...") }
            val steps = (s.transitionDurationSec * 20).coerceAtLeast(20)
            val stepDelay = (s.transitionDurationSec * 1_000L) / steps
            for (step in 1..steps) {
                val frac = step.toFloat() / steps.toFloat()
                val currentX = startX + (endX - startX) * frac
                setCrossfader(currentX)
                delay(stepDelay)
            }
            setCrossfader(endX)
            if (goingToB) pA.pause() else pB.pause()
            _state.update { it.copy(isTransitioning = false, statusNote = null) }
            autoMixTriggeredForCurrentCycle = false
        }
    }

    fun stopAll() {
        transitionJob?.cancel()
        deckAPlayer?.pause()
        deckBPlayer?.pause()
    }

    private fun applyBeatSync() {
        val bpmA = _state.value.deckA.analysis?.bpm ?: _state.value.deckA.song?.bpm ?: return
        val bpmB = _state.value.deckB.analysis?.bpm ?: _state.value.deckB.song?.bpm ?: return
        if (bpmA <= 0 || bpmB <= 0) return
        val ratio = (bpmA.toFloat() / bpmB.toFloat()).coerceIn(0.75f, 1.35f)
        deckBPlayer?.playbackParameters = PlaybackParameters(ratio)
        _state.update {
            it.copy(
                deckB = it.deckB.copy(playbackSpeed = ratio),
                statusNote = "Beat Sync locked: ${bpmB} BPM -> ${bpmA} BPM (${String.format("%.2fx", ratio)})",
            )
        }
    }

    private fun applyCrossfaderAndDsp(crossfader: Float) {
        // Equal-power cosine/sine curve
        val angle = crossfader * (PI / 2.0)
        val volA = cos(angle).toFloat().coerceIn(0f, 1f)
        val volB = sin(angle).toFloat().coerceIn(0f, 1f)
        deckAPlayer?.volume = volA
        deckBPlayer?.volume = volB

        val s = _state.value
        val midBlend = 1f - kotlin.math.abs(crossfader - 0.5f) * 2f // peaks at 1.0 in middle of transition

        // Apply filter sweep on outgoing/incoming EQ bands
        applyDeckFilter(deckAEq, s.filterType, cutStrength = crossfader)
        applyDeckFilter(deckBEq, s.filterType, cutStrength = 1f - crossfader)

        // Apply reverb/echo blend during transitions
        val useEcho = s.filterType == TransitionFilterType.ECHO_FADE || s.echoAmount > 0.05f
        val activeEcho = useEcho && midBlend > 0.1f && s.echoAmount > 0.05f
        runCatching {
            deckAReverb?.enabled = activeEcho
            if (activeEcho) deckAReverb?.preset = PresetReverb.PRESET_LARGEHALL
        }
        runCatching {
            deckBReverb?.enabled = activeEcho
            if (activeEcho) deckBReverb?.preset = PresetReverb.PRESET_LARGEHALL
        }
    }

    private fun applyDeckFilter(eq: Equalizer?, filterType: TransitionFilterType, cutStrength: Float) {
        eq ?: return
        runCatching {
            when (filterType) {
                TransitionFilterType.SMOOTH_FADE, TransitionFilterType.ECHO_FADE -> {
                    eq.enabled = false
                }
                TransitionFilterType.LOW_PASS_SWEEP -> {
                    eq.enabled = cutStrength > 0.05f
                    val bands = eq.numberOfBands.toInt()
                    val minMb = eq.bandLevelRange[0].toInt()
                    for (i in 0 until bands) {
                        val centerHz = eq.getCenterFreq(i.toShort()) / 1000
                        val level = if (centerHz >= 2000) (minMb * cutStrength * 0.85f).toInt() else 0
                        eq.setBandLevel(i.toShort(), level.toShort())
                    }
                }
                TransitionFilterType.HIGH_PASS_SWEEP -> {
                    eq.enabled = cutStrength > 0.05f
                    val bands = eq.numberOfBands.toInt()
                    val minMb = eq.bandLevelRange[0].toInt()
                    for (i in 0 until bands) {
                        val centerHz = eq.getCenterFreq(i.toShort()) / 1000
                        val level = if (centerHz <= 500) (minMb * cutStrength * 0.85f).toInt() else 0
                        eq.setBandLevel(i.toShort(), level.toShort())
                    }
                }
            }
        }
    }

    private fun isMixPermitted(song: Song): Boolean {
        if (song.sourceType == SourceType.AUTHORIZED_ONLINE) {
            val check = AuthorizedSourceValidator.validateUrl(song.audioUri)
            if (check is SourceValidationResult.Rejected) {
                _state.update { it.copy(statusNote = check.reason) }
                return false
            }
        }
        return true
    }

    private fun refreshTicker() {
        val anyPlaying = (deckAPlayer?.isPlaying == true) || (deckBPlayer?.isPlaying == true)
        if (!anyPlaying) {
            tickerJob?.cancel()
            tickerJob = null
            return
        }
        if (tickerJob?.isActive == true) return
        tickerJob = scope.launch {
            while (true) {
                val pA = deckAPlayer
                val pB = deckBPlayer
                val posA = pA?.currentPosition?.coerceAtLeast(0L) ?: 0L
                val durA = pA?.duration?.takeIf { it > 0 } ?: _state.value.deckA.durationMs
                val posB = pB?.currentPosition?.coerceAtLeast(0L) ?: 0L
                val durB = pB?.duration?.takeIf { it > 0 } ?: _state.value.deckB.durationMs

                _state.update {
                    it.copy(
                        deckA = it.deckA.copy(positionMs = posA, durationMs = durA),
                        deckB = it.deckB.copy(positionMs = posB, durationMs = durB),
                    )
                }

                // Auto Mix check
                val s = _state.value
                if (s.autoMixEnabled && !s.isTransitioning && !autoMixTriggeredForCurrentCycle &&
                    s.deckA.song != null && s.deckB.song != null
                ) {
                    val triggerWindowMs = s.transitionDurationSec * 1_000L
                    val activeIsA = s.crossfader < 0.5f
                    if (activeIsA && pA?.isPlaying == true && durA > triggerWindowMs + 2_000L &&
                        posA >= durA - triggerWindowMs
                    ) {
                        autoMixTriggeredForCurrentCycle = true
                        triggerSmoothCrossfadeTransition()
                    } else if (!activeIsA && pB?.isPlaying == true && durB > triggerWindowMs + 2_000L &&
                        posB >= durB - triggerWindowMs
                    ) {
                        autoMixTriggeredForCurrentCycle = true
                        triggerSmoothCrossfadeTransition()
                    }
                }
                delay(150L)
            }
        }
    }

    fun release() {
        tickerJob?.cancel()
        transitionJob?.cancel()
        runCatching { deckAEq?.release() }
        runCatching { deckBEq?.release() }
        runCatching { deckAReverb?.release() }
        runCatching { deckBReverb?.release() }
        deckAPlayer?.release()
        deckBPlayer?.release()
        deckAPlayer = null
        deckBPlayer = null
    }
}
