package com.example.model

import android.media.audiofx.PresetReverb

enum class EqPreset(
    val label: String,
    val bandsDb: List<Float>, // 10 bands: 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k
    val bassBoost: Int,       // 0..1000
    val trebleBoost: Float,   // -6..+12 dB shelf
    val virtualizer: Int,     // 0..1000
    val loudnessGainMb: Int,  // 0..900 mB
) {
    NORMAL(
        label = "Normal",
        bandsDb = listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
        bassBoost = 0,
        trebleBoost = 0f,
        virtualizer = 0,
        loudnessGainMb = 0,
    ),
    POP(
        label = "Pop",
        bandsDb = listOf(-1f, 1.5f, 3.5f, 4f, 2f, 0f, -1f, 2f, 3.5f, 4f),
        bassBoost = 220,
        trebleBoost = 2.5f,
        virtualizer = 250,
        loudnessGainMb = 180,
    ),
    ROCK(
        label = "Rock",
        bandsDb = listOf(4.5f, 3.5f, 2f, -1f, -2f, 0.5f, 2.5f, 4f, 5f, 4.5f),
        bassBoost = 380,
        trebleBoost = 3.5f,
        virtualizer = 300,
        loudnessGainMb = 240,
    ),
    JAZZ(
        label = "Jazz",
        bandsDb = listOf(3f, 2f, 1f, 2f, -1.5f, -1.5f, 0f, 2f, 3.5f, 4f),
        bassBoost = 180,
        trebleBoost = 2f,
        virtualizer = 420,
        loudnessGainMb = 120,
    ),
    CLASSICAL(
        label = "Classical",
        bandsDb = listOf(4f, 3f, 2f, 0.5f, -1f, -1f, 0.5f, 2.5f, 3.5f, 4.5f),
        bassBoost = 100,
        trebleBoost = 3f,
        virtualizer = 500,
        loudnessGainMb = 80,
    ),
    VOCAL(
        label = "Vocal",
        bandsDb = listOf(-2.5f, -2f, -1f, 1.5f, 4f, 5f, 4f, 2.5f, 1f, 0f),
        bassBoost = 80,
        trebleBoost = 1.5f,
        virtualizer = 220,
        loudnessGainMb = 260,
    ),
    DEEP_BASS(
        label = "Deep Bass",
        bandsDb = listOf(8f, 7f, 5.5f, 3f, 0.5f, -1f, 0f, 1.5f, 2.5f, 2f),
        bassBoost = 760,
        trebleBoost = 1f,
        virtualizer = 350,
        loudnessGainMb = 320,
    ),
}

enum class ReverbOption(val label: String, val presetValue: Short) {
    NONE("Off", PresetReverb.PRESET_NONE),
    SMALL_ROOM("Small Room", PresetReverb.PRESET_SMALLROOM),
    MEDIUM_ROOM("Studio Room", PresetReverb.PRESET_MEDIUMROOM),
    LARGE_ROOM("Club Room", PresetReverb.PRESET_LARGEROOM),
    MEDIUM_HALL("Concert Hall", PresetReverb.PRESET_MEDIUMHALL),
    LARGE_HALL("Arena Hall", PresetReverb.PRESET_LARGEHALL),
    PLATE("Warm Plate", PresetReverb.PRESET_PLATE),
}

val TenBandLabels = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

data class SoundStudioState(
    val isEnabled: Boolean = true,
    val activePresetName: String = EqPreset.NORMAL.label,
    val bandsDb: List<Float> = EqPreset.NORMAL.bandsDb,
    val bassBoost: Int = 0,
    val trebleBoost: Float = 0f,
    val virtualizer: Int = 0,
    val reverb: ReverbOption = ReverbOption.NONE,
    val loudnessGainMb: Int = 0,
    val hardwareBandCount: Int = 0,
    val effectsAttached: Boolean = false,
)
